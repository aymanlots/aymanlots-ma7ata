export type Language = 'ar';

export const translations = {
  ar: {
    appName: 'محطة الاتحادية',
    tagline: 'السفر ونقل البضائع والكوليات',
    routeTitle: 'خط النقل الدولي المغرب ⇋ موريتانيا',
    
    // Navigation
    navDashboard: 'الرئيسية',
    navParcels: 'الكوليات والإرساليات',
    navCash: 'الصناديق والقيود',
    navLedger: 'السجل المالي',
    navSettings: 'الإعدادات',
    navNewVoucher: 'إيصال / كولي جديد',
    navReceipts: 'مركز السندات PDF',

    // Roles & Stations
    owner: 'مدير المحطة (مشرف)',
    worker: 'عامل المحطة',
    allStations: 'جميع المحطات',
    station: 'المحطة',
    cashRegister: 'صندوق النقدية',
    activeBox: 'الصندوق نشط',

    // Currencies
    mad: 'درهم مغربي',
    mru: 'أوقية موريتانية',
    madSymbol: 'د.م.',
    mruSymbol: 'أ.م.',
    exchangeRateLabel: 'سعر الصرف اللحظي',
    converter: 'محوّل العملات (درهم ⇋ أوقية)',

    // Parcels
    parcelsTitle: 'إدارة الكوليات والبضائع المشحونة',
    newParcel: 'تسجيل إرسالية جديدة',
    trackParcel: 'تتبع كولي',
    trackingCode: 'رمز التتبع',
    sender: 'المرسل',
    receiver: 'المستلم',
    senderPhone: 'هاتف المرسل',
    receiverPhone: 'هاتف المستلم',
    originStation: 'محطة الانطلاق',
    destStation: 'محطة الوصول',
    route: 'خط السير الدولي',
    parcelCategory: 'نوع البضاعة',
    itemsCount: 'عدد الطرود',
    weight: 'الوزن (كلغ)',
    shippingFee: 'أجرة الشحن',
    codAmount: 'مبلغ التحصيل عند الاستلام',
    declaredValue: 'القيمة المصرح بها',
    paymentStatus: 'حالة الأداء',
    paidPrepaid: 'مدفوع مسبقاً بالمحطة',
    codUnpaid: 'الدفع عند الاستلام',
    parcelStatus: 'حالة الكولي',
    
    statusPending: 'قيد الانتظار بالمحطة',
    statusInTransit: 'في الطريق عبر الحدود',
    statusArrived: 'وصلت محطة الوصول',
    statusDelivered: 'تم التسليم للمستلم',
    statusCancelled: 'ملغاة',

    markInTransit: 'إرسال في الطريق',
    markArrived: 'تسجيل وصول بالمحطة',
    deliverParcel: 'تسليم الكولي واستلام المبلغ',
    printReceipt: 'طباعة التوصيل والباركود',
    previewReceipt: 'معاينة قبل الطباعة',
    downloadPdf: 'طباعة PDF',
    searchParcels: 'بحث برقم الهاتف، الرمز، أو الاسم...',

    // Cash & Vouchers
    cashIn: 'سند قبض نقدي',
    cashOut: 'سند صرف نقدي',
    goodsPayment: 'سداد أمانة بضائع',
    todayIn: 'مقبوضات اليوم',
    todayOut: 'مدفوعات ومصاريف اليوم',
    netBalance: 'الرصيد الصافي المتاح',
    dailyReport: 'التقرير المالي اليومي',
    exportReport: 'تصدير التقرير',
    printReport: 'طباعة الكشف اليومي',
    
    // Actions
    save: 'حفظ وتأكيد',
    cancel: 'إلغاء',
    close: 'إغلاق',
    confirm: 'تأكيد العملية',
    viewDetails: 'عرض التفاصيل',
    download: 'تحميل',
    print: 'طباعة',
    quickActions: 'العمليات السريعة',
  }
};
