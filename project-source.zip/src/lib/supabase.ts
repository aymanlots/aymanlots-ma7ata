import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Convert phone number to standard domain-specific email for Supabase Auth (no SMS required)
export const phoneToEmail = (phone: string): string => {
  const clean = phone.replace(/[^0-9]/g, '');
  return `${clean}@alittihadia.app`;
};

// Clean phone format
export const cleanPhoneNumber = (phone: string): string => {
  return phone.trim().replace(/\s+/g, '');
};

// Get Supabase credentials from environment or localStorage (only anon public key)
const getStoredCredentials = () => {
  const envUrl = import.meta.env.VITE_SUPABASE_URL;
  const envKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
  const localUrl = localStorage.getItem('aman_supabase_url');
  const localKey = localStorage.getItem('aman_supabase_anon_key');

  const url = localUrl || (envUrl && !envUrl.includes('your-project-id') ? envUrl : '');
  const key = localKey || (envKey && !envKey.includes('your-anon-public-key') ? envKey : '');

  return { url, key, isConfigured: Boolean(url && key) };
};

let clientInstance: SupabaseClient | null = null;

export const isSupabaseConfigured = (): boolean => {
  return getStoredCredentials().isConfigured;
};

export const getSupabaseClient = (): SupabaseClient | null => {
  const { url, key, isConfigured } = getStoredCredentials();
  if (!isConfigured) return null;

  if (!clientInstance) {
    try {
      clientInstance = createClient(url, key, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
          detectSessionInUrl: false
        },
      });
    } catch (e) {
      console.warn('Failed to initialize Supabase client:', e);
      return null;
    }
  }
  return clientInstance;
};

export const saveSupabaseConfig = (url: string, key: string) => {
  if (url && key) {
    localStorage.setItem('aman_supabase_url', url.trim());
    localStorage.setItem('aman_supabase_anon_key', key.trim());
    clientInstance = null; // Reset to force re-instantiation
  } else {
    localStorage.removeItem('aman_supabase_url');
    localStorage.removeItem('aman_supabase_anon_key');
    clientInstance = null;
  }
};

export const clearSupabaseConfig = () => {
  localStorage.removeItem('aman_supabase_url');
  localStorage.removeItem('aman_supabase_anon_key');
  clientInstance = null;
};
