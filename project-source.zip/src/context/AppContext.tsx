import React, { 
  createContext, 
  useContext, 
  useState, 
  useEffect, 
  ReactNode, 
  useMemo,
  useRef,
  useCallback
} from 'react';
import { 
  Profile, 
  Workspace,
  Team,
  WorkspaceMember,
  TeamMember,
  JoinRequest,
  WorkspaceCollaboration,
  Station, 
  StationWorker, 
  Currency, 
  Transaction, 
  TransactionType,
  Parcel,
  ParcelStatus,
  PaymentStatus,
  ParcelPayer,
  ParcelStatusHistoryEntry,
  ParcelPaymentEntry,
  ParcelCondition,
  Trip,
  TripStatus,
  RememberedDriver,
  RememberedVehicle,
  PasswordResetRequest,
  Subscription, 
  AuditLogEntry, 
  UserRole,
  Language
} from '../types/database';
import { translations } from '../lib/i18n';
import { parcelService, mapSupabaseRowToParcel } from '../services/parcelService';
import { tripService, mapSupabaseRowToTrip } from '../services/tripService';
import { cashService, mapSupabaseRowToTransaction } from '../services/cashService';
import { storageService, generateUUID, isValidUUID } from '../services/storageService';
import { 
  getSupabaseClient, 
  isSupabaseConfigured, 
  phoneToEmail, 
  cleanPhoneNumber 
} from '../lib/supabase';
import { PLATFORM_CONFIG, DEMO_MODE } from '../config/constants';
import { generateWorkspaceDemoData } from '../utils/demoData';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

// Helper to generate 6-character short workspace ID
const generateShortId = (): string => {
  const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  let res = '';
  for (let i = 0; i < 6; i++) {
    res += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return res;
};

// Helper to generate 8-character random invite code
const generateInviteCode = (): string => {
  const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  let res = '';
  for (let i = 0; i < 8; i++) {
    res += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return res;
};

// Base cross-border stations (starts with ZERO balance)
const getInitialStations = (workspaceId: string): Station[] => [
  {
    id: `sta-${workspaceId}-dakhla`,
    workspace_id: workspaceId,
    team_id: workspaceId,
    name: 'محطة الداخلة الرئيسية',
    city: 'الداخلة',
    country: 'MA',
    owner_id: null,
    is_active: true,
    phone: '+212 528 890000',
    address: 'شارع الولاء، ميناء الداخلة، المملكة المغربية',
    created_at: new Date().toISOString(),
    balances: { MAD: 0, MRU: 0 },
  },
  {
    id: `sta-${workspaceId}-nouadhibou`,
    workspace_id: workspaceId,
    team_id: workspaceId,
    name: 'محطة نواذيبو الدولية',
    city: 'نواذيبو',
    country: 'MR',
    owner_id: null,
    is_active: true,
    phone: '+222 4574 0000',
    address: 'حي كانصادو، طريق الميناء المستقل، الجمهورية الإسلامية الموريتانية',
    created_at: new Date().toISOString(),
    balances: { MAD: 0, MRU: 0 },
  },
];

const getInitialCurrencies = (workspaceId: string): Currency[] => [
  {
    id: `curr-${workspaceId}-mad`,
    workspace_id: workspaceId,
    team_id: workspaceId,
    code: 'MAD',
    label_ar: 'درهم مغربي',
    label_fr: 'Dirham Marocain',
    symbol: 'د.م.',
    is_active: true,
    rate_to_mad: 1.0,
    created_at: new Date().toISOString(),
  },
  {
    id: `curr-${workspaceId}-mru`,
    workspace_id: workspaceId,
    team_id: workspaceId,
    code: 'MRU',
    label_ar: 'أوقية موريتانية',
    label_fr: 'Ouguiya Mauritanienne',
    symbol: 'أ.م.',
    is_active: true,
    rate_to_mad: 0.263,
    created_at: new Date().toISOString(),
  },
];

interface AppContextType {
  // Authentication & Profile
  currentUser: Profile | null;
  userRole: UserRole;
  isLoggedIn: boolean;
  registerUser: (data: {
    name: string;
    phone: string;
    whatsapp_number: string;
    password?: string;
    isOwner: boolean;
    teamInviteCode?: string;
  }) => Promise<{ success: boolean; error?: string }>;
  loginWithCredentials: (phone: string, password?: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;

  // Workspace (Multi-Admin Isolation)
  currentWorkspace: Workspace | null;
  currentTeam: Workspace | null; // compatibility alias
  workspaceMembers: WorkspaceMember[];
  teamMembers: WorkspaceMember[]; // compatibility alias
  stations: Station[];
  selectedStationId: string | null;
  setSelectedStationId: (id: string | null) => void;
  userAssignedStationId: string | null;

  // Join Requests (Workers requesting to join)
  joinRequests: JoinRequest[];
  approveJoinRequest: (requestId: string) => Promise<{ success: boolean; error?: string }>;
  rejectJoinRequest: (requestId: string) => Promise<{ success: boolean; error?: string }>;
  renewInviteCode: () => Promise<string>;

  // Admin-to-Admin Collaborations (Optional Sharing)
  collaborations: WorkspaceCollaboration[];
  sendCollaborationRequest: (targetShortId: string) => Promise<{ success: boolean; error?: string; message?: string }>;
  respondToCollaboration: (collabId: string, accept: boolean) => Promise<{ success: boolean; error?: string; message?: string }>;
  updateSharingSettings: (collabId: string, shareCash: boolean, shareParcels: boolean, shareReports: boolean) => Promise<{ success: boolean; error?: string }>;

  // Dual Currency & Exchange Rate
  currencies: Currency[];
  stationBalances: Record<string, Record<string, number>>;
  exchangeRate: number;
  setExchangeRate: (rate: number) => void;
  convertCurrency: (amount: number, from: string, to: string) => number;

  // Transactions & Cash Register (Strictly 0 Initial Fake Data)
  transactions: Transaction[];
  auditLogs: AuditLogEntry[];
  createTransaction: (data: {
    station_id: string;
    type: TransactionType;
    amount: number;
    currency: string;
    phone_number?: string;
    reason?: string;
    photo_url?: string;
    note?: string;
    parcel_id?: string;
  }) => Promise<{ success: boolean; error?: string; transaction?: Transaction }>;
  updateTransaction: (id: string, updates: Partial<Transaction>, editReason?: string) => Promise<{ success: boolean; error?: string }>;
  cancelTransaction: (id: string, reason: string) => Promise<{ success: boolean; error?: string }>;
  
  // Parcels Module (Strictly 0 Initial Fake Data)
  parcels: Parcel[];
  createParcel: (data: {
    origin_station_id: string;
    destination_station_id: string;
    sender_name: string;
    sender_phone: string;
    receiver_name: string;
    receiver_phone: string;
    route?: string;
    description: string;
    category?: string;
    items_count?: number;
    weight_kg?: number;
    declared_value?: number;
    amount_due?: number;
    shipping_fee?: number;
    payer?: ParcelPayer;
    amount_paid?: number;
    cod_amount?: number;
    currency: string;
    payment_status?: PaymentStatus;
    notes?: string;
    condition?: ParcelCondition;
    condition_notes?: string;
  }) => Promise<{ success: boolean; error?: string; parcel?: Parcel }>;
  updateParcelStatus: (
    id: string, 
    status: ParcelStatus, 
    notesOrMeta?: { delivered_to?: string; notes?: string; condition?: ParcelCondition; condition_notes?: string } | string,
    deliveredTo?: string
  ) => Promise<{ success: boolean; error?: string }>;
  recordParcelPayment: (
    parcelId: string, 
    amount: number, 
    paidBy: string, 
    note?: string
  ) => Promise<{ success: boolean; error?: string }>;
  updateParcel: (id: string, updates: Partial<Parcel>) => Promise<{ success: boolean; error?: string }>;
  getParcelByTrackingCode: (code: string) => Parcel | undefined;

  // Trips Module (الرحلات والديسباتش)
  trips: Trip[];
  rememberedDrivers: RememberedDriver[];
  rememberedPlates: RememberedVehicle[];
  createTrip: (params: {
    driverName: string;
    driverPhone?: string;
    vehiclePlate: string;
    originStationId: string;
    destinationStationId: string;
    notes?: string;
  }) => Promise<{ success: boolean; error?: string; trip?: Trip }>;
  loadParcelToTrip: (
    tripId: string,
    parcelIdentifier: string
  ) => Promise<{ success: boolean; error?: string; warning?: string; trip?: Trip; parcel?: Parcel }>;
  unloadParcelFromTrip: (
    tripId: string,
    parcelId: string
  ) => Promise<{ success: boolean; error?: string; trip?: Trip }>;
  departTrip: (
    tripId: string
  ) => Promise<{ success: boolean; error?: string; trip?: Trip }>;
  receiveParcelAtDestination: (
    tripId: string,
    parcelIdentifier: string,
    condition: ParcelCondition,
    conditionNotes?: string
  ) => Promise<{ success: boolean; error?: string; trip?: Trip; parcel?: Parcel; allScanned?: boolean }>;
  closeTrip: (
    tripId: string,
    closeReason?: string
  ) => Promise<{ success: boolean; error?: string; trip?: Trip }>;

  // Admin Management
  addBalanceAdjustment: (stationId: string, currency: string, amount: number, note: string) => Promise<{ success: boolean; error?: string }>;
  createTeam: (name: string) => Promise<{ success: boolean; error?: string }>;
  joinTeam: (inviteCode: string) => Promise<{ success: boolean; error?: string }>;
  regenerateInviteCode: () => Promise<string>;
  addStation: (name: string, city: string, country?: 'MA' | 'MR', phone?: string, address?: string) => Promise<{ success: boolean; error?: string }>;
  addWorkerByOwner: (name: string, phone: string, stationId: string, role?: UserRole) => Promise<{ success: boolean; error?: string }>;
  assignWorkerToStation: (stationId: string, userId: string) => Promise<{ success: boolean }>;
  removeWorkerFromTeam: (userId: string) => Promise<{ success: boolean }>;
  addCurrency: (code: string, label_ar: string, symbol: string, label_fr?: string, rate?: number) => Promise<{ success: boolean }>;

  // Platform Owner & Multi-Workspace Controls
  allWorkspaces: Workspace[];
  allSubscriptions: Subscription[];
  updateWorkspaceSubscription: (workspaceId: string, action: 'activate' | 'extend' | 'suspend', months?: number) => Promise<{ success: boolean; error?: string }>;
  updateWorkspaceNotes: (workspaceId: string, notes: string) => Promise<{ success: boolean; error?: string }>;

  // Password Reset System (Worker to Admin, Admin to Platform Owner)
  passwordResetRequests: PasswordResetRequest[];
  submitPasswordResetRequest: (data: { phone: string; whatsapp: string; accountType: 'worker' | 'admin'; userName?: string }) => Promise<{ success: boolean; error?: string }>;
  resolvePasswordResetRequest: (requestId: string, approved: boolean, tempPassword?: string) => Promise<{ success: boolean; error?: string }>;

  // Language & i18n
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: keyof typeof translations.ar) => string;

  // Subscription / Paywall
  subscription: Subscription | null;
  isSubscriptionExpired: boolean;
  daysUntilExpiry: number;
  extendSubscription: (days?: number) => void;

  // Feedback & Status
  isSupabaseLive: boolean;
  hasDemoData: boolean;
  deleteDemoData: () => void;
  toast: { message: string; type: 'success' | 'error' | 'info' } | null;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  resetAllDataToZero: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const isSupabaseLive = isSupabaseConfigured();
  // عندما يكون اتصال Supabase مفعلاً، يُعامل DEMO_MODE كـ false تلقائياً
  const isEffectiveDemoMode = DEMO_MODE && !isSupabaseLive;

  // Language State - Strictly Modern Standard Arabic (العربية الفصحى)
  const language: Language = 'ar';
  const setLanguage = (_lang: Language) => {
    document.documentElement.dir = 'rtl';
    document.documentElement.lang = 'ar';
  };
  const t = (key: keyof typeof translations.ar) => {
    return translations.ar[key] || (key as string);
  };

  // Official Exchange Rate: 1 MAD = 3.80 MRU (0.263 MAD per MRU)
  const [exchangeRate, setExchangeRateState] = useState<number>(() => {
    const saved = localStorage.getItem('ittihadiya_rate');
    return saved ? parseFloat(saved) : 3.80;
  });

  const setExchangeRate = (rate: number) => {
    setExchangeRateState(rate);
    localStorage.setItem('ittihadiya_rate', rate.toString());
  };

  const convertCurrency = (amount: number, from: string, to: string): number => {
    if (from === to) return amount;
    if (from === 'MAD' && to === 'MRU') {
      return Math.round(amount * exchangeRate * 100) / 100;
    }
    if (from === 'MRU' && to === 'MAD') {
      return Math.round((amount / exchangeRate) * 100) / 100;
    }
    return amount;
  };

  // 1. Current User Profile
  const [currentUser, setCurrentUser] = useState<Profile | null>(() => {
    const saved = localStorage.getItem('aman_user');
    if (!saved) return null;
    try {
      const parsed = JSON.parse(saved);
      if (parsed?.id?.includes('usr-owner-001')) return null;
      return parsed;
    } catch {
      return null;
    }
  });

  // 2. Current Workspace (Multi-Admin Isolation with 6-char Short ID)
  const [currentWorkspace, setCurrentWorkspace] = useState<Workspace | null>(() => {
    const saved = localStorage.getItem('aman_workspace') || localStorage.getItem('aman_team');
    if (!saved) return null;
    try {
      const parsed = JSON.parse(saved);
      if (parsed?.id?.includes('team-aman-001')) return null;
      // Ensure short_id exists
      if (!parsed.short_id) {
        parsed.short_id = generateShortId();
      }
      return parsed;
    } catch {
      return null;
    }
  });

  // 3. Workspace Members
  const [workspaceMembers, setWorkspaceMembers] = useState<WorkspaceMember[]>(() => {
    const saved = localStorage.getItem('aman_workspace_members') || localStorage.getItem('aman_members');
    if (!saved) return [];
    try {
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });

  // 4. Join Requests (Workers wanting to join workspace)
  const [joinRequests, setJoinRequests] = useState<JoinRequest[]>(() => {
    const saved = localStorage.getItem('aman_join_requests');
    if (!saved) return [];
    try {
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });

  // 5. Admin Collaborations (Optional Sharing between Workspaces)
  const [collaborations, setCollaborations] = useState<WorkspaceCollaboration[]>(() => {
    const saved = localStorage.getItem('aman_collaborations');
    if (!saved) return [];
    try {
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });

  // 6. Stations
  const [stations, setStations] = useState<Station[]>(() => {
    const saved = localStorage.getItem('aman_stations');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch {}
    }
    return getInitialStations(currentWorkspace?.id || 'ws-default');
  });

  // 7. Station Workers
  const [stationWorkers, setStationWorkers] = useState<StationWorker[]>(() => {
    const saved = localStorage.getItem('aman_station_workers');
    if (!saved) return [];
    try {
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });

  // 8. Currencies
  const [currencies, setCurrencies] = useState<Currency[]>(() => {
    const saved = localStorage.getItem('aman_currencies');
    return saved ? JSON.parse(saved) : getInitialCurrencies(currentWorkspace?.id || 'ws-default');
  });

  // 9. All Transactions (Filtered by workspace + collaborations)
  const [allTransactions, setAllTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('aman_transactions');
    if (!saved) return [];
    try {
      const parsed = JSON.parse(saved);
      if (!Array.isArray(parsed) || parsed.some(t => t.id?.includes('tx-001-init'))) return [];
      return parsed;
    } catch {
      return [];
    }
  });

  // 10. All Parcels (Filtered by workspace + collaborations)
  const [allParcels, setAllParcels] = useState<Parcel[]>(() => {
    const saved = localStorage.getItem('ittihadiya_parcels');
    if (!saved) return [];
    try {
      const parsed = JSON.parse(saved);
      if (!Array.isArray(parsed) || parsed.some(p => p.id?.includes('pcl-001'))) return [];
      return parsed;
    } catch {
      return [];
    }
  });

  // 10.b All Trips & Dispatch
  const [allTrips, setAllTrips] = useState<Trip[]>(() => {
    return storageService.get<Trip[]>('TRIPS', []);
  });

  const [rememberedDrivers, setRememberedDrivers] = useState<RememberedDriver[]>(() => {
    return tripService.getRememberedDrivers();
  });

  const [rememberedPlates, setRememberedPlates] = useState<RememberedVehicle[]>(() => {
    return tripService.getRememberedPlates();
  });

  // 11. Subscription
  const [subscription, setSubscription] = useState<Subscription | null>(() => {
    const saved = localStorage.getItem('aman_subscription');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    return {
      id: 'sub-active',
      workspace_id: currentWorkspace?.id || 'ws-default',
      team_id: currentWorkspace?.id || 'ws-default',
      status: 'active',
      start_date: new Date().toISOString(),
      end_date: new Date(Date.now() + 30 * 86400000).toISOString(),
      created_at: new Date().toISOString(),
    };
  });

  // 12. Audit Logs
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(() => {
    const saved = localStorage.getItem('aman_audit_logs');
    return saved ? JSON.parse(saved) : [];
  });

  // 13. All Workspaces (Platform Owner View)
  const [allWorkspacesState, setAllWorkspacesState] = useState<Workspace[]>(() => {
    const saved = localStorage.getItem('alittihadia_all_workspaces');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch {}
    }
    return currentWorkspace ? [currentWorkspace] : [];
  });

  // 14. All Subscriptions (Platform Owner View)
  const [allSubscriptionsState, setAllSubscriptionsState] = useState<Subscription[]>(() => {
    const saved = localStorage.getItem('alittihadia_all_subscriptions');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch {}
    }
    return subscription ? [subscription] : [];
  });

  // 15. Password Reset Requests
  const [passwordResetRequestsState, setPasswordResetRequestsState] = useState<PasswordResetRequest[]>(() => {
    const saved = localStorage.getItem('alittihadia_password_reset_requests');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch {}
    }
    return [];
  });

  const [selectedStationId, setSelectedStationId] = useState<string | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const isOnline = useOnlineStatus();
  const realtimeChannelRef = useRef<any>(null);

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  }, []);

  // Load workspace data from Supabase when configured and logged in
  const loadWorkspaceFromCloud = useCallback(async (wsId: string, userId?: string) => {
    if (!isSupabaseConfigured() || !isValidUUID(wsId)) return;
    const supabase = getSupabaseClient();
    if (!supabase) return;

    try {
      // 1. Check platform_owners for current user
      if (userId && isValidUUID(userId)) {
        const { data: poRow } = await supabase
          .from('platform_owners')
          .select('user_id')
          .eq('user_id', userId)
          .maybeSingle();
        if (poRow?.user_id) {
          localStorage.setItem('alittihadia_platform_owners', JSON.stringify([poRow.user_id]));
        }
      }

      // 2. Load stations
      const { data: stRows } = await supabase
        .from('stations')
        .select('*')
        .eq('workspace_id', wsId)
        .order('created_at', { ascending: true });
      const loadedStations: Station[] = stRows && stRows.length > 0
        ? stRows.map((s: any) => ({ ...s, team_id: s.workspace_id }))
        : stations;
      if (stRows && stRows.length > 0) {
        setStations(loadedStations);
      }

      // 3. Load currencies
      const { data: currRows } = await supabase
        .from('currencies')
        .select('*')
        .eq('workspace_id', wsId)
        .order('created_at', { ascending: true });
      if (currRows && currRows.length > 0) {
        setCurrencies(currRows.map((c: any) => ({ ...c, team_id: c.workspace_id })));
      }

      // 4. Load workspace members + profiles
      const { data: memRows } = await supabase
        .from('workspace_members')
        .select('*, profile:profiles(*)')
        .eq('workspace_id', wsId);
      const loadedMembers: WorkspaceMember[] = memRows && memRows.length > 0
        ? memRows.map((m: any) => ({
            id: m.id,
            workspace_id: m.workspace_id,
            user_id: m.user_id,
            role: m.role,
            status: m.status,
            joined_at: m.joined_at,
            profile: Array.isArray(m.profile) ? m.profile[0] : m.profile,
          }))
        : workspaceMembers;
      if (memRows && memRows.length > 0) {
        setWorkspaceMembers(loadedMembers);
      }

      // 5. Load station_workers
      const { data: swRows } = await supabase
        .from('station_workers')
        .select('*, profile:profiles(*)')
        .eq('workspace_id', wsId);
      if (swRows) {
        setStationWorkers(swRows.map((sw: any) => ({
          id: sw.id,
          station_id: sw.station_id,
          workspace_id: sw.workspace_id,
          user_id: sw.user_id,
          assigned_at: sw.assigned_at,
          profile: Array.isArray(sw.profile) ? sw.profile[0] : sw.profile,
        })));
      }

      // 6. Load join_requests
      const { data: jrRows } = await supabase
        .from('join_requests')
        .select('*')
        .eq('workspace_id', wsId)
        .order('created_at', { ascending: false });
      if (jrRows) {
        setJoinRequests(jrRows as JoinRequest[]);
      }

      // 7. Load workspace_collaborations
      const { data: colRows } = await supabase
        .from('workspace_collaborations')
        .select('*')
        .or(`requester_workspace_id.eq.${wsId},target_workspace_id.eq.${wsId}`)
        .order('created_at', { ascending: false });
      if (colRows) {
        setCollaborations(colRows as WorkspaceCollaboration[]);
      }

      // 8. Load subscription
      const { data: subRow } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('workspace_id', wsId)
        .maybeSingle();
      if (subRow) {
        setSubscription({ ...subRow, team_id: subRow.workspace_id } as Subscription);
      }

      // 9. Build profiles lookup map for creator names
      const profilesMap: Record<string, string> = {};
      loadedMembers.forEach(m => {
        if (m.user_id && m.profile?.name) {
          profilesMap[m.user_id] = m.profile.name;
        }
      });

      // 10. Load parcels (preserving any local unsynced pending_sync items)
      const cloudParcels = await parcelService.fetchFromCloud(wsId, loadedStations);
      if (cloudParcels !== null) {
        setAllParcels(prev => {
          const pendingLocal = prev.filter(p => p.pending_sync && !cloudParcels.some(cp => cp.id === p.id));
          return [...pendingLocal, ...cloudParcels];
        });
      }

      // 11. Load trips + remembered drivers & vehicles
      const cloudTripBundle = await tripService.fetchFromCloud(wsId, loadedStations);
      if (cloudTripBundle !== null) {
        setAllTrips(prev => {
          const pendingLocal = prev.filter(t => t.pending_sync && !cloudTripBundle.trips.some(ct => ct.id === t.id));
          return [...pendingLocal, ...cloudTripBundle.trips];
        });
        setRememberedDrivers(cloudTripBundle.drivers);
        setRememberedPlates(cloudTripBundle.plates);
      }

      // 12. Load transactions & audit logs
      const cloudCashBundle = await cashService.fetchFromCloud(wsId, loadedStations);
      if (cloudCashBundle !== null) {
        setAllTransactions(prev => {
          const pendingLocal = prev.filter(tx => tx.pending_sync && !cloudCashBundle.transactions.some(ct => ct.id === tx.id));
          return [...pendingLocal, ...cloudCashBundle.transactions];
        });
        setAuditLogs(cloudCashBundle.auditLogs);
      }
    } catch (err) {
      console.warn('Error loading workspace data from Supabase:', err);
    }
  }, []);

  // Flush pending offline operations when browser comes back online
  useEffect(() => {
    if (!isOnline || !isSupabaseConfigured() || !currentUser || !currentWorkspace) return;
    if (!isValidUUID(currentWorkspace.id)) return;

    let cancelled = false;
    (async () => {
      const queue = storageService.getPendingSync();
      if (queue.length === 0) return;

      const pFlushed = await parcelService.flushPendingSync();
      const tFlushed = await tripService.flushPendingSync();
      const cFlushed = await cashService.flushPendingSync();
      const totalFlushed = pFlushed.synced + tFlushed.synced + cFlushed.synced;

      if (!cancelled && totalFlushed > 0) {
        setAllParcels(prev => prev.map(p => ({ ...p, pending_sync: false })));
        setAllTrips(prev => prev.map(t => ({ ...t, pending_sync: false })));
        setAllTransactions(prev => prev.map(tx => ({ ...tx, pending_sync: false })));
        showToast(`تمت مزامنة ${totalFlushed} عملية معلقة مع السحابة بنجاح`, 'success');
        await loadWorkspaceFromCloud(currentWorkspace.id, currentUser.id);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [isOnline, currentUser?.id, currentWorkspace?.id, loadWorkspaceFromCloud, showToast]);

  // Initial load + Realtime subscription when logged in & workspace active
  useEffect(() => {
    if (!isSupabaseConfigured() || !currentUser || !currentWorkspace) return;
    if (!isValidUUID(currentWorkspace.id)) return;

    const supabase = getSupabaseClient();
    if (!supabase) return;

    // Load initial cloud state
    loadWorkspaceFromCloud(currentWorkspace.id, currentUser.id);

    // Clean up any existing channel before subscribing
    if (realtimeChannelRef.current) {
      supabase.removeChannel(realtimeChannelRef.current);
      realtimeChannelRef.current = null;
    }

    const wsId = currentWorkspace.id;
    const channel = supabase
      .channel(`workspace-sync-${wsId}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'parcels' },
        () => {
          loadWorkspaceFromCloud(wsId, currentUser.id);
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'trips' },
        () => {
          loadWorkspaceFromCloud(wsId, currentUser.id);
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'trip_parcels' },
        () => {
          loadWorkspaceFromCloud(wsId, currentUser.id);
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'transactions' },
        () => {
          loadWorkspaceFromCloud(wsId, currentUser.id);
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'stations' },
        () => {
          loadWorkspaceFromCloud(wsId, currentUser.id);
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'join_requests' },
        () => {
          loadWorkspaceFromCloud(wsId, currentUser.id);
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'workspace_collaborations' },
        () => {
          loadWorkspaceFromCloud(wsId, currentUser.id);
        }
      )
      .subscribe();

    realtimeChannelRef.current = channel;

    return () => {
      if (realtimeChannelRef.current) {
        supabase.removeChannel(realtimeChannelRef.current);
        realtimeChannelRef.current = null;
      }
    };
  }, [currentUser?.id, currentWorkspace?.id, loadWorkspaceFromCloud]);

  // Determine User Role in current workspace
  const userRole: UserRole = useMemo(() => {
    if (!currentUser) return 'worker';
    
    // الأمان المحكم: دور مالك المنصة لا يُمنح برقم الهاتف أبداً
    // يتم التحقق حصراً من وجود معرف المستخدم في جدول platform_owners
    const savedPlatformOwners = localStorage.getItem('alittihadia_platform_owners');
    if (savedPlatformOwners) {
      try {
        const ownerIds: string[] = JSON.parse(savedPlatformOwners);
        if (ownerIds.includes(currentUser.id)) {
          return 'platform_owner';
        }
      } catch {}
    }
    if (!currentWorkspace) return 'owner';
    const member = workspaceMembers.find(m => m.user_id === currentUser.id && m.status === 'active');
    if (member?.role === 'admin' || member?.role === 'owner') return 'owner';
    return member?.role || (currentWorkspace.created_by === currentUser.id ? 'owner' : 'worker');
  }, [currentUser, currentWorkspace, workspaceMembers]);

  // Determine user's assigned station if worker
  const userAssignedStationId = useMemo(() => {
    if (!currentUser) return null;
    const assignment = stationWorkers.find(sw => sw.user_id === currentUser.id);
    return assignment?.station_id || stations[0]?.id || null;
  }, [currentUser, stationWorkers, stations]);

  useEffect(() => {
    if (userRole === 'worker' && userAssignedStationId) {
      setSelectedStationId(userAssignedStationId);
    } else if (!selectedStationId && stations.length > 0) {
      setSelectedStationId(stations[0].id);
    } else if (stations.length === 0 && selectedStationId !== null) {
      setSelectedStationId(null);
    }
  }, [userRole, userAssignedStationId, stations, selectedStationId]);

  // Pre-fill demo data automatically if DEMO_MODE is active (and Supabase is NOT configured)
  // for a newly initialized local workspace that hasn't been seeded or had demo data deleted yet.
  useEffect(() => {
    if (!isEffectiveDemoMode || !currentWorkspace || !currentUser) return;
    const seededKey = `ittihadiya_demo_seeded_${currentWorkspace.id}`;
    const deletedKey = `ittihadiya_demo_deleted_${currentWorkspace.id}`;
    if (localStorage.getItem(deletedKey)) return;

    const wsParcels = allParcels.filter(p => p.workspace_id === currentWorkspace.id);
    if (localStorage.getItem(seededKey)) {
      if (wsParcels.some(p => p.is_demo && (p.sender_name === 'مرسل تجريبي 4' || p.sender_name === 'مرسل تجريبي 7'))) {
        setAllParcels(prev =>
          prev.map(p => {
            if (!p.is_demo) return p;
            if ([101, 102, 103, 107].includes(p.parcel_number)) {
              return { ...p, sender_name: 'مرسل تجريبي 1', sender_phone: '0600000011' };
            }
            if ([104, 105, 106].includes(p.parcel_number)) {
              return { ...p, sender_name: 'مرسل تجريبي 2', sender_phone: '0600000012' };
            }
            if (p.parcel_number === 108) {
              return { ...p, sender_name: 'مرسل تجريبي 3', sender_phone: '0600000013' };
            }
            return p;
          })
        );
      }
      return;
    }
    const wsTxs = allTransactions.filter(t => t.workspace_id === currentWorkspace.id);
    if (wsParcels.length === 0 && wsTxs.length === 0) {
      const demo = generateWorkspaceDemoData(currentWorkspace.id, currentUser);
      setStations(demo.stations);
      setSelectedStationId(demo.stations[0]?.id || null);
      setWorkspaceMembers(prev => {
        const nonDemo = prev.filter(m => !m.is_demo);
        const hasAdmin = nonDemo.some(m => m.user_id === currentUser.id);
        const base = hasAdmin
          ? nonDemo
          : [
              {
                workspace_id: currentWorkspace.id,
                user_id: currentUser.id,
                role: 'admin' as const,
                status: 'active' as const,
                joined_at: new Date().toISOString(),
                profile: currentUser,
              },
              ...nonDemo,
            ];
        return [...base, ...demo.members];
      });
      setStationWorkers(demo.stationWorkers);
      setAllParcels(prev => [...demo.parcels, ...prev.filter(p => p.workspace_id !== currentWorkspace.id)]);
      setAllTrips(prev => [...demo.trips, ...prev.filter(t => t.workspace_id !== currentWorkspace.id)]);
      setAllTransactions(prev => [...demo.transactions, ...prev.filter(tx => tx.workspace_id !== currentWorkspace.id)]);
      localStorage.setItem(seededKey, 'true');
    }
  }, [isEffectiveDemoMode, currentWorkspace?.id, currentUser?.id]);

  // ============================================================================
  // MULTI-ADMIN ISOLATION & OPTIONAL COLLABORATION FILTERING
  // ============================================================================

  // Visible Transactions:
  // 1. My workspace transactions
  // 2. Plus collaborating workspace transactions IF that partner has share_cash === true
  // 3. STRICT ISOLATION: If worker, only see transactions of their assigned station!
  const transactions: Transaction[] = useMemo(() => {
    if (!currentWorkspace) return [];
    const myWsId = currentWorkspace.id;

    // Find all partner workspaces that are currently sharing cash with us (Admin only)
    const sharedWsIds = new Set<string>();
    if (userRole !== 'worker') {
      collaborations.forEach(c => {
        if (c.status !== 'accepted') return;
        if (c.requester_workspace_id === myWsId && c.target_share_cash) {
          sharedWsIds.add(c.target_workspace_id);
        } else if (c.target_workspace_id === myWsId && c.requester_share_cash) {
          sharedWsIds.add(c.requester_workspace_id);
        }
      });
    }

    return allTransactions
      .filter(tx => {
        const txWs = tx.workspace_id || tx.team_id || '';
        const inScope = txWs === myWsId || (txWs ? sharedWsIds.has(txWs) : false);
        if (!inScope) return false;

        // منع مشاركة البيانات التجريبية مع المدراء المتعاونين نهائياً
        if (txWs !== myWsId && tx.is_demo) return false;

        // If worker: strictly isolate to their assigned station in their own workspace
        if (userRole === 'worker') {
          if (txWs !== myWsId) return false;
          if (userAssignedStationId && tx.station_id !== userAssignedStationId) return false;
        }

        return true;
      })
      .map(tx => {
        const txWs = tx.workspace_id || tx.team_id || '';
        const isFromPartner = txWs !== myWsId;
        return isFromPartner ? { ...tx, is_collaborator_data: true } : tx;
      });
  }, [currentWorkspace, collaborations, allTransactions, userRole, userAssignedStationId]);

  // Visible Parcels:
  // 1. My workspace parcels
  // 2. Plus collaborating workspace parcels IF that partner has share_parcels === true
  // 3. STRICT ISOLATION: If worker, only see parcels originating from or destined to their assigned station!
  const parcels: Parcel[] = useMemo(() => {
    if (!currentWorkspace) return [];
    const myWsId = currentWorkspace.id;

    const sharedWsIds = new Set<string>();
    if (userRole !== 'worker') {
      collaborations.forEach(c => {
        if (c.status !== 'accepted') return;
        if (c.requester_workspace_id === myWsId && c.target_share_parcels) {
          sharedWsIds.add(c.target_workspace_id);
        } else if (c.target_workspace_id === myWsId && c.requester_share_parcels) {
          sharedWsIds.add(c.requester_workspace_id);
        }
      });
    }

    return allParcels
      .filter(p => {
        const pWs = p.workspace_id || p.team_id || '';
        const inScope = pWs === myWsId || (pWs ? sharedWsIds.has(pWs) : false);
        if (!inScope) return false;

        // منع مشاركة البيانات التجريبية مع المدراء المتعاونين نهائياً
        if (pWs !== myWsId && p.is_demo) return false;

        // If worker: strictly isolate to parcels originating or arriving at their assigned station
        if (userRole === 'worker') {
          if (pWs !== myWsId) return false;
          if (userAssignedStationId) {
            const isOrigin = p.origin_station_id === userAssignedStationId;
            const isDest = p.destination_station_id === userAssignedStationId;
            if (!isOrigin && !isDest) return false;
          }
        }

        return true;
      })
      .map(p => {
        const pWs = p.workspace_id || p.team_id || '';
        const isFromPartner = pWs !== myWsId;
        return isFromPartner ? { ...p, is_collaborator_data: true } : p;
      });
  }, [currentWorkspace, collaborations, allParcels, userRole, userAssignedStationId]);

  // Visible Trips:
  // Strictly isolated: Workers only see trips originating from or heading to their assigned station!
  const trips: Trip[] = useMemo(() => {
    if (!currentWorkspace) return [];
    const myWsId = currentWorkspace.id;
    return allTrips.filter(t => {
      if (t.workspace_id !== myWsId) return false;
      if (userRole === 'worker' && userAssignedStationId) {
        const isOrigin = t.origin_station_id === userAssignedStationId;
        const isDest = t.destination_station_id === userAssignedStationId;
        if (!isOrigin && !isDest) return false;
      }
      return true;
    });
  }, [currentWorkspace, allTrips, userRole, userAssignedStationId]);

  useEffect(() => {
    storageService.set('TRIPS', allTrips);
  }, [allTrips]);

  // Station Balances Calculation (Strictly Real Transactions Only)
  const stationBalances = useMemo(() => {
    const balances: Record<string, Record<string, number>> = {};

    stations.forEach(s => {
      balances[s.id] = {};
      currencies.forEach(c => {
        balances[s.id][c.code] = 0;
      });
    });

    transactions.forEach(tx => {
      if (tx.status !== 'confirmed' || tx.deleted_at) return;
      if (!balances[tx.station_id]) {
        balances[tx.station_id] = {};
      }
      if (balances[tx.station_id][tx.currency] === undefined) {
        balances[tx.station_id][tx.currency] = 0;
      }

      const amt = Number(tx.amount);
      if (isNaN(amt)) return;

      const isInflow = tx.type === 'cash_in' || tx.type === 'parcel_shipping_fee' || tx.type === 'parcel_cod_collection';
      const isOutflow = tx.type === 'cash_out' || tx.type === 'goods_payment' || tx.type === 'parcel_cod_payout';

      if (isInflow) {
        balances[tx.station_id][tx.currency] += amt;
      } else if (isOutflow) {
        balances[tx.station_id][tx.currency] -= amt;
      }

      balances[tx.station_id][tx.currency] = Math.round((balances[tx.station_id][tx.currency] + Number.EPSILON) * 100) / 100;
    });

    return balances;
  }, [stations, currencies, transactions]);

  // Local Storage Persistence
  useEffect(() => {
    if (currentUser) localStorage.setItem('aman_user', JSON.stringify(currentUser));
    else localStorage.removeItem('aman_user');
  }, [currentUser]);

  useEffect(() => {
    if (currentWorkspace) {
      localStorage.setItem('aman_workspace', JSON.stringify(currentWorkspace));
      localStorage.setItem('aman_team', JSON.stringify(currentWorkspace));
    } else {
      localStorage.removeItem('aman_workspace');
      localStorage.removeItem('aman_team');
    }
  }, [currentWorkspace]);

  useEffect(() => {
    localStorage.setItem('aman_workspace_members', JSON.stringify(workspaceMembers));
    localStorage.setItem('aman_members', JSON.stringify(workspaceMembers));
  }, [workspaceMembers]);

  useEffect(() => {
    localStorage.setItem('aman_join_requests', JSON.stringify(joinRequests));
  }, [joinRequests]);

  useEffect(() => {
    localStorage.setItem('aman_collaborations', JSON.stringify(collaborations));
  }, [collaborations]);

  useEffect(() => {
    localStorage.setItem('aman_stations', JSON.stringify(stations));
  }, [stations]);

  useEffect(() => {
    localStorage.setItem('aman_station_workers', JSON.stringify(stationWorkers));
  }, [stationWorkers]);

  useEffect(() => {
    localStorage.setItem('aman_currencies', JSON.stringify(currencies));
  }, [currencies]);

  useEffect(() => {
    localStorage.setItem('aman_transactions', JSON.stringify(allTransactions));
  }, [allTransactions]);

  useEffect(() => {
    localStorage.setItem('ittihadiya_parcels', JSON.stringify(allParcels));
  }, [allParcels]);

  useEffect(() => {
    if (subscription) localStorage.setItem('aman_subscription', JSON.stringify(subscription));
  }, [subscription]);

  useEffect(() => {
    localStorage.setItem('aman_audit_logs', JSON.stringify(auditLogs));
  }, [auditLogs]);

  // Subscription calculation
  const isSubscriptionExpired = useMemo(() => {
    if (!subscription) return false;
    const end = new Date(subscription.end_date).getTime();
    return end < Date.now();
  }, [subscription]);

  const daysUntilExpiry = useMemo(() => {
    if (!subscription) return 30;
    const diff = new Date(subscription.end_date).getTime() - Date.now();
    return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
  }, [subscription]);

  // ============================================================================
  // AUTHENTICATION: PHONE + PASSWORD WITHOUT SMS (GENERATING EMAIL @alittihadia.app)
  // ============================================================================

  const registerUser = async (data: {
    name: string;
    phone: string;
    whatsapp_number: string;
    password?: string;
    isOwner: boolean;
    teamInviteCode?: string;
  }) => {
    try {
      const cleanPhone = cleanPhoneNumber(data.phone);
      const cleanWhatsapp = cleanPhoneNumber(data.whatsapp_number) || cleanPhone;
      const pwd = data.password || '123456';
      const syntheticEmail = phoneToEmail(cleanPhone);

      const supabase = getSupabaseClient();
      let userId = `usr-${Date.now()}`;

      // 1. If Supabase is live, register via Supabase Auth
      if (supabase) {
        const { data: authData, error: authError } = await supabase.auth.signUp({
          email: syntheticEmail,
          password: pwd,
          options: {
            data: {
              name: data.name.trim(),
              phone: cleanPhone,
              whatsapp_number: cleanWhatsapp,
            }
          }
        });

        if (authError) {
          // If already registered, try signing in
          if (authError.message.includes('already registered')) {
            return await loginWithCredentials(cleanPhone, pwd);
          }
          return { success: false, error: authError.message };
        }

        if (authData.user) {
          userId = authData.user.id;
        }
      }

      // 2. Create profile
      const newProfile: Profile = {
        id: userId,
        phone: cleanPhone,
        whatsapp_number: cleanWhatsapp,
        name: data.name.trim(),
        created_at: new Date().toISOString(),
      };
      setCurrentUser(newProfile);

      // 3. If Owner: Create new independent Workspace with 6-char short ID
      if (data.isOwner) {
        let short_id = generateShortId();
        let invite_code = generateInviteCode();
        let wsId = supabase ? generateUUID() : `ws-${Date.now()}`;

        let newWorkspace: Workspace = {
          id: wsId,
          short_id,
          name: `محطة الاتحادية - ${newProfile.name}`,
          invite_code,
          created_by: newProfile.id,
          created_at: new Date().toISOString(),
        };

        // Call RPC first if Supabase is connected so we use the authoritative DB UUIDs
        let rpcCreated = false;
        if (supabase) {
          try {
            const { data: rpcData, error: rpcErr } = await supabase.rpc('rpc_create_workspace', {
              p_name: newWorkspace.name
            });
            if (rpcErr) {
              showToast(`تنبيه مزامنة مساحة العمل: ${rpcErr.message}`, 'error');
            } else if (rpcData?.success && rpcData.workspace) {
              rpcCreated = true;
              newWorkspace = rpcData.workspace as Workspace;
              short_id = newWorkspace.short_id;
              invite_code = newWorkspace.invite_code;
              wsId = newWorkspace.id;
              setCurrentWorkspace(newWorkspace);

              if (Array.isArray(rpcData.stations) && rpcData.stations.length > 0) {
                const cloudStations = rpcData.stations.map((s: any) => ({ ...s, team_id: s.workspace_id }));
                setStations(cloudStations);
                setSelectedStationId(cloudStations[0].id);
              }
              if (Array.isArray(rpcData.currencies) && rpcData.currencies.length > 0) {
                setCurrencies(rpcData.currencies.map((c: any) => ({ ...c, team_id: c.workspace_id })));
              }
              if (rpcData.subscription) {
                setSubscription({ ...rpcData.subscription, team_id: newWorkspace.id });
              }
              const adminMember: WorkspaceMember = {
                workspace_id: newWorkspace.id,
                user_id: newProfile.id,
                role: 'admin',
                status: 'active',
                joined_at: rpcData.member?.joined_at || new Date().toISOString(),
                profile: newProfile,
              };
              setWorkspaceMembers([adminMember]);
              setStationWorkers([]);
            }
          } catch (e: any) {
            console.warn('RPC create_workspace sync error (local workspace active):', e);
            showToast('تعذر الاتصال بالسحابة، تم إنشاء مساحة العمل محلياً', 'error');
          }
        }

        if (!rpcCreated) {
          setCurrentWorkspace(newWorkspace);

          const adminMember: WorkspaceMember = {
            workspace_id: newWorkspace.id,
            user_id: newProfile.id,
            role: 'admin',
            status: 'active',
            joined_at: new Date().toISOString(),
            profile: newProfile,
          };
          const initialWsCurrencies = getInitialCurrencies(newWorkspace.id);
          setCurrencies(initialWsCurrencies);

          // إذا كان DEMO_MODE مفعلاً وSupabase غير مفعل، نملأ مساحة العمل الجديدة بالبيانات التجريبية تلقائياً
          if (DEMO_MODE && !isSupabaseConfigured() && !supabase) {
            const demo = generateWorkspaceDemoData(newWorkspace.id, newProfile);
            setStations(demo.stations);
            setSelectedStationId(demo.stations[0]?.id || null);
            setWorkspaceMembers([adminMember, ...demo.members]);
            setStationWorkers(demo.stationWorkers);
            setAllParcels(prev => [...demo.parcels, ...prev.filter(p => p.workspace_id !== newWorkspace.id)]);
            setAllTrips(prev => [...demo.trips, ...prev.filter(t => t.workspace_id !== newWorkspace.id)]);
            setAllTransactions(prev => [...demo.transactions, ...prev.filter(tx => tx.workspace_id !== newWorkspace.id)]);
            localStorage.setItem(`ittihadiya_demo_seeded_${newWorkspace.id}`, 'true');
          } else {
            setWorkspaceMembers([adminMember]);
            setStationWorkers([]);
            const initialWsStations = getInitialStations(newWorkspace.id);
            setStations(initialWsStations);
            setSelectedStationId(initialWsStations[0].id);
          }
        }

        showToast(`مرحباً بك يا ${newProfile.name}! تم إنشاء مساحة عملك المستقلة بنجاح (معرفك: ${short_id})`, 'success');
        return { success: true };
      } else {
        // 4. If Worker: Submit Join Request using invite code
        const code = (data.teamInviteCode || '').trim().toUpperCase();

        if (supabase) {
          try {
            const { data: rpcRes, error: rpcErr } = await supabase.rpc('rpc_submit_join_request', {
              p_invite_code: code
            });
            if (rpcErr) {
              return { success: false, error: rpcErr.message };
            }
            if (!rpcRes.success) {
              return { success: false, error: rpcRes.error };
            }
          } catch (e) {
            console.warn('RPC submit_join_request fallback to local:', e);
          }
        }

        // Local simulated join request
        const targetWs = currentWorkspace && currentWorkspace.invite_code === code 
          ? currentWorkspace 
          : null;

        const req: JoinRequest = {
          id: `req-${Date.now()}`,
          workspace_id: targetWs ? targetWs.id : 'ws-external',
          user_id: newProfile.id,
          invite_code_used: code,
          user_name: newProfile.name,
          user_phone: newProfile.phone,
          user_whatsapp: newProfile.whatsapp_number,
          status: 'pending',
          created_at: new Date().toISOString(),
        };

        setJoinRequests(prev => [req, ...prev]);

        showToast(`تم إرسال طلب انضمامك يا ${newProfile.name}. بانتظار موافقة مدير المحطة.`, 'info');
        return { success: true };
      }
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const loginWithCredentials = async (phone: string, password?: string) => {
    try {
      const cleanPhone = cleanPhoneNumber(phone);
      const syntheticEmail = phoneToEmail(cleanPhone);
      const supabase = getSupabaseClient();

      if (supabase && password) {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: syntheticEmail,
          password,
        });

        if (error) {
          return { success: false, error: 'رقم الهاتف أو كلمة المرور غير صحيحة' };
        }

        if (data.user) {
          // Fetch real profile
          const { data: prof } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', data.user.id)
            .maybeSingle();

          if (prof) {
            setCurrentUser(prof);
          } else {
            setCurrentUser({
              id: data.user.id,
              phone: cleanPhone,
              whatsapp_number: data.user.user_metadata?.whatsapp_number || cleanPhone,
              name: data.user.user_metadata?.name || 'مستخدم محطة الاتحادية',
              created_at: new Date().toISOString(),
            });
          }

          // Fetch member workspace
          const { data: mem } = await supabase
            .from('workspace_members')
            .select('*, workspaces(*)')
            .eq('user_id', data.user.id)
            .eq('status', 'active')
            .maybeSingle();

          const wsData = Array.isArray(mem?.workspaces) ? mem?.workspaces[0] : mem?.workspaces;
          if (wsData) {
            setCurrentWorkspace(wsData);
            await loadWorkspaceFromCloud(wsData.id, data.user.id);
          }

          showToast('تم تسجيل الدخول بنجاح عبر السحابة', 'success');
          return { success: true };
        }
      }

      // Offline / Local lookup fallback
      const member = workspaceMembers.find(m => m.profile?.phone === cleanPhone);
      if (member && member.profile) {
        setCurrentUser(member.profile);
        showToast(`مرحباً بعودتك يا ${member.profile.name}`, 'success');
        return { success: true };
      }

      // Existing local user
      if (currentUser && currentUser.phone === cleanPhone) {
        showToast(`مرحباً بعودتك يا ${currentUser.name}`, 'success');
        return { success: true };
      }

      return { 
        success: false, 
        error: 'لم يتم العثور على حساب بهذا الهاتف. يرجى الضغط على "إنشاء حساب جديد كمدير" أولاً.' 
      };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const logout = () => {
    const supabase = getSupabaseClient();
    if (supabase) {
      if (realtimeChannelRef.current) {
        supabase.removeChannel(realtimeChannelRef.current);
        realtimeChannelRef.current = null;
      }
      supabase.auth.signOut().catch(() => {});
    }
    setCurrentUser(null);
    localStorage.removeItem('aman_user');
    showToast('تم تسجيل الخروج بنجاح', 'info');
  };

  // ============================================================================
  // WORKSPACE JOIN APPROVAL & CODE RENEWAL
  // ============================================================================

  const approveJoinRequest = async (requestId: string) => {
    const req = joinRequests.find(r => r.id === requestId);
    if (!req) return { success: false, error: 'الطلب غير موجود' };

    const supabase = getSupabaseClient();
    if (supabase) {
      try {
        const { data: rpcRes, error: rpcErr } = await supabase.rpc('rpc_approve_join_request', { p_request_id: requestId });
        if (rpcErr || (rpcRes && !rpcRes.success)) {
          showToast(rpcErr?.message || rpcRes?.error || 'تعذر مزامنة الموافقة مع السحابة', 'error');
        }
      } catch (e) {
        console.warn('RPC approve_join_request fallback:', e);
        showToast('تعذر الاتصال بالسحابة، تم اعتماد الطلب محلياً', 'error');
      }
    }

    setJoinRequests(prev => prev.map(r => r.id === requestId ? { ...r, status: 'approved' } : r));

    // Add to members
    const newMember: WorkspaceMember = {
      workspace_id: req.workspace_id,
      user_id: req.user_id,
      role: 'worker',
      status: 'active',
      joined_at: new Date().toISOString(),
      profile: {
        id: req.user_id,
        phone: req.user_phone,
        whatsapp_number: req.user_whatsapp,
        name: req.user_name,
        created_at: new Date().toISOString(),
      }
    };

    setWorkspaceMembers(prev => [...prev.filter(m => m.user_id !== req.user_id), newMember]);
    showToast(`تمت الموافقة على انضمام العامل "${req.user_name}" بنجاح`, 'success');
    return { success: true };
  };

  const rejectJoinRequest = async (requestId: string) => {
    const supabase = getSupabaseClient();
    if (supabase) {
      try {
        const { data: rpcRes, error: rpcErr } = await supabase.rpc('rpc_reject_join_request', { p_request_id: requestId });
        if (rpcErr || (rpcRes && !rpcRes.success)) {
          showToast(rpcErr?.message || rpcRes?.error || 'تعذر مزامنة الرفض مع السحابة', 'error');
        }
      } catch (e) {
        console.warn('RPC reject_join_request fallback:', e);
        showToast('تعذر الاتصال بالسحابة، تم الرفض محلياً', 'error');
      }
    }

    setJoinRequests(prev => prev.map(r => r.id === requestId ? { ...r, status: 'rejected' } : r));
    showToast('تم رفض طلب الانضمام', 'info');
    return { success: true };
  };

  const renewInviteCode = async (): Promise<string> => {
    if (!currentWorkspace) return '';
    let newCode = generateInviteCode();

    const supabase = getSupabaseClient();
    if (supabase) {
      try {
        const { data: rpcRes, error: rpcErr } = await supabase.rpc('rpc_renew_invite_code', { p_workspace_id: currentWorkspace.id });
        if (rpcErr || (rpcRes && !rpcRes.success)) {
          showToast(rpcErr?.message || rpcRes?.error || 'تعذر تجديد الرمز في السحابة', 'error');
        } else if (rpcRes?.invite_code) {
          newCode = rpcRes.invite_code;
        }
      } catch (e) {
        console.warn('RPC renew_invite_code fallback:', e);
        showToast('تعذر الاتصال بالسحابة، تم تجديد الرمز محلياً', 'error');
      }
    }

    const updatedWs = { ...currentWorkspace, invite_code: newCode };
    setCurrentWorkspace(updatedWs);
    showToast('تم تجديد رمز الدعوة بنجاح', 'success');
    return newCode;
  };

  // ============================================================================
  // ADMIN-TO-ADMIN COLLABORATIONS & OPTIONAL SHARING
  // ============================================================================

  const sendCollaborationRequest = async (targetShortId: string) => {
    if (!currentWorkspace) return { success: false, error: 'لا توجد مساحة عمل نشطة' };
    const cleanId = targetShortId.trim().toUpperCase();

    if (cleanId === currentWorkspace.short_id) {
      return { success: false, error: 'لا يمكنك إرسال طلب تعاون لمساحة عملك الخاصة' };
    }

    let cloudCollab: WorkspaceCollaboration | null = null;
    const supabase = getSupabaseClient();
    if (supabase) {
      try {
        const { data, error } = await supabase.rpc('rpc_send_collaboration_request', {
          p_target_short_id: cleanId
        });
        if (error) return { success: false, error: error.message };
        if (!data.success) return { success: false, error: data.error };
        if (data.collaboration) {
          cloudCollab = data.collaboration as WorkspaceCollaboration;
        }
      } catch (e) {
        console.warn('RPC send_collaboration_request fallback:', e);
        showToast('تعذر الاتصال بالسحابة، تم حفظ طلب التعاون محلياً', 'error');
      }
    }

    const newCollab: WorkspaceCollaboration = cloudCollab || {
      id: `collab-${Date.now()}`,
      requester_workspace_id: currentWorkspace.id,
      target_workspace_id: `ws-target-${cleanId}`,
      target_workspace_short_id: cleanId,
      requester_workspace_name: currentWorkspace.name,
      target_workspace_name: `إدارة مساحة العمل [${cleanId}]`,
      status: 'pending',
      requester_share_cash: false,
      requester_share_parcels: false,
      requester_share_reports: false,
      target_share_cash: false,
      target_share_parcels: false,
      target_share_reports: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    setCollaborations(prev => [newCollab, ...prev]);
    return { 
      success: true, 
      message: `تم إرسال طلب التعاون إلى مساحة العمل [${cleanId}] بنجاح، بانتظار قبول الطرف الآخر.` 
    };
  };

  const respondToCollaboration = async (collabId: string, accept: boolean) => {
    const supabase = getSupabaseClient();
    if (supabase) {
      try {
        const { data: rpcRes, error: rpcErr } = await supabase.rpc('rpc_respond_to_collaboration', {
          p_collab_id: collabId,
          p_accept: accept
        });
        if (rpcErr || (rpcRes && !rpcRes.success)) {
          showToast(rpcErr?.message || rpcRes?.error || 'تعذر مزامنة قرار الشراكة مع السحابة', 'error');
        }
      } catch (e) {
        console.warn('RPC respond_to_collaboration fallback:', e);
        showToast('تعذر الاتصال بالسحابة، تم تحديث الشراكة محلياً', 'error');
      }
    }

    setCollaborations(prev => prev.map(c => {
      if (c.id === collabId) {
        return {
          ...c,
          status: accept ? 'accepted' : 'rejected',
          updated_at: new Date().toISOString()
        };
      }
      return c;
    }));

    showToast(
      accept 
        ? 'تم قبول الشراكة بنجاح! يمكنك الآن اختيار ما تود مشاركته بشكل اختياري.' 
        : 'تم رفض طلب الشراكة',
      accept ? 'success' : 'info'
    );
    return { success: true };
  };

  const updateSharingSettings = async (
    collabId: string,
    shareCash: boolean,
    shareParcels: boolean,
    shareReports: boolean
  ) => {
    const supabase = getSupabaseClient();
    if (supabase) {
      try {
        const { data: rpcRes, error: rpcErr } = await supabase.rpc('rpc_update_sharing_settings', {
          p_collab_id: collabId,
          p_share_cash: shareCash,
          p_share_parcels: shareParcels,
          p_share_reports: shareReports
        });
        if (rpcErr || (rpcRes && !rpcRes.success)) {
          showToast(rpcErr?.message || rpcRes?.error || 'تعذر مزامنة إعدادات المشاركة مع السحابة', 'error');
        }
      } catch (e) {
        console.warn('RPC update_sharing_settings fallback:', e);
        showToast('تعذر الاتصال بالسحابة، تم تحديث إعدادات المشاركة محلياً', 'error');
      }
    }

    setCollaborations(prev => prev.map(c => {
      if (c.id === collabId) {
        const isRequester = c.requester_workspace_id === currentWorkspace?.id;
        return {
          ...c,
          requester_share_cash: isRequester ? shareCash : c.requester_share_cash,
          requester_share_parcels: isRequester ? shareParcels : c.requester_share_parcels,
          requester_share_reports: isRequester ? shareReports : c.requester_share_reports,
          target_share_cash: !isRequester ? shareCash : c.target_share_cash,
          target_share_parcels: !isRequester ? shareParcels : c.target_share_parcels,
          target_share_reports: !isRequester ? shareReports : c.target_share_reports,
          updated_at: new Date().toISOString()
        };
      }
      return c;
    }));

    showToast('تم تحديث إعدادات المشاركة بنجاح. التحكم فوري ومستقل.', 'success');
    return { success: true };
  };

  // Check if any demo records exist
  const hasDemoData = useMemo(() => {
    return (
      stations.some(s => s.is_demo) ||
      workspaceMembers.some(m => m.is_demo) ||
      stationWorkers.some(sw => sw.is_demo) ||
      allParcels.some(p => p.is_demo) ||
      allTrips.some(t => t.is_demo) ||
      allTransactions.some(tx => tx.is_demo)
    );
  }, [stations, workspaceMembers, stationWorkers, allParcels, allTrips, allTransactions]);

  // Delete ONLY demo records (is_demo === true) and nothing else
  const deleteDemoData = () => {
    if (currentWorkspace) {
      localStorage.setItem(`ittihadiya_demo_deleted_${currentWorkspace.id}`, 'true');
    }
    setStations(prev => {
      const remaining = prev.filter(s => !s.is_demo);
      setSelectedStationId(remaining[0]?.id || null);
      return remaining;
    });
    setWorkspaceMembers(prev => prev.filter(m => !m.is_demo));
    setStationWorkers(prev => prev.filter(sw => !sw.is_demo));
    setAllParcels(prev => prev.filter(p => !p.is_demo));
    setAllTrips(prev => prev.filter(t => !t.is_demo));
    setAllTransactions(prev => prev.filter(tx => !tx.is_demo));
    setAuditLogs(prev => prev.filter(a => !a.is_demo));
    showToast('تم حذف جميع البيانات التجريبية بنجاح وأصبح التطبيق فارغاً تماماً', 'success');
  };

  // Reset Data to 0
  const resetAllDataToZero = () => {
    setAllTransactions([]);
    setAllParcels([]);
    setAllTrips([]);
    setAuditLogs([]);
    localStorage.removeItem('aman_transactions');
    localStorage.removeItem('ittihadiya_parcels');
    storageService.remove('TRIPS');
    localStorage.removeItem('aman_audit_logs');
    showToast('تمت إعادة ضبط كافة الأرصدة والكوليات والرحلات إلى 0 بنجاح', 'info');
  };

  // Add Worker by Owner
  const addWorkerByOwner = async (name: string, phone: string, stationId: string, role: UserRole = 'worker') => {
    if (!currentWorkspace) return { success: false, error: 'لا توجد مساحة عمل نشطة' };

    const newWorkerProfile: Profile = {
      id: `usr-worker-${Date.now()}`,
      name: name.trim(),
      phone: phone.trim(),
      whatsapp_number: phone.trim(),
      created_at: new Date().toISOString(),
    };

    const newMember: WorkspaceMember = {
      workspace_id: currentWorkspace.id,
      user_id: newWorkerProfile.id,
      role: role === 'owner' ? 'admin' : 'worker',
      status: 'active',
      joined_at: new Date().toISOString(),
      profile: newWorkerProfile,
    };

    setWorkspaceMembers(prev => [...prev, newMember]);

    setStationWorkers(prev => [
      ...prev.filter(sw => sw.user_id !== newWorkerProfile.id),
      {
        station_id: stationId,
        workspace_id: currentWorkspace.id,
        user_id: newWorkerProfile.id,
        assigned_at: new Date().toISOString(),
        profile: newWorkerProfile,
      }
    ]);

    showToast(`تمت إضافة الموظف "${newWorkerProfile.name}" وتعيينه بالمحطة بنجاح`, 'success');
    return { success: true };
  };

  // Create Transaction
  const createTransaction = async (data: {
    station_id: string;
    type: TransactionType;
    amount: number;
    currency: string;
    phone_number?: string;
    reason?: string;
    photo_url?: string;
    note?: string;
    parcel_id?: string;
  }) => {
    if (!currentUser) return { success: false, error: 'يرجى تسجيل الدخول أولاً' };

    const st = stations.find(s => s.id === data.station_id);
    const wsId = currentWorkspace?.id || 'ws-default';
    const txId = isSupabaseConfigured()
      ? generateUUID()
      : `tx-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;

    const newTx: Transaction = {
      id: txId,
      workspace_id: wsId,
      team_id: wsId,
      station_id: data.station_id,
      created_by: currentUser.id,
      type: data.type,
      amount: Math.round(Number(data.amount) * 100) / 100,
      currency: data.currency,
      phone_number: data.phone_number?.trim() || null,
      reason: data.reason?.trim() || null,
      photo_url: data.photo_url || null,
      note: data.note?.trim() || null,
      parcel_id: data.parcel_id || null,
      status: 'confirmed',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      station_name: st?.name || 'محطة الاتحادية',
      creator_name: currentUser.name,
    };

    const audit: AuditLogEntry = {
      id: isSupabaseConfigured() ? generateUUID() : `audit-${Date.now()}`,
      workspace_id: wsId,
      team_id: wsId,
      user_id: currentUser.id,
      user_name: currentUser.name,
      action: 'INSERT',
      table_name: 'transactions',
      record_id: newTx.id,
      old_data: null,
      new_data: newTx,
      created_at: new Date().toISOString(),
    };

    setAllTransactions(prev => [newTx, ...prev]);
    setAuditLogs(prev => [audit, ...prev]);

    if (isSupabaseConfigured()) {
      const synced = await cashService.syncTransactionAndAuditToCloud(
        newTx,
        audit,
        (msg: string) => showToast(msg, 'error')
      );
      if (!synced) {
        setAllTransactions(prev => prev.map(t => t.id === newTx.id ? { ...t, pending_sync: true } : t));
      } else {
        const nextTxs = [newTx, ...allTransactions];
        const balances = cashService.calculateStationBalances(stations, nextTxs);
        const curr = newTx.currency === 'MRU' ? 'MRU' : 'MAD';
        const bal = balances[newTx.station_id]?.[curr] ?? 0;
        await cashService.syncStationBalanceToCloud(newTx.station_id, wsId, curr, bal);
      }
    }

    showToast(`تم تسجيل السند بنجاح بمبلغ ${newTx.amount} ${newTx.currency}`, 'success');
    return { success: true, transaction: newTx };
  };

  const updateTransaction = async (id: string, updates: Partial<Transaction>, editReason?: string) => {
    if (userRole !== 'owner') return { success: false, error: 'صلاحية التعديل للمدير المشرف فقط' };

    const currentTx = allTransactions.find(t => t.id === id);
    if (!currentTx) return { success: false, error: 'السند غير موجود' };

    const writtenReason = editReason?.trim() || 'تعديل بيانات السند المالي';
    const editEntry = {
      edited_at: new Date().toISOString(),
      edited_by_id: currentUser?.id || 'owner',
      edited_by_name: currentUser?.name || 'المدير العام',
      reason: writtenReason,
      action: 'UPDATE' as const,
      previous_data: {
        amount: currentTx.amount,
        reason: currentTx.reason,
        phone_number: currentTx.phone_number,
        note: currentTx.note
      }
    };

    const updated: Transaction = { 
      ...currentTx, 
      ...updates, 
      edit_history: [...(currentTx.edit_history || []), editEntry],
      updated_at: new Date().toISOString() 
    };
    const nextTxs = allTransactions.map(t => t.id === id ? updated : t);
    setAllTransactions(nextTxs);

    const audit: AuditLogEntry = {
      id: isSupabaseConfigured() ? generateUUID() : `audit-${Date.now()}`,
      workspace_id: currentTx.workspace_id,
      team_id: currentTx.workspace_id,
      user_id: currentUser?.id || null,
      user_name: currentUser?.name || 'المدير العام',
      action: 'UPDATE',
      table_name: 'transactions',
      record_id: updated.id,
      old_data: currentTx,
      new_data: updated,
      created_at: new Date().toISOString(),
    };
    setAuditLogs(prev => [audit, ...prev]);

    if (isSupabaseConfigured()) {
      const synced = await cashService.syncTransactionAndAuditToCloud(
        updated,
        audit,
        (msg: string) => showToast(msg, 'error')
      );
      if (!synced) {
        setAllTransactions(prev => prev.map(t => t.id === id ? { ...t, pending_sync: true } : t));
      } else {
        const balances = cashService.calculateStationBalances(stations, nextTxs);
        const curr = updated.currency === 'MRU' ? 'MRU' : 'MAD';
        const bal = balances[updated.station_id]?.[curr] ?? 0;
        await cashService.syncStationBalanceToCloud(updated.station_id, updated.workspace_id, curr, bal);
      }
    }

    showToast('تم تعديل السند وتوثيق سجل المراجعة بنجاح', 'success');
    return { success: true };
  };

  const cancelTransaction = async (id: string, reason: string) => {
    if (userRole !== 'owner') return { success: false, error: 'صلاحية إلغاء السندات للمشرف فقط' };

    const currentTx = allTransactions.find(t => t.id === id);
    if (!currentTx) return { success: false, error: 'السند غير موجود' };

    const writtenReason = reason.trim() || 'إلغاء السند وإرجاع المبلغ للصندوق';
    const cancelEntry = {
      edited_at: new Date().toISOString(),
      edited_by_id: currentUser?.id || 'owner',
      edited_by_name: currentUser?.name || 'المدير العام',
      reason: writtenReason,
      action: 'CANCEL' as const,
      previous_data: {
        amount: currentTx.amount,
        status: currentTx.status
      }
    };

    const updated: Transaction = { 
      ...currentTx, 
      status: 'cancelled' as const, 
      cancelled_by_name: currentUser?.name || 'المدير العام',
      cancelled_at: new Date().toISOString(),
      cancel_reason: writtenReason,
      edit_history: [...(currentTx.edit_history || []), cancelEntry],
      note: `${currentTx.note ? currentTx.note + ' | ' : ''}[تم الإلغاء: ${writtenReason}]`,
      updated_at: new Date().toISOString() 
    };
    const nextTxs = allTransactions.map(t => t.id === id ? updated : t);
    setAllTransactions(nextTxs);

    const audit: AuditLogEntry = {
      id: isSupabaseConfigured() ? generateUUID() : `audit-${Date.now()}`,
      workspace_id: currentTx.workspace_id,
      team_id: currentTx.workspace_id,
      user_id: currentUser?.id || null,
      user_name: currentUser?.name || 'المدير العام',
      action: 'CANCEL',
      table_name: 'transactions',
      record_id: updated.id,
      old_data: currentTx,
      new_data: updated,
      created_at: new Date().toISOString(),
    };
    setAuditLogs(prev => [audit, ...prev]);

    if (isSupabaseConfigured()) {
      const synced = await cashService.syncTransactionAndAuditToCloud(
        updated,
        audit,
        (msg: string) => showToast(msg, 'error')
      );
      if (!synced) {
        setAllTransactions(prev => prev.map(t => t.id === id ? { ...t, pending_sync: true } : t));
      } else {
        const balances = cashService.calculateStationBalances(stations, nextTxs);
        const curr = updated.currency === 'MRU' ? 'MRU' : 'MAD';
        const bal = balances[updated.station_id]?.[curr] ?? 0;
        await cashService.syncStationBalanceToCloud(updated.station_id, updated.workspace_id, curr, bal);
      }
    }

    showToast('تم إلغاء السند وتحديث رصيد الصندوق وتوثيق السبب', 'info');
    return { success: true };
  };

  // Create Parcel
  const createParcel = async (data: {
    origin_station_id: string;
    destination_station_id: string;
    sender_name: string;
    sender_phone: string;
    receiver_name: string;
    receiver_phone: string;
    route?: string;
    description: string;
    category?: string;
    items_count?: number;
    weight_kg?: number;
    declared_value?: number;
    amount_due?: number;
    shipping_fee?: number;
    payer?: ParcelPayer;
    amount_paid?: number;
    cod_amount?: number;
    currency: string;
    payment_status?: PaymentStatus;
    notes?: string;
    condition?: ParcelCondition;
    condition_notes?: string;
  }) => {
    if (!currentUser) return { success: false, error: 'يرجى تسجيل الدخول أولاً' };

    const originSt = stations.find(s => s.id === data.origin_station_id);
    const destSt = stations.find(s => s.id === data.destination_station_id);
    const wsId = currentWorkspace?.id || 'ws-default';

    let parcelNumber: number;
    let tracking_code: string;
    const codeNumber = Math.floor(1000 + Math.random() * 9000);

    if (isSupabaseConfigured()) {
      const seq = await parcelService.getNextParcelNumberAsync(wsId, allParcels);
      parcelNumber = seq.parcelNumber;
      tracking_code = seq.trackingCode;
    } else {
      parcelNumber = allParcels.filter(p => p.workspace_id === wsId).length + 1;
      tracking_code = `ITT-${new Date().getFullYear()}-${codeNumber}`;
    }

    const amountDue = Math.round(Number(data.amount_due ?? data.shipping_fee ?? 0) * 100) / 100;
    const amountPaid = Math.round(Number(data.amount_paid ?? (data.payment_status === 'paid' ? amountDue : 0)) * 100) / 100;
    const payer: ParcelPayer = data.payer || (data.payment_status === 'cod' ? 'receiver' : 'sender');
    const parcelStatus: ParcelStatus = 'registered';
    const condition: ParcelCondition = data.condition || 'normal';
    const conditionNotes = condition === 'abnormal' ? (data.condition_notes?.trim() || null) : null;

    const newParcel: Parcel = {
      id: isSupabaseConfigured() ? generateUUID() : `pcl-${Date.now()}-${codeNumber}`,
      tracking_code,
      parcel_number: parcelNumber,
      workspace_id: wsId,
      team_id: wsId,
      origin_station_id: data.origin_station_id,
      destination_station_id: data.destination_station_id,
      origin_station_name: originSt?.name || 'محطة الانطلاق',
      destination_station_name: destSt?.name || 'محطة الوصول',
      sender_name: data.sender_name.trim(),
      sender_phone: data.sender_phone.trim(),
      receiver_name: data.receiver_name.trim(),
      receiver_phone: data.receiver_phone.trim(),
      route: (data.route || '').trim() || `${originSt?.city} ➔ الكركرات ➔ ${destSt?.city}`,
      description: data.description.trim(),
      category: data.category || 'طرد بضائع',
      items_count: Number(data.items_count) || 1,
      weight_kg: data.weight_kg ? Number(data.weight_kg) : undefined,
      declared_value: data.declared_value ? Number(data.declared_value) : undefined,
      amount_due: amountDue,
      shipping_fee: amountDue,
      payer,
      amount_paid: amountPaid,
      cod_amount: data.cod_amount ? Math.round(Number(data.cod_amount) * 100) / 100 : 0,
      currency: data.currency || 'MAD',
      status: parcelStatus,
      condition,
      condition_notes: conditionNotes,
      payment_status: amountPaid >= amountDue ? 'paid' : (amountPaid > 0 ? 'partial' : 'unpaid'),
      status_history: [
        {
          status: parcelStatus,
          timestamp: new Date().toISOString(),
          changed_by_id: currentUser.id,
          changed_by_name: currentUser.name,
          notes: 'تسجيل الكولي في المحطة',
          condition,
          condition_notes: conditionNotes || undefined
        }
      ],
      payment_history: amountPaid > 0 ? [
        {
          id: `pay-${Date.now()}`,
          amount: amountPaid,
          currency: data.currency || 'MAD',
          paid_by: payer === 'sender' ? data.sender_name.trim() : data.receiver_name.trim(),
          recorded_by_id: currentUser.id,
          recorded_by_name: currentUser.name,
          recorded_at: new Date().toISOString(),
          note: 'الدفعة الأولى عند التسجيل'
        }
      ] : [],
      created_by: currentUser.id,
      creator_name: currentUser.name,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      notes: data.notes?.trim() || null,
    };

    setAllParcels(prev => [newParcel, ...prev]);

    if (isSupabaseConfigured()) {
      const synced = await parcelService.syncParcelToCloud(
        newParcel,
        (msg: string) => showToast(msg, 'error')
      );
      if (!synced) {
        setAllParcels(prev => prev.map(p => p.id === newParcel.id ? { ...p, pending_sync: true } : p));
      }
    }

    if (amountPaid > 0) {
      await createTransaction({
        station_id: newParcel.origin_station_id,
        type: 'parcel_shipping_fee',
        amount: amountPaid,
        currency: newParcel.currency,
        phone_number: newParcel.sender_phone,
        reason: `أجرة شحن الكولي [${newParcel.tracking_code}] إلى ${destSt?.city}`,
        note: `شحن ${newParcel.items_count} طرد - ${newParcel.description}`,
        parcel_id: newParcel.id,
      });
    }

    showToast(`تم تسجيل الإرسالية [${tracking_code}] بنجاح`, 'success');
    return { success: true, parcel: newParcel };
  };

  const updateParcelStatus = async (
    id: string, 
    status: ParcelStatus, 
    notesOrMeta?: { delivered_to?: string; notes?: string; condition?: ParcelCondition; condition_notes?: string } | string,
    deliveredTo?: string
  ) => {
    const parcel = allParcels.find(p => p.id === id);
    if (!parcel) return { success: false, error: 'الكولي غير موجود' };

    const noteText = typeof notesOrMeta === 'string' ? notesOrMeta : notesOrMeta?.notes;
    const deliveredPerson = typeof notesOrMeta === 'object' ? notesOrMeta?.delivered_to : deliveredTo;
    const metaCondition = typeof notesOrMeta === 'object' ? notesOrMeta?.condition : undefined;
    const metaConditionNotes = typeof notesOrMeta === 'object' ? notesOrMeta?.condition_notes : undefined;

    const finalCondition: ParcelCondition = metaCondition || parcel.condition || 'normal';
    const finalConditionNotes = metaCondition === 'abnormal' 
      ? (metaConditionNotes || parcel.condition_notes) 
      : (metaCondition === 'normal' ? null : parcel.condition_notes);

    const newHistoryEntry: ParcelStatusHistoryEntry = {
      status,
      timestamp: new Date().toISOString(),
      changed_by_id: currentUser?.id || 'sys',
      changed_by_name: currentUser?.name || 'المستخدم',
      notes: noteText || undefined,
      condition: finalCondition,
      condition_notes: finalCondition === 'abnormal' ? (finalConditionNotes || undefined) : undefined,
    };

    const updated: Parcel = {
      ...parcel,
      status,
      condition: finalCondition,
      condition_notes: finalConditionNotes,
      updated_at: new Date().toISOString(),
      notes: noteText ? `${parcel.notes || ''} [${noteText}]` : parcel.notes,
      status_history: [...(parcel.status_history || []), newHistoryEntry],
    };

    if (status === 'delivered') {
      updated.delivered_at = new Date().toISOString();
      updated.delivered_to = deliveredPerson || parcel.receiver_name;

      const codAmount = parcel.cod_amount ?? 0;
      if (codAmount > 0) {
        await createTransaction({
          station_id: parcel.destination_station_id,
          type: 'parcel_cod_collection',
          amount: codAmount,
          currency: parcel.currency,
          phone_number: parcel.receiver_phone,
          reason: `تحصيل مبلغ COD للكولي [${parcel.tracking_code}] من المستلم`,
          note: `المستلم: ${updated.delivered_to}`,
          parcel_id: parcel.id,
        });
      }
    }

    setAllParcels(prev => prev.map(p => p.id === id ? updated : p));

    if (isSupabaseConfigured()) {
      const synced = await parcelService.syncParcelToCloud(
        updated,
        (msg: string) => showToast(msg, 'error')
      );
      if (!synced) {
        setAllParcels(prev => prev.map(p => p.id === id ? { ...p, pending_sync: true } : p));
      }
    }

    showToast(`تم تحديث حالة الكولي [${parcel.tracking_code}] إلى "${status}"`, 'success');
    return { success: true };
  };

  const recordParcelPayment = async (
    parcelId: string, 
    amount: number, 
    paidBy: string, 
    note?: string
  ) => {
    const parcel = allParcels.find(p => p.id === parcelId);
    if (!parcel) return { success: false, error: 'الكولي غير موجود' };

    const paymentAmount = Math.round(Number(amount) * 100) / 100;
    const newAmountPaid = Math.round(((parcel.amount_paid || 0) + paymentAmount) * 100) / 100;
    const newPaymentEntry: ParcelPaymentEntry = {
      id: `pay-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      amount: paymentAmount,
      currency: parcel.currency,
      paid_by: paidBy.trim() || 'العميل',
      recorded_by_id: currentUser?.id || 'sys',
      recorded_by_name: currentUser?.name || 'المستخدم',
      recorded_at: new Date().toISOString(),
      note: note?.trim(),
    };

    const newPaymentStatus: PaymentStatus = newAmountPaid >= parcel.amount_due ? 'paid' : (newAmountPaid > 0 ? 'partial' : 'unpaid');

    const updated: Parcel = {
      ...parcel,
      amount_paid: newAmountPaid,
      payment_status: newPaymentStatus,
      payment_history: [...(parcel.payment_history || []), newPaymentEntry],
      updated_at: new Date().toISOString(),
    };

    setAllParcels(prev => prev.map(p => p.id === parcelId ? updated : p));

    if (isSupabaseConfigured()) {
      const synced = await parcelService.syncParcelToCloud(
        updated,
        (msg: string) => showToast(msg, 'error')
      );
      if (!synced) {
        setAllParcels(prev => prev.map(p => p.id === parcelId ? { ...p, pending_sync: true } : p));
      }
    }

    await createTransaction({
      station_id: parcel.origin_station_id,
      type: 'parcel_shipping_fee',
      amount: paymentAmount,
      currency: parcel.currency,
      phone_number: parcel.payer === 'sender' ? parcel.sender_phone : parcel.receiver_phone,
      reason: `دفعة شحن للكولي [${parcel.tracking_code}] من ${paidBy}`,
      note: note || `سداد جزئي/كلي للكولي`,
      parcel_id: parcel.id,
    });

    return { success: true };
  };

  const updateParcel = async (id: string, updates: Partial<Parcel>) => {
    const parcel = allParcels.find(p => p.id === id);
    if (!parcel) return { success: false, error: 'الكولي غير موجود' };

    const updated = { ...parcel, ...updates, updated_at: new Date().toISOString() };
    setAllParcels(prev => prev.map(p => p.id === id ? updated : p));

    if (isSupabaseConfigured()) {
      const synced = await parcelService.syncParcelToCloud(
        updated,
        (msg: string) => showToast(msg, 'error')
      );
      if (!synced) {
        setAllParcels(prev => prev.map(p => p.id === id ? { ...p, pending_sync: true } : p));
      }
    }

    showToast('تم تعديل بيانات الإرسالية بنجاح', 'success');
    return { success: true };
  };

  const getParcelByTrackingCode = (code: string): Parcel | undefined => {
    if (!code) return undefined;
    const clean = code.trim().toUpperCase();
    return parcels.find(p => p.tracking_code.toUpperCase() === clean);
  };

  // ============================================================================
  // TRIPS & DISPATCH MODULE (إدارة رحلات الشحن والتفريغ بين المحطات)
  // ============================================================================

  const createTrip = async (params: {
    driverName: string;
    driverPhone?: string;
    vehiclePlate: string;
    originStationId: string;
    destinationStationId: string;
    notes?: string;
  }): Promise<{ success: boolean; error?: string; trip?: Trip }> => {
    if (!currentWorkspace || !currentUser) {
      return { success: false, error: 'غير مسجل الدخول' };
    }
    const originSt = stations.find(s => s.id === params.originStationId);
    const destSt = stations.find(s => s.id === params.destinationStationId);

    const res = tripService.createTrip(
      {
        workspaceId: currentWorkspace.id,
        driverName: params.driverName,
        driverPhone: params.driverPhone,
        vehiclePlate: params.vehiclePlate,
        originStationId: params.originStationId,
        destinationStationId: params.destinationStationId,
        originStationName: originSt?.name,
        destinationStationName: destSt?.name,
        notes: params.notes,
        userId: currentUser.id,
        userName: currentUser.name,
        onErrorToast: (msg: string) => showToast(msg, 'error')
      },
      allTrips
    );

    setAllTrips(res.updatedList);
    setRememberedDrivers(tripService.getRememberedDrivers());
    setRememberedPlates(tripService.getRememberedPlates());
    showToast(`تم إنشاء الرحلة [${res.trip.trip_code}] بنجاح`, 'success');
    return { success: true, trip: res.trip };
  };

  const loadParcelToTrip = async (
    tripId: string,
    parcelIdentifier: string
  ): Promise<{ success: boolean; error?: string; warning?: string; trip?: Trip; parcel?: Parcel }> => {
    if (!currentUser) return { success: false, error: 'غير مسجل الدخول' };

    const res = tripService.loadParcelToTrip(
      tripId,
      parcelIdentifier,
      { id: currentUser.id, name: currentUser.name },
      allTrips,
      allParcels,
      userAssignedStationId || undefined,
      (msg: string) => showToast(msg, 'error')
    );

    if (res.success) {
      setAllTrips(res.updatedTrips);
      setAllParcels(res.updatedParcels);
    }
    return {
      success: res.success,
      error: res.error,
      warning: res.warning,
      trip: res.trip,
      parcel: res.parcel
    };
  };

  const unloadParcelFromTrip = async (
    tripId: string,
    parcelId: string
  ): Promise<{ success: boolean; error?: string; trip?: Trip }> => {
    if (!currentUser) return { success: false, error: 'غير مسجل الدخول' };
    const res = tripService.unloadParcelFromTrip(
      tripId,
      parcelId,
      { id: currentUser.id, name: currentUser.name },
      allTrips,
      allParcels,
      (msg: string) => showToast(msg, 'error')
    );
    if (res.success) {
      setAllTrips(res.updatedTrips);
      setAllParcels(res.updatedParcels);
    }
    return { success: res.success, error: res.error, trip: res.trip };
  };

  const departTrip = async (
    tripId: string
  ): Promise<{ success: boolean; error?: string; trip?: Trip }> => {
    if (!currentUser) return { success: false, error: 'غير مسجل الدخول' };
    const res = tripService.departTrip(
      tripId,
      { id: currentUser.id, name: currentUser.name },
      allTrips,
      allParcels,
      (msg: string) => showToast(msg, 'error')
    );
    if (res.success) {
      setAllTrips(res.updatedTrips);
    }
    return { success: res.success, error: res.error, trip: res.trip };
  };

  const receiveParcelAtDestination = async (
    tripId: string,
    parcelIdentifier: string,
    condition: ParcelCondition,
    conditionNotes?: string
  ): Promise<{ success: boolean; error?: string; trip?: Trip; parcel?: Parcel; allScanned?: boolean }> => {
    if (!currentUser) return { success: false, error: 'غير مسجل الدخول' };
    const res = tripService.receiveParcelAtDestination(
      tripId,
      parcelIdentifier,
      condition,
      conditionNotes,
      { id: currentUser.id, name: currentUser.name },
      allTrips,
      allParcels,
      (msg: string) => showToast(msg, 'error')
    );
    if (res.success) {
      setAllTrips(res.updatedTrips);
      setAllParcels(res.updatedParcels);
    }
    return {
      success: res.success,
      error: res.error,
      trip: res.trip,
      parcel: res.parcel,
      allScanned: res.allScanned
    };
  };

  const closeTrip = async (
    tripId: string,
    closeReason?: string
  ): Promise<{ success: boolean; error?: string; trip?: Trip }> => {
    if (!currentUser) return { success: false, error: 'غير مسجل الدخول' };
    const res = tripService.closeTrip(
      tripId,
      { id: currentUser.id, name: currentUser.name },
      closeReason,
      allTrips,
      (msg: string) => showToast(msg, 'error')
    );
    if (res.success) {
      setAllTrips(res.updatedTrips);
    }
    return { success: res.success, error: res.error, trip: res.trip };
  };

  const addBalanceAdjustment = async (stationId: string, currency: string, amount: number, note: string) => {
    if (userRole !== 'owner') return { success: false, error: 'غير مصرح' };
    const st = stations.find(s => s.id === stationId);
    
    return await createTransaction({
      station_id: stationId,
      type: amount >= 0 ? 'cash_in' : 'cash_out',
      amount: Math.abs(amount),
      currency,
      reason: `تسوية رصيد الصندوق من المشرف (${st?.city})`,
      note: note || 'تسوية محاسبية',
    });
  };

  const createTeam = async (name: string) => {
    if (!currentUser) return { success: false, error: 'غير مسجل' };
    const supabase = getSupabaseClient();
    if (supabase) {
      try {
        const { data: rpcData, error: rpcErr } = await supabase.rpc('rpc_create_workspace', {
          p_name: name.trim()
        });
        if (!rpcErr && rpcData?.success && rpcData.workspace) {
          const newWs = rpcData.workspace as Workspace;
          setCurrentWorkspace(newWs);
          if (Array.isArray(rpcData.stations) && rpcData.stations.length > 0) {
            const cloudStations = rpcData.stations.map((s: any) => ({ ...s, team_id: s.workspace_id }));
            setStations(cloudStations);
            setSelectedStationId(cloudStations[0].id);
          }
          if (Array.isArray(rpcData.currencies) && rpcData.currencies.length > 0) {
            setCurrencies(rpcData.currencies.map((c: any) => ({ ...c, team_id: c.workspace_id })));
          }
          if (rpcData.subscription) {
            setSubscription({ ...rpcData.subscription, team_id: newWs.id });
          }
          setWorkspaceMembers([{
            workspace_id: newWs.id,
            user_id: currentUser.id,
            role: 'admin',
            status: 'active',
            joined_at: rpcData.member?.joined_at || new Date().toISOString(),
            profile: currentUser,
          }]);
          setStationWorkers([]);
          return { success: true };
        }
      } catch (e) {
        console.warn('createTeam RPC error, falling back to local:', e);
      }
    }

    const ws: Workspace = {
      id: `ws-${Date.now()}`,
      short_id: generateShortId(),
      name: name.trim(),
      invite_code: generateInviteCode(),
      created_by: currentUser.id,
      created_at: new Date().toISOString(),
    };
    setCurrentWorkspace(ws);

    const adminMember: WorkspaceMember = {
      workspace_id: ws.id,
      user_id: currentUser.id,
      role: 'admin',
      status: 'active',
      joined_at: new Date().toISOString(),
      profile: currentUser,
    };

    const initialWsCurrencies = getInitialCurrencies(ws.id);
    setCurrencies(initialWsCurrencies);

    if (DEMO_MODE && !isSupabaseConfigured()) {
      const demo = generateWorkspaceDemoData(ws.id, currentUser);
      setStations(demo.stations);
      setSelectedStationId(demo.stations[0]?.id || null);
      setWorkspaceMembers([adminMember, ...demo.members]);
      setStationWorkers(demo.stationWorkers);
      setAllParcels(prev => [...demo.parcels, ...prev.filter(p => p.workspace_id !== ws.id)]);
      setAllTrips(prev => [...demo.trips, ...prev.filter(t => t.workspace_id !== ws.id)]);
      setAllTransactions(prev => [...demo.transactions, ...prev.filter(tx => tx.workspace_id !== ws.id)]);
      localStorage.setItem(`ittihadiya_demo_seeded_${ws.id}`, 'true');
    } else {
      setWorkspaceMembers([adminMember]);
      setStationWorkers([]);
      const initialWsStations = getInitialStations(ws.id);
      setStations(initialWsStations);
      setSelectedStationId(initialWsStations[0].id);
    }

    return { success: true };
  };

  const joinTeam = async (inviteCode: string) => {
    if (!currentUser) return { success: false, error: 'غير مسجل' };
    if (currentWorkspace && currentWorkspace.invite_code === inviteCode.trim().toUpperCase()) {
      return { success: true };
    }
    return { success: false, error: 'رمز الدعوة غير صحيح' };
  };

  const addStation = async (name: string, city: string, country: 'MA' | 'MR' = 'MA', phone?: string, address?: string) => {
    const wsId = currentWorkspace?.id || 'ws-default';
    const newSt: Station = {
      id: isSupabaseConfigured() ? generateUUID() : `sta-${Date.now()}`,
      workspace_id: wsId,
      team_id: wsId,
      name: name.trim(),
      city: city.trim(),
      country,
      owner_id: currentUser?.id || null,
      phone: phone?.trim(),
      address: address?.trim(),
      is_active: true,
      created_at: new Date().toISOString(),
    };
    setStations(prev => [...prev, newSt]);

    const supabase = getSupabaseClient();
    if (supabase && isValidUUID(wsId)) {
      try {
        const { error } = await supabase.from('stations').upsert({
          id: newSt.id,
          workspace_id: wsId,
          name: newSt.name,
          city: newSt.city,
          country: newSt.country,
          phone: newSt.phone || null,
          address: newSt.address || null,
          is_active: true,
          owner_id: currentUser?.id && isValidUUID(currentUser.id) ? currentUser.id : null,
        });
        if (error) showToast(`تعذر حفظ المحطة في السحابة: ${error.message}`, 'error');
      } catch (e: any) {
        showToast('تعذر الاتصال بالسحابة، تم حفظ المحطة محلياً', 'error');
      }
    }

    showToast(`تمت إضافة محطة ${newSt.name} بنجاح`, 'success');
    return { success: true };
  };

  const assignWorkerToStation = async (stationId: string, userId: string) => {
    const wsId = currentWorkspace?.id || 'ws-default';
    setStationWorkers(prev => {
      const filtered = prev.filter(w => w.user_id !== userId);
      return [...filtered, { station_id: stationId, workspace_id: wsId, user_id: userId, assigned_at: new Date().toISOString() }];
    });

    const supabase = getSupabaseClient();
    if (supabase && isValidUUID(wsId) && isValidUUID(stationId) && isValidUUID(userId)) {
      try {
        await supabase.from('station_workers').delete().eq('workspace_id', wsId).eq('user_id', userId);
        const { error } = await supabase.from('station_workers').insert({
          station_id: stationId,
          workspace_id: wsId,
          user_id: userId,
        });
        if (error) showToast(`تعذر مزامنة تعيين الموظف مع السحابة: ${error.message}`, 'error');
      } catch {
        showToast('تعذر الاتصال بالسحابة، تم تعيين الموظف محلياً', 'error');
      }
    }

    showToast('تم تعيين الموظف بالمحطة بنجاح', 'success');
    return { success: true };
  };

  const removeWorkerFromTeam = async (userId: string) => {
    setWorkspaceMembers(prev => prev.filter(m => m.user_id !== userId));
    const wsId = currentWorkspace?.id || '';
    const supabase = getSupabaseClient();
    if (supabase && isValidUUID(wsId) && isValidUUID(userId)) {
      try {
        await supabase.from('station_workers').delete().eq('workspace_id', wsId).eq('user_id', userId);
        await supabase.from('workspace_members').delete().eq('workspace_id', wsId).eq('user_id', userId);
      } catch {
        showToast('تعذر الاتصال بالسحابة، تم الحذف محلياً', 'error');
      }
    }
    showToast('تم حذف الموظف من الفريق', 'info');
    return { success: true };
  };

  const addCurrency = async (code: string, label_ar: string, symbol: string, label_fr?: string, rate: number = 1.0) => {
    const wsId = currentWorkspace?.id || 'ws-default';
    const newCurr: Currency = {
      id: isSupabaseConfigured() ? generateUUID() : `curr-${Date.now()}`,
      workspace_id: wsId,
      team_id: wsId,
      code: code.trim().toUpperCase(),
      label_ar: label_ar.trim(),
      label_fr: label_fr?.trim() || code,
      symbol: symbol.trim(),
      is_active: true,
      rate_to_mad: rate,
      created_at: new Date().toISOString(),
    };
    setCurrencies(prev => [...prev, newCurr]);

    const supabase = getSupabaseClient();
    if (supabase && isValidUUID(wsId)) {
      try {
        const { error } = await supabase.from('currencies').upsert({
          id: newCurr.id,
          workspace_id: wsId,
          code: newCurr.code,
          label_ar: newCurr.label_ar,
          label_fr: newCurr.label_fr,
          symbol: newCurr.symbol,
          rate_to_mad: newCurr.rate_to_mad,
          is_active: true,
        }, { onConflict: 'workspace_id,code' });
        if (error) showToast(`تعذر حفظ العملة في السحابة: ${error.message}`, 'error');
      } catch {
        showToast('تعذر الاتصال بالسحابة، تم حفظ العملة محلياً', 'error');
      }
    }

    showToast(`تمت إضافة عملة ${newCurr.code} (${newCurr.label_ar})`, 'success');
    return { success: true };
  };

  const extendSubscription = (days: number = 30) => {
    if (!subscription) return;
    const baseDate = isSubscriptionExpired ? new Date() : new Date(subscription.end_date);
    const newEnd = new Date(baseDate.getTime() + days * 86400000).toISOString();
    const updatedSub: Subscription = {
      ...subscription,
      status: 'active',
      end_date: newEnd,
    };
    setSubscription(updatedSub);
    showToast(`تم تمديد الاشتراك بنجاح لمدة ${days} يوماً!`, 'success');
  };

  // Platform Owner Controls: Update Subscription
  const updateWorkspaceSubscription = async (
    workspaceId: string, 
    action: 'activate' | 'extend' | 'suspend', 
    months: number = 1
  ) => {
    setAllSubscriptionsState(prev => {
      const existing = prev.find(s => s.workspace_id === workspaceId);
      const now = new Date();
      let newEndDate = existing && new Date(existing.end_date).getTime() > now.getTime()
        ? new Date(existing.end_date)
        : new Date();
      
      if (action === 'extend' || action === 'activate') {
        newEndDate.setMonth(newEndDate.getMonth() + months);
      }

      const updatedSub: Subscription = {
        id: existing?.id || `sub-${workspaceId}`,
        workspace_id: workspaceId,
        team_id: workspaceId,
        status: action === 'suspend' ? 'suspended' : 'active',
        start_date: existing?.start_date || now.toISOString(),
        end_date: newEndDate.toISOString(),
        is_trial: false,
        created_at: existing?.created_at || now.toISOString(),
      };

      const next = prev.filter(s => s.workspace_id !== workspaceId).concat(updatedSub);
      localStorage.setItem('alittihadia_all_subscriptions', JSON.stringify(next));

      if (currentWorkspace?.id === workspaceId) {
        setSubscription(updatedSub);
        localStorage.setItem('aman_subscription', JSON.stringify(updatedSub));
      }

      return next;
    });
    return { success: true };
  };

  // Platform Owner Controls: Update Workspace Notes
  const updateWorkspaceNotes = async (workspaceId: string, notes: string) => {
    setAllWorkspacesState(prev => {
      const next = prev.map(ws => ws.id === workspaceId ? { ...ws, admin_notes: notes } : ws);
      localStorage.setItem('alittihadia_all_workspaces', JSON.stringify(next));
      return next;
    });
    if (currentWorkspace?.id === workspaceId) {
      setCurrentWorkspace(prev => prev ? { ...prev, admin_notes: notes } : null);
    }
    return { success: true };
  };

  // Password Reset Request (Worker to Workspace Admin, Admin to Platform Owner)
  const submitPasswordResetRequest = async (data: {
    phone: string;
    whatsapp: string;
    accountType: 'worker' | 'admin';
    userName?: string;
  }) => {
    const newReq: PasswordResetRequest = {
      id: `req-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      user_id: `usr-${cleanPhoneNumber(data.phone)}`,
      user_name: data.userName || `المستخدم (${data.phone})`,
      user_phone: data.phone,
      user_whatsapp: data.whatsapp,
      workspace_id: currentWorkspace?.id,
      workspace_name: currentWorkspace?.name,
      target_role: data.accountType,
      status: 'pending',
      requested_at: new Date().toISOString(),
    };

    setPasswordResetRequestsState(prev => {
      const next = [newReq, ...prev];
      localStorage.setItem('alittihadia_password_reset_requests', JSON.stringify(next));
      return next;
    });
    return { success: true };
  };

  // Resolve Password Reset Request
  const resolvePasswordResetRequest = async (
    requestId: string, 
    approved: boolean, 
    tempPassword?: string
  ) => {
    setPasswordResetRequestsState(prev => {
      const next = prev.map(r => r.id === requestId ? {
        ...r,
        status: approved ? ('resolved' as const) : ('rejected' as const),
        resolved_at: new Date().toISOString(),
        resolved_by: currentUser?.id,
        temporary_password: tempPassword || null,
      } : r);
      localStorage.setItem('alittihadia_password_reset_requests', JSON.stringify(next));
      return next;
    });
    return { success: true };
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        userRole,
        isLoggedIn: Boolean(currentUser),
        registerUser,
        loginWithCredentials,
        logout,
        currentWorkspace,
        currentTeam: currentWorkspace,
        workspaceMembers,
        teamMembers: workspaceMembers,
        joinRequests,
        approveJoinRequest,
        rejectJoinRequest,
        renewInviteCode,
        collaborations,
        sendCollaborationRequest,
        respondToCollaboration,
        updateSharingSettings,
        stations,
        selectedStationId,
        setSelectedStationId,
        userAssignedStationId,
        currencies,
        stationBalances,
        exchangeRate,
        setExchangeRate,
        convertCurrency,
        transactions,
        auditLogs,
        createTransaction,
        updateTransaction,
        cancelTransaction,
        parcels,
        createParcel,
        updateParcelStatus,
        recordParcelPayment,
        updateParcel,
        getParcelByTrackingCode,
        trips,
        rememberedDrivers,
        rememberedPlates,
        createTrip,
        loadParcelToTrip,
        unloadParcelFromTrip,
        departTrip,
        receiveParcelAtDestination,
        closeTrip,
        addBalanceAdjustment,
        createTeam,
        joinTeam,
        regenerateInviteCode: renewInviteCode,
        addStation,
        addWorkerByOwner,
        assignWorkerToStation,
        removeWorkerFromTeam,
        addCurrency,
        language,
        setLanguage,
        t,
        subscription,
        isSubscriptionExpired,
        daysUntilExpiry,
        extendSubscription,
        allWorkspaces: allWorkspacesState,
        allSubscriptions: allSubscriptionsState,
        updateWorkspaceSubscription,
        updateWorkspaceNotes,
        passwordResetRequests: passwordResetRequestsState,
        submitPasswordResetRequest,
        resolvePasswordResetRequest,
        isSupabaseLive,
        hasDemoData,
        deleteDemoData,
        toast,
        showToast,
        resetAllDataToZero,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
