import React, { useState, useEffect, useRef } from 'react';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';
import { 
  Camera, 
  X, 
  Scan, 
  Keyboard, 
  Flashlight, 
  RotateCw, 
  AlertCircle, 
  CheckCircle2, 
  HelpCircle,
  Sparkles
} from 'lucide-react';
import { playSuccessBeep, playErrorBeep } from '../utils/audioFeedback';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScan: (scannedCode: string) => void;
  title?: string;
  subtitle?: string;
  placeholder?: string;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  onScan,
  title = 'مسح باركود (Code128) أو رمز (QR)',
  subtitle = 'وجه الكاميرا نحو رمز QR أو باركود Code128 على الملصق أو استخدم القارئ اليدوي',
  placeholder = 'أدخل رقم الكولي أو امسح كود التتبع (QR / Code128)...'
}) => {
  const [activeMode, setActiveMode] = useState<'camera' | 'manual'>('camera');
  const [manualCode, setManualCode] = useState('');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [torchOn, setTorchOn] = useState(false);
  const [hasTorch, setHasTorch] = useState(false);

  const html5QrCodeRef = useRef<Html5Qrcode | null>(null);
  const manualInputRef = useRef<HTMLInputElement>(null);
  const readerElementId = 'alittihadia-qr-reader';

  // تنظيف استخلاص كود الكولي من ناتج المسح (يدعم QR و Code128 والرقم التسلسلي)
  const extractCleanCode = (raw: string): string => {
    let clean = raw.trim();
    if (!clean) return '';

    // إذا كان الممسوح عبارة عن JSON (تنسيق قديم)
    if (clean.startsWith('{') && clean.endsWith('}')) {
      try {
        const parsed = JSON.parse(clean);
        if (parsed.code) return String(parsed.code).trim();
        if (parsed.num) return String(parsed.num).trim();
      } catch {}
    }

    return clean;
  };

  const handleSuccessfulScan = (rawText: string) => {
    const code = extractCleanCode(rawText);
    if (!code) {
      playErrorBeep();
      return;
    }

    playSuccessBeep();
    stopCamera();
    onScan(code);
    onClose();
  };

  // بدء تشغيل كاميرا الهاتف مع دعم كامل لـ QR Code و Code128
  const startCamera = async () => {
    setCameraError(null);
    try {
      if (!html5QrCodeRef.current) {
        html5QrCodeRef.current = new Html5Qrcode(readerElementId, {
          formatsToSupport: [
            Html5QrcodeSupportedFormats.QR_CODE,
            Html5QrcodeSupportedFormats.CODE_128,
            Html5QrcodeSupportedFormats.CODE_39,
            Html5QrcodeSupportedFormats.EAN_13,
          ],
          verbose: false,
        });
      }

      const qr = html5QrCodeRef.current;
      if (qr.isScanning) {
        return;
      }

      await qr.start(
        { facingMode: 'environment' },
        {
          fps: 15,
          qrbox: { width: 260, height: 220 },
          aspectRatio: 1.0,
        },
        (decodedText) => {
          handleSuccessfulScan(decodedText);
        },
        () => {
          // خطأ إطار عابر يتم تجاهله أثناء البحث عن الكود
        }
      );

      setIsCameraActive(true);

      // فحص دعم الفلاش (Torch)
      try {
        const track = (qr as any).getRunningTrackCameraCapabilities?.();
        if (track && track.torch) {
          setHasTorch(true);
        }
      } catch {}

    } catch (err: any) {
      console.warn('Camera start error:', err);
      setIsCameraActive(false);
      const msg = String(err?.message || err).toLowerCase();
      if (msg.includes('permission') || msg.includes('notallowed')) {
        setCameraError('لم يتم منح إذن استخدام الكاميرا. يرجى السماح للتطبيق بالوصول للكاميرا أو استخدام الإدخال اليدوي.');
      } else if (msg.includes('notfound') || msg.includes('device')) {
        setCameraError('لم يتم العثور على كاميرا في هذا الجهاز. يمكنك استخدام الإدخال اليدوي أو قارئ الباركود الخارجي.');
      } else {
        setCameraError('تعذر فتح الكاميرا حالياً. يرجى استخدام حقل الإدخال اليدوي أو قارئ الباركود.');
      }
      setActiveMode('manual');
    }
  };

  const stopCamera = async () => {
    if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
      try {
        await html5QrCodeRef.current.stop();
      } catch (e) {
        console.warn('Camera stop error:', e);
      }
    }
    setIsCameraActive(false);
    setTorchOn(false);
  };

  // تشغيل / إيقاف الفلاش إن كان مدعوماً
  const toggleTorch = async () => {
    if (!html5QrCodeRef.current || !isCameraActive) return;
    try {
      const nextTorch = !torchOn;
      await html5QrCodeRef.current.applyVideoConstraints({
        advanced: [{ torch: nextTorch } as any]
      });
      setTorchOn(nextTorch);
    } catch (e) {
      console.warn('Failed to toggle torch:', e);
    }
  };

  useEffect(() => {
    if (isOpen) {
      setManualCode('');
      setCameraError(null);

      if (activeMode === 'camera') {
        const timer = setTimeout(() => {
          startCamera();
        }, 150);
        return () => clearTimeout(timer);
      } else {
        setTimeout(() => {
          manualInputRef.current?.focus();
        }, 100);
      }
    } else {
      stopCamera();
    }

    return () => {
      stopCamera();
    };
  }, [isOpen, activeMode]);

  // إرسال الإدخال اليدوي أو قارئ الباركود الخارجي (USB/Bluetooth)
  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) {
      playErrorBeep();
      return;
    }
    handleSuccessfulScan(manualCode);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 bg-black/90 backdrop-blur-md animate-fadeIn" dir="rtl">
      <div 
        className="w-full max-w-[380px] bg-[#1a0f00]/95 border border-[#D4AF37]/65 rounded-[24px] shadow-[0_20px_50px_rgba(0,0,0,0.9)] overflow-hidden flex flex-col text-right relative"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-3.5 border-b border-[#D4AF37]/30 bg-[#120a00]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#F5D799] via-[#D4AF37] to-[#9A711C] text-[#140b00] flex items-center justify-center shadow-md">
              <Scan className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <h3 className="text-xs font-black text-white">{title}</h3>
              <p className="text-[10px] text-[#C2A878]">{subtitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-[#1a0f00] border border-[#D4AF37]/30 text-[#C2A878] hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Mode Toggle Switcher */}
        <div className="p-2.5 bg-[#0d0700] border-b border-[#D4AF37]/25 flex items-center justify-center gap-1.5">
          <button
            type="button"
            onClick={() => setActiveMode('camera')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-[11px] font-bold transition ${
              activeMode === 'camera'
                ? 'bg-gradient-to-r from-[#F5D799] via-[#D4AF37] to-[#B68A2E] text-[#140b00] shadow-md font-black'
                : 'bg-[#1a0f00] text-[#C2A878] border border-[#D4AF37]/30 hover:text-white'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>كاميرا الهاتف</span>
          </button>
          <button
            type="button"
            onClick={() => {
              stopCamera();
              setActiveMode('manual');
            }}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-[11px] font-bold transition ${
              activeMode === 'manual'
                ? 'bg-gradient-to-r from-[#F5D799] via-[#D4AF37] to-[#B68A2E] text-[#140b00] shadow-md font-black'
                : 'bg-[#1a0f00] text-[#C2A878] border border-[#D4AF37]/30 hover:text-white'
            }`}
          >
            <Keyboard className="w-3.5 h-3.5" />
            <span>إدخال يدوي / قارئ خارجي</span>
          </button>
        </div>

        {/* Camera Scanner View */}
        {activeMode === 'camera' && (
          <div className="p-4 flex flex-col items-center justify-center space-y-3">
            {cameraError ? (
              <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs space-y-2 text-center w-full">
                <AlertCircle className="w-6 h-6 text-rose-400 mx-auto" />
                <p className="font-bold">{cameraError}</p>
                <button
                  type="button"
                  onClick={() => setActiveMode('manual')}
                  className="px-4 py-2 rounded-xl bg-[#120a00] border border-[#D4AF37]/40 hover:bg-[#1a0f00] text-[#F5D799] font-bold text-xs"
                >
                  الانتقال إلى الإدخال اليدوي
                </button>
              </div>
            ) : (
              <div className="relative w-full aspect-square max-w-[260px] bg-black rounded-3xl overflow-hidden border-2 border-[#D4AF37]/60 shadow-inner flex items-center justify-center">
                {/* Container for html5-qrcode video */}
                <div id={readerElementId} className="w-full h-full" />

                {/* Animated scan overlay frame */}
                <div className="absolute inset-0 pointer-events-none border-2 border-dashed border-[#D4AF37]/70 rounded-2xl m-4 flex items-center justify-center">
                  <div className="w-full h-0.5 bg-gradient-to-r from-transparent via-[#F5D799] to-transparent shadow-[0_0_8px_#D4AF37] animate-pulse" />
                </div>
              </div>
            )}

            {/* Camera Controls */}
            {isCameraActive && (
              <div className="flex items-center justify-center gap-2.5 w-full pt-1">
                {hasTorch && (
                  <button
                    type="button"
                    onClick={toggleTorch}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-[11px] font-bold transition ${
                      torchOn ? 'bg-[#D4AF37] text-[#140b00] font-black' : 'bg-[#120a00] text-[#C2A878] border border-[#D4AF37]/30'
                    }`}
                  >
                    <Flashlight className="w-3.5 h-3.5" />
                    <span>{torchOn ? 'إطفاء الفلاش' : 'تشغيل الفلاش'}</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    stopCamera();
                    setTimeout(startCamera, 200);
                  }}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-[#120a00] border border-[#D4AF37]/30 hover:bg-[#1a0f00] text-[#F5D799] text-[11px] font-bold transition"
                  title="إعادة تشغيل الكاميرا"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                  <span>تحديث الكاميرا</span>
                </button>
              </div>
            )}

            <p className="text-[10px] text-[#C2A878] text-center">
              ضع رمز الاستجابة السريعة (QR) أو باركود التذكرة داخل المربع للمسح الفوري
            </p>
          </div>
        )}

        {/* Manual Input View & Hardware Barcode Listener */}
        {activeMode === 'manual' && (
          <form onSubmit={handleManualSubmit} className="p-4 space-y-3.5">
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-[#F5D799] block">
                رقم الكولي أو كود التتبع:
              </label>
              <input
                ref={manualInputRef}
                type="text"
                autoFocus
                value={manualCode}
                onChange={e => setManualCode(e.target.value)}
                placeholder={placeholder}
                className="w-full bg-[#120a00] border border-[#D4AF37]/50 focus:border-[#F5D799] rounded-xl px-3.5 py-2.5 text-xs text-white font-mono placeholder-[#8C6D3F] focus:outline-none shadow-inner"
              />
              <p className="text-[10px] text-[#C2A878]">
                💡 متوافق مع قارئات الباركود اللاسلكية أو USB؛ امسح الباركود وسيتم الإرسال تلقائياً.
              </p>
            </div>

            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 rounded-xl bg-[#120a00] border border-[#D4AF37]/35 hover:bg-[#1a0f00] text-[#C2A878] font-bold text-xs transition"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="flex-[2] py-2.5 rounded-xl bg-gradient-to-r from-[#F5D799] via-[#D4AF37] to-[#B68A2E] hover:brightness-110 text-[#140b00] font-black text-xs transition shadow-lg active:scale-95"
              >
                تأكيد ومتابعة ➔
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
