import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Parcel, Transaction } from '../types/database';
import { ParcelStickerModal } from './ParcelStickerModal';
import { 
  PlusCircle, 
  Store, 
  Clock, 
  ArrowDownLeft, 
  ArrowUpRight, 
  Package, 
  Eye, 
  ShieldCheck,
  Phone,
  Truck,
  CheckCircle2,
  Printer,
  Compass,
  ArrowRightLeft,
  Calendar,
  DollarSign
} from 'lucide-react';

interface WorkerStationViewProps {
  onOpenNewVoucher: () => void;
  onOpenNewParcel: () => void;
  onGoToParcels: () => void;
  onGoToCash: () => void;
}

export const WorkerStationView: React.FC<WorkerStationViewProps> = ({ 
  onOpenNewVoucher,
  onOpenNewParcel,
  onGoToParcels,
  onGoToCash
}) => {
  const { 
    currentUser, 
    stations, 
    selectedStationId, 
    stationBalances, 
    currencies, 
    transactions,
    parcels,
    updateParcelStatus,
    exchangeRate 
  } = useApp();

  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);
  const [selectedParcelForReceipt, setSelectedParcelForReceipt] = useState<Parcel | null>(null);

  const currentStation = stations.find(s => s.id === selectedStationId) || stations[0];
  const balances = currentStation ? (stationBalances[currentStation.id] || {}) : {};

  // Today's vouchers for this station only
  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);

  const stationTodayTransactions = transactions.filter(t => {
    return (
      t.station_id === currentStation?.id &&
      new Date(t.created_at) >= todayStart &&
      !t.deleted_at &&
      t.status === 'confirmed'
    );
  });

  // Today's parcels for this station
  const stationParcels = parcels.filter(p => {
    return p.origin_station_id === currentStation?.id || p.destination_station_id === currentStation?.id;
  });

  const parcelsAwaitingDelivery = stationParcels.filter(p => {
    return p.destination_station_id === currentStation?.id && (p.status === 'arrived' || p.status === 'in_transit');
  });

  return (
    <div className="space-y-3.5 pb-24 text-right">
      
      {/* ===================================================================== */}
      {/* HERO LIVE TRACKING SHOWCASE (100% Match to Mobile Reference Image)    */}
      {/* ===================================================================== */}
      <div className="space-y-2.5">
        {/* 1. Desert Road Map: Dakhla -> Nouadhibou with White Van */}
        <div className="relative rounded-t-[24px] overflow-hidden border-t border-x border-[#D4AF37]/40 shadow-2xl">
          <svg
            viewBox="52 268 653 465"
            className="w-full h-auto block"
            preserveAspectRatio="xMidYMid slice"
          >
            <image
              href="/assets/aistudio/IIII_3d3dff03.jpeg"
              width="757"
              height="1600"
            />
          </svg>
        </div>

        {/* 2. Translucent Brown Shipment Status & Golden Timeline Card */}
        <div className="-mt-8 relative z-10 rounded-[22px] bg-[#1a0f00]/80 backdrop-blur-md border border-[#D4AF37]/65 p-4 shadow-[0_12px_35px_rgba(0,0,0,0.85)]">
          <div className="text-right">
            <h2 className="text-[18px] font-black text-[#F5D799] leading-tight">
              حالة الشحنة • <span dir="ltr" className="font-sans">In Transit</span>
            </h2>
            <p className="text-[12px] text-[#D8C3A5] font-medium mt-0.5">
              رقم <span dir="ltr" className="font-mono font-bold text-[#FFF8EB]">TRT-847291-MR</span>
            </p>
          </div>

          {/* Horizontal Golden Progress Bar */}
          <div className="relative flex items-center justify-between my-3 px-1">
            <div className="absolute left-2 right-2 top-1/2 -translate-y-1/2 h-[1.5px] bg-[#D4AF37]/45" />
            <div className="relative z-10 w-3 h-3 rounded-full bg-[#F39C3D] ring-2 ring-[#1a0f00]" />
            <div className="relative z-10 w-2.5 h-2.5 rounded-full bg-[#E6B86A]" />
            <div className="relative z-10 w-2.5 h-2.5 rounded-full bg-[#E6B86A]" />
            <div className="relative z-10 w-2.5 h-2.5 rounded-full bg-[#E6B86A]" />
            <div className="relative z-10 w-2.5 h-2.5 rounded-full bg-[#E6B86A]" />
          </div>

          {/* Vertical Golden Timeline */}
          <div className="relative space-y-3 pr-7 mt-2 before:absolute before:right-[9px] before:top-2 before:bottom-6 before:w-[1.5px] before:bg-[#D4AF37]/60">
            <div className="relative">
              <div className="absolute -right-7 top-0.5 w-5 h-5 rounded-full bg-[#F39C3D] text-[#1a0f00] flex items-center justify-center text-[11px] font-black shadow-md">
                ✓
              </div>
              <div className="text-[13px] font-bold text-[#FFF8EB] leading-snug">
                فالمحطة
              </div>
              <div className="text-[11px] text-[#C8B08A]">اليوم، 09:15</div>
            </div>

            <div className="relative">
              <div className="absolute -right-7 top-0.5 w-5 h-5 rounded-full bg-[#F39C3D] text-[#1a0f00] flex items-center justify-center text-[11px] font-black shadow-md">
                ✓
              </div>
              <div className="text-[13px] font-bold text-[#FFF8EB] leading-snug">
                فالطريق
              </div>
              <div className="text-[11px] text-[#C8B08A]">اليوم، 11:40</div>
            </div>

            <div className="relative">
              <div className="absolute -right-7 top-0.5 w-5 h-5 rounded-full bg-[#F39C3D] text-[#1a0f00] flex items-center justify-center text-[11px] font-black shadow-md">
                ✓
              </div>
              <div className="text-[13px] font-bold text-[#FFF8EB] leading-snug">
                وصلات
              </div>
              <div className="text-[11px] text-[#C8B08A]">اليوم، 13:20</div>
            </div>

            <div className="relative">
              <div className="absolute -right-7 top-0.5 w-5 h-5 rounded-full bg-[#1a0f00] border-2 border-[#F39C3D] flex items-center justify-center shadow-[0_0_10px_rgba(243,156,61,0.6)]">
                <span className="w-2 h-2 rounded-full bg-[#F5D799]" />
              </div>
              <div className="text-[13px] font-bold text-[#FFF8EB] leading-snug">
                تسلمات
              </div>
              <div className="text-[11px] text-[#E6C37A]">متوقع • 15:45 • جاري الآن</div>
            </div>
          </div>
        </div>

        {/* 3. QR Code & Expected Arrival Split Card */}
        <div className="rounded-[22px] bg-[#1a0f00]/80 backdrop-blur-md border border-[#D4AF37]/65 p-3.5 shadow-2xl grid grid-cols-2 gap-3 items-center">
          <div className="text-right pr-1 border-l border-[#D4AF37]/30 pl-2 space-y-1.5">
            <div className="flex items-center justify-start gap-1.5 text-[#F5D799] font-bold text-[14px]">
              <span>الوصول المتوقع</span>
              <Clock className="w-4 h-4 text-[#E6C37A]" />
            </div>
            <div className="text-[12px] font-bold text-[#FFF8EB]">
              اليوم، 17:30 • 3 س 10 د
            </div>
            <div className="text-[11px] text-[#D9B36C] font-mono" dir="ltr">
              → 142 km to Nouadhibou
            </div>
          </div>

          <div
            onClick={onGoToParcels}
            className="flex flex-col items-center justify-center cursor-pointer"
          >
            <span className="text-[12px] font-bold text-[#F5D799] mb-1.5">رمز الاستلام QR</span>
            <div className="flex items-center gap-2">
              <div className="w-[74px] h-[74px] rounded-lg bg-[#E5953E] p-1.5 shadow-md flex items-center justify-center">
                <svg viewBox="0 0 21 21" className="w-full h-full fill-[#1a0f00]">
                  <path d="M0,0 h7 v7 h-7 z M1,1 v5 h5 v-5 z M2,2 h3 v3 h-3 z M14,0 h7 v7 h-7 z M15,1 v5 h5 v-5 z M16,2 h3 v3 h-3 z M0,14 h7 v7 h-7 z M1,15 v5 h5 v-5 z M2,16 h3 v3 h-3 z M8,0 h2 v2 h-2 z M11,1 h2 v2 h-2 z M8,4 h3 v2 h-3 z M12,4 h1 v3 h-1 z M0,8 h3 v2 h-3 z M4,8 h2 v3 h-2 z M8,8 h5 v2 h-5 z M15,8 h2 v2 h-2 z M18,9 h3 v2 h-3 z M1,11 h2 v2 h-2 z M6,11 h3 v2 h-3 z M11,11 h2 v3 h-2 z M14,12 h3 v2 h-3 z M8,15 h2 v3 h-2 z M12,16 h2 v2 h-2 z M15,15 h3 v3 h-3 z M19,15 h2 v2 h-2 z M9,19 h4 v2 h-4 z M15,19 h6 v2 h-6 z" />
                </svg>
              </div>
              <span className="text-[18px] font-bold text-[#D99B4E] font-mono">82</span>
            </div>
            <span className="text-[10px] font-bold text-[#E6C37A] mt-1.5">امسح عند الاستلام</span>
          </div>
        </div>

        {/* 4. Bottom Dual Action Buttons */}
        <div className="grid grid-cols-2 gap-2.5 pt-0.5">
          <button
            onClick={onGoToParcels}
            className="py-3 px-3 rounded-2xl bg-gradient-to-r from-[#F5B05B] via-[#E5953E] to-[#D4882A] hover:brightness-110 text-[#1a0f00] font-black text-[13px] flex items-center justify-center gap-1.5 shadow-lg shadow-[#E5953E]/25 border border-[#F8C885] active:scale-95 transition"
          >
            <span>تفاصيل الشحنة</span>
            <Package className="w-4 h-4 stroke-[2.5]" />
          </button>

          <button
            onClick={() => setSelectedParcelForReceipt(parcels[0] || null)}
            className="py-3 px-3 rounded-2xl bg-[#1a0f00]/90 hover:bg-[#2a1800] text-[#E6C37A] font-bold text-[13px] flex items-center justify-center gap-1.5 border border-[#D4AF37]/65 active:scale-95 transition"
          >
            <span>مشاركة التتبع</span>
            <Printer className="w-4 h-4 text-[#D4AF37]" />
          </button>
        </div>
      </div>

      {/* 1. Station Hero Card */}
      <div className="rounded-[22px] bg-[#1a0f00]/80 backdrop-blur-md border border-[#D4AF37]/50 p-4 shadow-2xl relative overflow-hidden">
        <div className="flex items-center justify-between mb-3 relative z-10">
          <div className="flex items-center gap-2.5">
            <div 
              className="w-11 h-11 rounded-full border border-[#D4AF37] shrink-0 overflow-hidden flex items-center justify-center p-0"
              style={{ background: 'transparent', borderRadius: '50%', padding: 0, overflow: 'hidden' }}
            >
              <img 
                src="/logo.png" 
                alt="شعار محطة الاتحادية" 
                style={{ borderRadius: '50%', width: '100%', height: '100%', objectFit: 'cover', background: 'transparent', display: 'block' }}
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-black text-[#F5D799]">
                  {currentStation?.name || 'محطة الإرساليات'}
                </h2>
              </div>
              <p className="text-[11px] text-[#C8B08A] font-medium mt-0.5">
                مرحباً بك يا <strong>{currentUser?.name}</strong>
              </p>
            </div>
          </div>

          <span className="text-[10px] px-2.5 py-1 rounded-full bg-[#120a00] text-[#E6C37A] font-bold border border-[#D4AF37]/40">
            {currentStation?.country === 'MA' ? '🇲🇦 المغرب' : '🇲🇷 موريتانيا'}
          </span>
        </div>

        {/* Dual Live Currency Balance Card */}
        <div className="space-y-2 mt-2 relative z-10">
          {/* MAD Balance */}
          <div className="bg-[#120a00]/90 p-3 rounded-xl border border-[#D4AF37]/30 flex items-center justify-between">
            <div>
              <span className="text-xs text-[#C8B08A] block font-bold">
                صندوق الدرهم المغربي
              </span>
              <span className="text-[10px] text-[#E6C37A] font-bold">
                محطة {currentStation?.city}
              </span>
            </div>
            <div className={`text-xl font-black font-mono ${
              (balances['MAD'] ?? 0) < 0 ? 'text-rose-400' : 'text-[#F5D799]'
            }`}>
              {(balances['MAD'] ?? 0).toLocaleString()} <span className="text-xs font-sans font-normal text-[#C8B08A]">درهم</span>
            </div>
          </div>

          {/* MRU Balance */}
          <div className="bg-[#120a00]/90 p-3 rounded-xl border border-[#D4AF37]/30 flex items-center justify-between">
            <div>
              <span className="text-xs text-[#C8B08A] block font-bold">
                صندوق الأوقية الموريتانية
              </span>
              <span className="text-[10px] text-[#E6C37A] font-bold">
                محطة {currentStation?.city}
              </span>
            </div>
            <div className={`text-xl font-black font-mono ${
              (balances['MRU'] ?? 0) < 0 ? 'text-rose-400' : 'text-[#F5D799]'
            }`}>
              {(balances['MRU'] ?? 0).toLocaleString()} <span className="text-xs font-sans font-normal text-[#C8B08A]">أوقية</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. BIG 4 QUICK ACTION BUTTONS */}
      <div>
        <h3 className="text-xs font-black text-[#E6C37A] mb-2 flex items-center gap-1.5">
          <span>العمليات اليومية السريعة لموظف المكتب:</span>
        </h3>

        <div className="grid grid-cols-2 gap-2.5">
          {/* Button 1: New Parcel Intake */}
          <button
            onClick={onOpenNewParcel}
            className="flex flex-col items-start p-3.5 rounded-[20px] bg-[#1a0f00]/80 border border-[#D4AF37]/50 hover:border-[#D4AF37] shadow-lg text-right active:scale-95 transition group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] flex items-center justify-center font-bold mb-2 shadow-md">
              <Package className="w-5 h-5 stroke-[2.5]" />
            </div>
            <span className="text-xs font-black text-[#FFF8EB] block">
              تسجيل كولي جديد
            </span>
            <span className="text-[10px] text-[#C8B08A] font-medium mt-0.5">
              استلام بضاعة وطباعة باركود
            </span>
          </button>

          {/* Button 2: Deliver & Collect COD */}
          <button
            onClick={onGoToParcels}
            className="flex flex-col items-start p-3.5 rounded-[20px] bg-[#1a0f00]/80 border border-[#D4AF37]/50 hover:border-[#D4AF37] shadow-lg text-right active:scale-95 transition group"
          >
            <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/20 border border-[#D4AF37]/50 text-[#F5D799] flex items-center justify-center font-bold mb-2">
              <CheckCircle2 className="w-5 h-5 stroke-[2.5]" />
            </div>
            <span className="text-xs font-black text-[#FFF8EB] block">
              تسليم وقبض المبلغ
            </span>
            <span className="text-[10px] text-[#E6C37A] font-medium mt-0.5">
              {parcelsAwaitingDelivery.length} طرد بانتظار التسليم
            </span>
          </button>

          {/* Button 3: Cash In */}
          <button
            onClick={onOpenNewVoucher}
            className="flex flex-col items-start p-3.5 rounded-[20px] bg-[#1a0f00]/80 border border-[#D4AF37]/50 hover:border-[#D4AF37] shadow-lg text-right active:scale-95 transition group"
          >
            <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/20 border border-[#D4AF37]/50 text-[#F5D799] flex items-center justify-center font-bold mb-2">
              <ArrowDownLeft className="w-5 h-5 stroke-[2.5]" />
            </div>
            <span className="text-xs font-black text-[#FFF8EB] block">
              سند قبض نقدي
            </span>
            <span className="text-[10px] text-[#C8B08A] font-medium mt-0.5">
              إيداع نقد بصندوق المحطة
            </span>
          </button>

          {/* Button 4: Cash Out / Expenses */}
          <button
            onClick={onOpenNewVoucher}
            className="flex flex-col items-start p-3.5 rounded-[20px] bg-[#1a0f00]/80 border border-[#D4AF37]/50 hover:border-[#D4AF37] shadow-lg text-right active:scale-95 transition group"
          >
            <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/20 border border-[#D4AF37]/50 text-[#F5D799] flex items-center justify-center font-bold mb-2">
              <ArrowUpRight className="w-5 h-5 stroke-[2.5]" />
            </div>
            <span className="text-xs font-black text-[#FFF8EB] block">
              سند صرف نقدي
            </span>
            <span className="text-[10px] text-[#C8B08A] font-medium mt-0.5">
              سداد بضاعة أو مصاريف طريق
            </span>
          </button>
        </div>
      </div>

      {/* 3. Awaiting Parcels at this Station Banner */}
      {parcelsAwaitingDelivery.length > 0 && (
        <div className="bg-[#1a0f00]/80 border border-[#D4AF37]/50 rounded-[22px] p-3.5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-[#F5D799] flex items-center gap-1.5">
              <Compass className="w-4 h-4 text-[#D4AF37]" />
              <span>طرود وصلت محطة {currentStation?.city} جاهزة للتسليم:</span>
            </span>
            <button
              onClick={onGoToParcels}
              className="text-[11px] font-bold text-[#F3A952] hover:underline"
            >
              عرض الكل ➔
            </button>
          </div>

          <div className="space-y-2 pt-1">
            {parcelsAwaitingDelivery.slice(0, 3).map(p => (
              <div
                key={p.id}
                className="bg-[#120a00]/90 p-2.5 rounded-xl border border-[#D4AF37]/30 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-bold text-[#FFF8EB] font-mono">{p.tracking_code}</div>
                  <div className="text-[10px] text-[#C8B08A]">
                    المستلم: <strong>{p.receiver_name}</strong> ({p.receiver_phone})
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {(p.cod_amount ?? 0) > 0 && (
                    <span className="font-mono font-bold text-[#E6C37A] text-xs">
                      {p.cod_amount} {p.currency} (COD)
                    </span>
                  )}
                  <button
                    onClick={() => setSelectedParcelForReceipt(p)}
                    className="p-1.5 rounded-lg bg-[#1a0f00] border border-[#D4AF37]/40 text-[#E6C37A] hover:text-white"
                    title="طباعة التوصيل"
                  >
                    <Printer className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. Today's Activity at This Station */}
      <div className="bg-[#1a0f00]/80 border border-[#D4AF37]/50 rounded-[22px] p-4 shadow-lg space-y-3">
        <div className="flex items-center justify-between border-b border-[#D4AF37]/25 pb-2">
          <span className="text-xs font-black text-[#F5D799] flex items-center gap-1.5">
            <Calendar className="w-4 h-4 text-[#D4AF37]" />
            <span>سندات محطة {currentStation?.city} اليوم ({stationTodayTransactions.length}):</span>
          </span>

          <button
            onClick={onGoToCash}
            className="text-[11px] text-[#F3A952] hover:underline font-bold"
          >
            فتح دفتر القيود ➔
          </button>
        </div>

        {stationTodayTransactions.length === 0 ? (
          <div className="text-center py-5 text-[#C8B08A] text-xs">
            لم تسجل أي حركة نقدية في هذا الصندوق اليوم حتى الآن.
          </div>
        ) : (
          <div className="space-y-2">
            {stationTodayTransactions.slice(0, 5).map(t => {
              const isInflow = t.type === 'cash_in' || t.type === 'parcel_shipping_fee' || t.type === 'parcel_cod_collection';
              return (
                <div
                  key={t.id}
                  className="bg-[#120a00]/90 p-3 rounded-xl border border-[#D4AF37]/30 flex items-center justify-between text-xs"
                >
                  <div className="min-w-0 pr-1">
                    <span className="font-bold text-[#FFF8EB] block truncate">{t.reason || 'سند مالي'}</span>
                    <span className="text-[10px] text-[#C8B08A] font-mono" dir="ltr">
                      {new Date(t.created_at).toLocaleTimeString('ar-MA', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <div className="text-left font-mono shrink-0 pl-1">
                    <span className={`font-black text-sm ${isInflow ? 'text-[#F5D799]' : 'text-rose-400'}`}>
                      {isInflow ? '+' : '-'}{t.amount} {t.currency}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 10cm x 10cm Parcel Sticker Modal */}
      <ParcelStickerModal
        parcel={selectedParcelForReceipt}
        isOpen={Boolean(selectedParcelForReceipt)}
        onClose={() => setSelectedParcelForReceipt(null)}
      />

    </div>
  );
};
