import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Store, 
  ArrowDownLeft, 
  ArrowUpRight, 
  TrendingUp, 
  Users, 
  UserPlus, 
  Plus, 
  Coins, 
  Share2, 
  Trash2, 
  ExternalLink,
  ShieldAlert,
  Clock,
  CheckCircle,
  Eye,
  SlidersHorizontal,
  FileSpreadsheet,
  Package,
  Truck,
  Compass,
  Calendar,
  DollarSign,
  PlusCircle,
  CheckCircle2,
  MapPin,
  Phone
} from 'lucide-react';
import { Transaction } from '../types/database';
import { DailyFinancialReportModal } from './DailyFinancialReportModal';

interface OwnerDashboardProps {
  onOpenNewVoucher: () => void;
  onOpenNewParcel: () => void;
  onOpenLedger: () => void;
  onOpenParcels: () => void;
  onOpenSettings: () => void;
}

export const OwnerDashboard: React.FC<OwnerDashboardProps> = ({
  onOpenNewVoucher,
  onOpenNewParcel,
  onOpenLedger,
  onOpenParcels,
  onOpenSettings,
}) => {
  const { 
    currentTeam, 
    stations, 
    stationBalances, 
    currencies, 
    teamMembers, 
    transactions, 
    parcels,
    addBalanceAdjustment, 
    addStation, 
    addWorkerByOwner,
    assignWorkerToStation, 
    removeWorkerFromTeam,
    addCurrency,
    exchangeRate,
    convertCurrency,
    showToast
  } = useApp();

  // Modal States
  const [showAdjustmentModal, setShowAdjustmentModal] = useState(false);
  const [adjStationId, setAdjStationId] = useState(stations[0]?.id || '');
  const [adjCurrency, setAdjCurrency] = useState(currencies[0]?.code || 'MAD');
  const [adjAmount, setAdjAmount] = useState('');
  const [adjNote, setAdjNote] = useState('');

  const [showDailyReport, setShowDailyReport] = useState(false);

  const [showNewStationModal, setShowNewStationModal] = useState(false);
  const [newStationName, setNewStationName] = useState('');
  const [newStationCity, setNewStationCity] = useState('');
  const [newStationCountry, setNewStationCountry] = useState<'MA' | 'MR'>('MA');
  const [newStationPhone, setNewStationPhone] = useState('');

  const [showAddWorkerModal, setShowAddWorkerModal] = useState(false);
  const [workerName, setWorkerName] = useState('');
  const [workerPhone, setWorkerPhone] = useState('');
  const [workerStationId, setWorkerStationId] = useState(stations[0]?.id || '');
  const [workerRole, setWorkerRole] = useState<'worker' | 'owner'>('worker');
  const [selectedReceiptPhoto, setSelectedReceiptPhoto] = useState<string | null>(null);

  // Global Cash in Circulation across ALL stations
  const globalTotals = useMemo(() => {
    let totalMad = 0;
    let totalMru = 0;

    Object.values(stationBalances).forEach(bals => {
      totalMad += bals['MAD'] || 0;
      totalMru += bals['MRU'] || 0;
    });

    totalMad = Math.round(totalMad * 100) / 100;
    totalMru = Math.round(totalMru * 100) / 100;

    // Approximate equivalent in MAD
    const equivMad = Math.round((totalMad + (totalMru / exchangeRate)) * 100) / 100;

    return { totalMad, totalMru, equivMad };
  }, [stationBalances, exchangeRate]);

  // Parcel Stats
  const parcelStats = useMemo(() => {
    const total = parcels.length;
    const inTransit = parcels.filter(p => p.status === 'in_transit').length;
    const arrived = parcels.filter(p => p.status === 'arrived').length;
    const delivered = parcels.filter(p => p.status === 'delivered').length;
    const pending = parcels.filter(p => p.status === 'registered' || (p.status as string) === 'pending').length;

    let codPendingMad = 0;
    let codPendingMru = 0;
    parcels.forEach(p => {
      const remaining = Math.max(0, (p.amount_due ?? (p.shipping_fee ?? 0)) - (p.amount_paid ?? 0));
      if (p.status !== 'delivered' && p.status !== 'cancelled' && remaining > 0) {
        if (p.currency === 'MAD') codPendingMad += remaining;
        if (p.currency === 'MRU') codPendingMru += remaining;
      }
    });

    return { total, inTransit, arrived, delivered, pending, codPendingMad, codPendingMru };
  }, [parcels]);

  // Handle Adjustment Submit
  const handleAdjustmentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(adjAmount);
    if (!amountNum || amountNum === 0) {
      showToast('يرجى إدخال مبلغ صحيح', 'error');
      return;
    }
    const res = await addBalanceAdjustment(adjStationId, adjCurrency, amountNum, adjNote);
    if (res.success) {
      setShowAdjustmentModal(false);
      setAdjAmount('');
      setAdjNote('');
    } else {
      showToast(res.error || 'فشل التعديل', 'error');
    }
  };

  // Handle New Station Submit
  const handleNewStationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStationName || !newStationCity) {
      showToast('يرجى ملء جميع الحقول المطلوبة', 'error');
      return;
    }
    const res = await addStation(newStationName, newStationCity, newStationCountry, newStationPhone);
    if (res.success) {
      setShowNewStationModal(false);
      setNewStationName('');
      setNewStationCity('');
      setNewStationPhone('');
    }
  };

  const handleAddWorkerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!workerName.trim() || !workerPhone.trim()) {
      showToast('يرجى إدخال اسم ورقم هاتف الموظف', 'error');
      return;
    }
    const res = await addWorkerByOwner(workerName, workerPhone, workerStationId || stations[0]?.id, workerRole);
    if (res.success) {
      setShowAddWorkerModal(false);
      setWorkerName('');
      setWorkerPhone('');
    }
  };

  // Share invite code via WhatsApp
  const shareInviteViaWhatsApp = () => {
    const text = `السلام عليكم ورحمة الله، هذا رمز الانضمام لفريق إدارة "${currentTeam?.name}" على تطبيق محطة الاتحادية الدوليّة للنقل والكوليات:
رمز الدعوة: ${currentTeam?.invite_code}
افتح التطبيق واختر "الانضمام بواسطة رمز الدعوة" لبدء العمل فوراً.`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="space-y-3.5 pb-24 text-right">

      {/* ===================================================================== */}
      {/* HERO LIVE TRACKING SHOWCASE (100% Match to Mobile Reference Image)    */}
      {/* ===================================================================== */}
      <div className="space-y-2.5">
        {/* 1. Desert Road Map: Dakhla -> Nouadhibou with White Van */}
        <div className="relative rounded-t-[24px] overflow-hidden border-t border-x border-[#D4AF37]/40 shadow-2xl">
          <svg
            viewBox="52 268 653 465"
            className="w-full h-auto block"
            preserveAspectRatio="xMidYMid slice"
          >
            <image
              href="/assets/aistudio/IIII_3d3dff03.jpeg"
              width="757"
              height="1600"
            />
          </svg>
        </div>

        {/* 2. Translucent Brown Shipment Status & Golden Timeline Card */}
        <div className="-mt-8 relative z-10 rounded-[22px] bg-[#1a0f00]/80 backdrop-blur-md border border-[#D4AF37]/65 p-4 shadow-[0_12px_35px_rgba(0,0,0,0.85)]">
          {/* Card Header */}
          <div className="text-right">
            <h2 className="text-[18px] font-black text-[#F5D799] leading-tight">
              حالة الشحنة • <span dir="ltr" className="font-sans">In Transit</span>
            </h2>
            <p className="text-[12px] text-[#D8C3A5] font-medium mt-0.5">
              رقم <span dir="ltr" className="font-mono font-bold text-[#FFF8EB]">TRT-847291-MR</span>
            </p>
          </div>

          {/* Horizontal Golden Progress Bar */}
          <div className="relative flex items-center justify-between my-3 px-1">
            <div className="absolute left-2 right-2 top-1/2 -translate-y-1/2 h-[1.5px] bg-[#D4AF37]/45" />
            <div className="relative z-10 w-3 h-3 rounded-full bg-[#F39C3D] ring-2 ring-[#1a0f00]" />
            <div className="relative z-10 w-2.5 h-2.5 rounded-full bg-[#E6B86A]" />
            <div className="relative z-10 w-2.5 h-2.5 rounded-full bg-[#E6B86A]" />
            <div className="relative z-10 w-2.5 h-2.5 rounded-full bg-[#E6B86A]" />
            <div className="relative z-10 w-2.5 h-2.5 rounded-full bg-[#E6B86A]" />
          </div>

          {/* Vertical Golden Timeline */}
          <div className="relative space-y-3 pr-7 mt-2 before:absolute before:right-[9px] before:top-2 before:bottom-6 before:w-[1.5px] before:bg-[#D4AF37]/60">
            {/* Step 1 */}
            <div className="relative">
              <div className="absolute -right-7 top-0.5 w-5 h-5 rounded-full bg-[#F39C3D] text-[#1a0f00] flex items-center justify-center text-[11px] font-black shadow-md">
                ✓
              </div>
              <div className="text-[13px] font-bold text-[#FFF8EB] leading-snug">
                فالمحطة
              </div>
              <div className="text-[11px] text-[#C8B08A]">اليوم، 09:15</div>
            </div>

            {/* Step 2 */}
            <div className="relative">
              <div className="absolute -right-7 top-0.5 w-5 h-5 rounded-full bg-[#F39C3D] text-[#1a0f00] flex items-center justify-center text-[11px] font-black shadow-md">
                ✓
              </div>
              <div className="text-[13px] font-bold text-[#FFF8EB] leading-snug">
                فالطريق
              </div>
              <div className="text-[11px] text-[#C8B08A]">اليوم، 11:40</div>
            </div>

            {/* Step 3 */}
            <div className="relative">
              <div className="absolute -right-7 top-0.5 w-5 h-5 rounded-full bg-[#F39C3D] text-[#1a0f00] flex items-center justify-center text-[11px] font-black shadow-md">
                ✓
              </div>
              <div className="text-[13px] font-bold text-[#FFF8EB] leading-snug">
                وصلات
              </div>
              <div className="text-[11px] text-[#C8B08A]">اليوم، 13:20</div>
            </div>

            {/* Step 4 (Active) */}
            <div className="relative">
              <div className="absolute -right-7 top-0.5 w-5 h-5 rounded-full bg-[#1a0f00] border-2 border-[#F39C3D] flex items-center justify-center shadow-[0_0_10px_rgba(243,156,61,0.6)]">
                <span className="w-2 h-2 rounded-full bg-[#F5D799]" />
              </div>
              <div className="text-[13px] font-bold text-[#FFF8EB] leading-snug">
                تسلمات
              </div>
              <div className="text-[11px] text-[#E6C37A]">متوقع • 15:45 • جاري الآن</div>
            </div>
          </div>
        </div>

        {/* 3. QR Code & Expected Arrival Split Card */}
        <div className="rounded-[22px] bg-[#1a0f00]/80 backdrop-blur-md border border-[#D4AF37]/65 p-3.5 shadow-2xl grid grid-cols-2 gap-3 items-center">
          {/* Right Column (RTL): Expected Arrival */}
          <div className="text-right pr-1 border-l border-[#D4AF37]/30 pl-2 space-y-1.5">
            <div className="flex items-center justify-start gap-1.5 text-[#F5D799] font-bold text-[14px]">
              <span>الوصول المتوقع</span>
              <Clock className="w-4 h-4 text-[#E6C37A]" />
            </div>
            <div className="text-[12px] font-bold text-[#FFF8EB]">
              اليوم، 17:30 • 3 س 10 د
            </div>
            <div className="text-[11px] text-[#D9B36C] font-mono" dir="ltr">
              → 142 km to Nouadhibou
            </div>
          </div>

          {/* Left Column (RTL): Golden QR Code */}
          <div
            onClick={onOpenParcels}
            className="flex flex-col items-center justify-center cursor-pointer"
          >
            <span className="text-[12px] font-bold text-[#F5D799] mb-1.5">رمز الاستلام QR</span>
            <div className="flex items-center gap-2">
              <div className="w-[74px] h-[74px] rounded-lg bg-[#E5953E] p-1.5 shadow-md flex items-center justify-center">
                <svg viewBox="0 0 21 21" className="w-full h-full fill-[#1a0f00]">
                  <path d="M0,0 h7 v7 h-7 z M1,1 v5 h5 v-5 z M2,2 h3 v3 h-3 z M14,0 h7 v7 h-7 z M15,1 v5 h5 v-5 z M16,2 h3 v3 h-3 z M0,14 h7 v7 h-7 z M1,15 v5 h5 v-5 z M2,16 h3 v3 h-3 z M8,0 h2 v2 h-2 z M11,1 h2 v2 h-2 z M8,4 h3 v2 h-3 z M12,4 h1 v3 h-1 z M0,8 h3 v2 h-3 z M4,8 h2 v3 h-2 z M8,8 h5 v2 h-5 z M15,8 h2 v2 h-2 z M18,9 h3 v2 h-3 z M1,11 h2 v2 h-2 z M6,11 h3 v2 h-3 z M11,11 h2 v3 h-2 z M14,12 h3 v2 h-3 z M8,15 h2 v3 h-2 z M12,16 h2 v2 h-2 z M15,15 h3 v3 h-3 z M19,15 h2 v2 h-2 z M9,19 h4 v2 h-4 z M15,19 h6 v2 h-6 z" />
                </svg>
              </div>
              <span className="text-[18px] font-bold text-[#D99B4E] font-mono">82</span>
            </div>
            <span className="text-[10px] font-bold text-[#E6C37A] mt-1.5">امسح عند الاستلام</span>
          </div>
        </div>

        {/* 4. Bottom Dual Action Buttons (Golden CTA + Outlined Brown/Gold) */}
        <div className="grid grid-cols-2 gap-2.5 pt-0.5">
          <button
            onClick={onOpenParcels}
            className="py-3 px-3 rounded-2xl bg-gradient-to-r from-[#F5B05B] via-[#E5953E] to-[#D4882A] hover:brightness-110 text-[#1a0f00] font-black text-[13px] flex items-center justify-center gap-1.5 shadow-lg shadow-[#E5953E]/25 border border-[#F8C885] active:scale-95 transition"
          >
            <span>تفاصيل الشحنة</span>
            <Package className="w-4 h-4 stroke-[2.5]" />
          </button>

          <button
            onClick={shareInviteViaWhatsApp}
            className="py-3 px-3 rounded-2xl bg-[#1a0f00]/90 hover:bg-[#2a1800] text-[#E6C37A] font-bold text-[13px] flex items-center justify-center gap-1.5 border border-[#D4AF37]/65 active:scale-95 transition"
          >
            <span>مشاركة التتبع</span>
            <Share2 className="w-4 h-4 text-[#D4AF37]" />
          </button>
        </div>
      </div>

      {/* ===================================================================== */}
      {/* EXECUTIVE ADMINISTRATION & STATION BALANCES (Mobile 390px Cards)      */}
      {/* ===================================================================== */}
      <div className="rounded-[22px] bg-[#1a0f00]/80 backdrop-blur-md border border-[#D4AF37]/50 p-4 shadow-2xl space-y-3">
        <div className="flex items-center justify-between border-b border-[#D4AF37]/25 pb-3">
          <div className="flex items-center gap-2.5">
            <div 
              className="w-11 h-11 rounded-full border border-[#D4AF37] shrink-0 overflow-hidden flex items-center justify-center p-0"
              style={{ background: 'transparent', borderRadius: '50%', padding: 0, overflow: 'hidden' }}
            >
              <img 
                src="/logo.png" 
                alt="محطة الاتحادية" 
                style={{ borderRadius: '50%', width: '100%', height: '100%', objectFit: 'cover', background: 'transparent', display: 'block' }}
              />
            </div>
            <div>
              <h2 className="text-sm font-black text-[#F5D799]">
                لوحة الإشراف العام
              </h2>
              <p className="text-[11px] text-[#C8B08A] font-medium">
                المغرب ⇋ موريتانيا • {stations.length} محطات
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowDailyReport(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-[#120a00] border border-[#D4AF37]/50 text-[#E6C37A] text-[11px] font-bold transition active:scale-95"
          >
            <Calendar className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>التقرير اليومي</span>
          </button>
        </div>

        {/* Quick Action Buttons */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={onOpenNewParcel}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] text-xs font-black transition shadow-md active:scale-95"
          >
            <Package className="w-4 h-4 stroke-[2.5]" />
            <span>إرسالية جديدة</span>
          </button>

          <button
            onClick={onOpenNewVoucher}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-[#120a00] border border-[#D4AF37]/60 text-[#E6C37A] text-xs font-bold transition active:scale-95"
          >
            <Coins className="w-4 h-4 text-[#D4AF37]" />
            <span>سند مالي</span>
          </button>
        </div>

        {/* Global Cash Breakdown Across All Stations */}
        <div className="space-y-2 pt-1">
          <div className="bg-[#120a00]/90 p-3 rounded-xl border border-[#D4AF37]/30 flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-[#C8B08A] block">إجمالي النقد بالدرهم (MAD) 🇲🇦</span>
              <span className="text-[10px] text-[#A68966]">صناديق المحطات بالمغرب</span>
            </div>
            <div className="text-lg font-black font-mono text-[#F5D799]">
              {globalTotals.totalMad.toLocaleString()} <span className="text-[10px] font-sans font-normal text-[#C8B08A]">درهم</span>
            </div>
          </div>

          <div className="bg-[#120a00]/90 p-3 rounded-xl border border-[#D4AF37]/30 flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-[#C8B08A] block">إجمالي النقد بالأوقية (MRU) 🇲🇷</span>
              <span className="text-[10px] text-[#A68966]">صناديق المحطات بموريتانيا</span>
            </div>
            <div className="text-lg font-black font-mono text-[#F5D799]">
              {globalTotals.totalMru.toLocaleString()} <span className="text-[10px] font-sans font-normal text-[#C8B08A]">أوقية</span>
            </div>
          </div>

          <div className="bg-gradient-to-l from-[#6E4720]/50 to-[#120a00]/90 p-3 rounded-xl border border-[#D4AF37]/45 flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-[#E6C37A] block">القيمة الإجمالية التقديرية</span>
              <span className="text-[10px] text-[#C8B08A] font-mono" dir="ltr">1 MAD ≈ {exchangeRate} MRU</span>
            </div>
            <div className="text-lg font-black font-mono text-[#F3A952]">
              ~{globalTotals.equivMad.toLocaleString()} <span className="text-[10px] font-sans font-normal text-[#C8B08A]">درهم</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Cross-border Freight & Parcels Logistics KPIs */}
      <div className="grid grid-cols-2 gap-2.5">
        <div 
          onClick={onOpenParcels}
          className="bg-[#1a0f00]/80 border border-[#D4AF37]/45 rounded-[20px] p-3.5 shadow-md cursor-pointer transition active:scale-95"
        >
          <div className="flex items-center justify-between text-[#C8B08A] mb-1">
            <span className="text-[11px] font-bold">إجمالي الكوليات</span>
            <Package className="w-4 h-4 text-[#D4AF37]" />
          </div>
          <div className="text-xl font-black font-mono text-[#FFF8EB]">{parcelStats.total}</div>
          <span className="text-[10px] text-[#A68966] mt-0.5 block">شحنة مسجلة بالنظام</span>
        </div>

        <div 
          onClick={onOpenParcels}
          className="bg-[#1a0f00]/80 border border-[#D4AF37]/45 rounded-[20px] p-3.5 shadow-md cursor-pointer transition active:scale-95"
        >
          <div className="flex items-center justify-between text-[#E6C37A] mb-1">
            <span className="text-[11px] font-bold">في الطريق (الكركرات)</span>
            <Truck className="w-4 h-4 text-[#F3A952]" />
          </div>
          <div className="text-xl font-black font-mono text-[#F3A952]">{parcelStats.inTransit}</div>
          <span className="text-[10px] text-[#C8B08A] mt-0.5 block">عابرة للحدود الآن</span>
        </div>

        <div 
          onClick={onOpenParcels}
          className="bg-[#1a0f00]/80 border border-[#D4AF37]/45 rounded-[20px] p-3.5 shadow-md cursor-pointer transition active:scale-95"
        >
          <div className="flex items-center justify-between text-[#E6C37A] mb-1">
            <span className="text-[11px] font-bold">وصلت محطة الوصول</span>
            <Compass className="w-4 h-4 text-[#D4AF37]" />
          </div>
          <div className="text-xl font-black font-mono text-[#FFF8EB]">{parcelStats.arrived}</div>
          <span className="text-[10px] text-[#C8B08A] mt-0.5 block">جاهزة للتسليم للزبون</span>
        </div>

        <div 
          onClick={onOpenParcels}
          className="bg-[#1a0f00]/80 border border-[#D4AF37]/45 rounded-[20px] p-3.5 shadow-md cursor-pointer transition active:scale-95"
        >
          <div className="flex items-center justify-between text-[#E6C37A] mb-1">
            <span className="text-[11px] font-bold">تم التسليم بنجاح</span>
            <CheckCircle2 className="w-4 h-4 text-[#F3A952]" />
          </div>
          <div className="text-xl font-black font-mono text-[#F5D799]">{parcelStats.delivered}</div>
          <span className="text-[10px] text-[#C8B08A] mt-0.5 block">مكتملة ومؤداة</span>
        </div>
      </div>

      {/* 3. Stations Breakdown List (Morocco + Mauritania Stations) */}
      <div className="bg-[#1a0f00]/80 border border-[#D4AF37]/50 rounded-[22px] p-4 shadow-xl space-y-3">
        <div className="flex items-center justify-between border-b border-[#D4AF37]/25 pb-2.5">
          <div>
            <h3 className="text-xs font-black text-[#F5D799] flex items-center gap-1.5">
              <Store className="w-4 h-4 text-[#D4AF37]" />
              <span>محطات النقل الدولي ({stations.length})</span>
            </h3>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setShowAdjustmentModal(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-[#120a00] border border-[#D4AF37]/40 text-[11px] font-bold text-[#E6C37A] transition"
              title="تسوية رصيد الصندوق"
            >
              <SlidersHorizontal className="w-3 h-3" />
              <span>تسوية</span>
            </button>

            <button
              onClick={() => setShowNewStationModal(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] text-[11px] font-black transition shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>إضافة محطة</span>
            </button>
          </div>
        </div>

        {/* Stations List */}
        {stations.length === 0 ? (
          <div className="bg-[#120a00] border border-dashed border-[#D4AF37]/30 rounded-2xl p-5 text-center text-xs text-[#C8B08A]">
            لا توجد محطات مسجلة حالياً — يمكنك الضغط على &quot;إضافة محطة&quot; لإضافة محطة جديدة.
          </div>
        ) : (
          <div className="space-y-2.5">
            {stations.map(station => {
              const bals = stationBalances[station.id] || {};
              const stMad = bals['MAD'] || 0;
              const stMru = bals['MRU'] || 0;

              return (
                <div
                  key={station.id}
                  className="bg-[#120a00]/90 border border-[#D4AF37]/35 rounded-2xl p-3.5 space-y-2.5"
                >
                  <div className="flex items-center justify-between border-b border-[#D4AF37]/20 pb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-base">{station.country === 'MA' ? '🇲🇦' : '🇲🇷'}</span>
                      <div>
                        <h4 className="text-xs font-bold text-[#FFF8EB]">{station.name}</h4>
                        <p className="text-[10px] text-[#C8B08A]">
                          {station.city} {station.phone ? `• ${station.phone}` : ''}
                        </p>
                      </div>
                    </div>

                    <span className="text-[9px] px-2 py-0.5 rounded-full bg-[#1a0f00] border border-[#D4AF37]/40 text-[#E6C37A] font-bold">
                      {station.country === 'MA' ? 'المغرب' : 'موريتانيا'}
                    </span>
                  </div>

                  {/* Cash Balances in Station */}
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="bg-[#1a0f00]/80 p-2.5 rounded-xl border border-[#D4AF37]/25">
                      <span className="text-[10px] text-[#C8B08A] block mb-0.5">صندوق الدرهم (MAD)</span>
                      <div className={`font-mono font-black text-sm ${stMad < 0 ? 'text-rose-400' : 'text-[#F5D799]'}`}>
                        {stMad.toLocaleString()} <span className="text-[10px] font-sans font-normal text-[#C8B08A]">درهم</span>
                      </div>
                    </div>

                    <div className="bg-[#1a0f00]/80 p-2.5 rounded-xl border border-[#D4AF37]/25">
                      <span className="text-[10px] text-[#C8B08A] block mb-0.5">صندوق الأوقية (MRU)</span>
                      <div className={`font-mono font-black text-sm ${stMru < 0 ? 'text-rose-400' : 'text-[#F5D799]'}`}>
                        {stMru.toLocaleString()} <span className="text-[10px] font-sans font-normal text-[#C8B08A]">أوقية</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 4. Team & Invite Code Banner */}
      <div className="bg-[#1a0f00]/80 border border-[#D4AF37]/50 rounded-[22px] p-4 shadow-lg space-y-3">
        <div>
          <span className="text-xs font-black text-[#F5D799] block mb-1">
            فريق عمل محطة الاتحادية ({teamMembers.length} أعضاء):
          </span>
          <p className="text-[11px] text-[#C8B08A]">
            رمز الدعوة لانضمام العمال ومسؤولي المحطات:
          </p>
          <div className="mt-2 inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#120a00] border border-[#D4AF37]/45 text-[#E6C37A] font-mono text-sm font-black tracking-widest" dir="ltr">
            {currentTeam?.invite_code || '84729103'}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setShowAddWorkerModal(true)}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] text-xs font-black transition shadow-md active:scale-95"
          >
            <UserPlus className="w-4 h-4" />
            <span>إضافة موظف</span>
          </button>
          <button
            onClick={shareInviteViaWhatsApp}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-[#120a00] border border-[#D4AF37]/60 text-[#E6C37A] text-xs font-bold transition active:scale-95"
          >
            <Share2 className="w-4 h-4 text-[#D4AF37]" />
            <span>مشاركة الرمز</span>
          </button>
        </div>
      </div>

      {/* Adjustment Modal */}
      {showAdjustmentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="w-full max-w-[360px] bg-[#1a0f00] border border-[#D4AF37]/60 rounded-3xl p-5 shadow-2xl space-y-4 text-right">
            <div className="flex items-center justify-between border-b border-[#D4AF37]/25 pb-2">
              <h3 className="text-sm font-bold text-[#F5D799]">تسوية محاسبية لصندوق المحطة</h3>
              <button onClick={() => setShowAdjustmentModal(false)} className="text-[#C8B08A] hover:text-white">✕</button>
            </div>

            <form onSubmit={handleAdjustmentSubmit} className="space-y-3 text-xs">
              <div>
                <label className="text-[#E6C37A] font-bold block mb-1">المحطة:</label>
                <select
                  value={adjStationId}
                  onChange={(e) => setAdjStationId(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white font-bold"
                >
                  {stations.map(st => (
                    <option key={st.id} value={st.id}>{st.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[#E6C37A] font-bold block mb-1">العملة:</label>
                <select
                  value={adjCurrency}
                  onChange={(e) => setAdjCurrency(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white font-bold"
                >
                  <option value="MAD">درهم مغربي (MAD)</option>
                  <option value="MRU">أوقية موريتانية (MRU)</option>
                </select>
              </div>

              <div>
                <label className="text-[#E6C37A] font-bold block mb-1">
                  المبلغ (موجب للإضافة وسالب للخصم):
                </label>
                <input
                  type="number"
                  step="any"
                  required
                  value={adjAmount}
                  onChange={(e) => setAdjAmount(e.target.value)}
                  placeholder="مثال: 5000 أو -200"
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white font-mono font-bold"
                />
              </div>

              <div>
                <label className="text-[#E6C37A] font-bold block mb-1">بيان التسوية / الملاحظة:</label>
                <input
                  type="text"
                  required
                  value={adjNote}
                  onChange={(e) => setAdjNote(e.target.value)}
                  placeholder="مثال: تغذية الصندوق برصيد نقدي من الإدارة"
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAdjustmentModal(false)}
                  className="px-4 py-2 rounded-xl bg-[#120a00] border border-[#D4AF37]/40 text-[#C8B08A] font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black shadow-md"
                >
                  تأكيد التسوية
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* New Station Modal */}
      {showNewStationModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="w-full max-w-[360px] bg-[#1a0f00] border border-[#D4AF37]/60 rounded-3xl p-5 shadow-2xl space-y-4 text-right">
            <div className="flex items-center justify-between border-b border-[#D4AF37]/25 pb-2">
              <h3 className="text-sm font-bold text-[#F5D799]">إضافة محطة نقل دولية جديدة</h3>
              <button onClick={() => setShowNewStationModal(false)} className="text-[#C8B08A] hover:text-white">✕</button>
            </div>

            <form onSubmit={handleNewStationSubmit} className="space-y-3 text-xs">
              <div>
                <label className="text-[#E6C37A] font-bold block mb-1">اسم المحطة:</label>
                <input
                  type="text"
                  required
                  value={newStationName}
                  onChange={(e) => setNewStationName(e.target.value)}
                  placeholder="مثال: محطة العيون - المسيرة"
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-[#E6C37A] font-bold block mb-1">المدينة:</label>
                <input
                  type="text"
                  required
                  value={newStationCity}
                  onChange={(e) => setNewStationCity(e.target.value)}
                  placeholder="مثال: العيون"
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-[#E6C37A] font-bold block mb-1">الدولة:</label>
                <select
                  value={newStationCountry}
                  onChange={(e) => setNewStationCountry(e.target.value as 'MA' | 'MR')}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white font-bold"
                >
                  <option value="MA">المملكة المغربية 🇲🇦</option>
                  <option value="MR">الجمهورية الإسلامية الموريتانية 🇲🇷</option>
                </select>
              </div>

              <div>
                <label className="text-[#E6C37A] font-bold block mb-1">رقم الهاتف للتواصل (اختياري):</label>
                <input
                  type="tel"
                  dir="ltr"
                  value={newStationPhone}
                  onChange={(e) => setNewStationPhone(e.target.value)}
                  placeholder="+212 528 000 000"
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white text-right font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewStationModal(false)}
                  className="px-4 py-2 rounded-xl bg-[#120a00] border border-[#D4AF37]/40 text-[#C8B08A] font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black shadow-md"
                >
                  إضافة المحطة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Worker Modal */}
      {showAddWorkerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="w-full max-w-[360px] bg-[#1a0f00] border border-[#D4AF37]/60 rounded-3xl p-5 shadow-2xl space-y-4 text-right">
            <div className="flex items-center justify-between border-b border-[#D4AF37]/25 pb-2">
              <h3 className="text-sm font-bold text-[#F5D799] flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-[#D4AF37]" />
                <span>إضافة موظف جديد وتعيينه بالمحطة</span>
              </h3>
              <button onClick={() => setShowAddWorkerModal(false)} className="text-[#C8B08A] hover:text-white">✕</button>
            </div>

            <form onSubmit={handleAddWorkerSubmit} className="space-y-3 text-xs">
              <div>
                <label className="text-[#E6C37A] font-bold block mb-1">اسم الموظف الكامل *</label>
                <input
                  type="text"
                  required
                  value={workerName}
                  onChange={(e) => setWorkerName(e.target.value)}
                  placeholder="مثال: إبراهيم الصحراوي أو محمد الأمين"
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div>
                <label className="text-[#E6C37A] font-bold block mb-1">رقم هاتف الموظف *</label>
                <input
                  type="tel"
                  required
                  dir="ltr"
                  value={workerPhone}
                  onChange={(e) => setWorkerPhone(e.target.value)}
                  placeholder="+212 600 000 000 أو +222 40 00 00 00"
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white text-right font-mono focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div>
                <label className="text-[#E6C37A] font-bold block mb-1">محطة العمل المعين بها *</label>
                <select
                  value={workerStationId}
                  onChange={(e) => setWorkerStationId(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white font-bold focus:outline-none focus:border-[#D4AF37]"
                >
                  {stations.map(st => (
                    <option key={st.id} value={st.id}>
                      {st.name} ({st.city})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[#E6C37A] font-bold block mb-1">الصلاحية *</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setWorkerRole('worker')}
                    className={`p-2 rounded-xl border text-center transition font-bold ${
                      workerRole === 'worker'
                        ? 'bg-gradient-to-r from-[#F5B05B] to-[#D4882A] border-[#F8C885] text-[#1a0f00]'
                        : 'bg-[#120a00] border-[#D4AF37]/30 text-[#C8B08A]'
                    }`}
                  >
                    💼 موظف محطة
                  </button>
                  <button
                    type="button"
                    onClick={() => setWorkerRole('owner')}
                    className={`p-2 rounded-xl border text-center transition font-bold ${
                      workerRole === 'owner'
                        ? 'bg-gradient-to-r from-[#F5B05B] to-[#D4882A] border-[#F8C885] text-[#1a0f00]'
                        : 'bg-[#120a00] border-[#D4AF37]/30 text-[#C8B08A]'
                    }`}
                  >
                    👑 مدير فرعي
                  </button>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-[#D4AF37]/25">
                <button
                  type="button"
                  onClick={() => setShowAddWorkerModal(false)}
                  className="px-4 py-2 rounded-xl bg-[#120a00] border border-[#D4AF37]/40 text-[#C8B08A] font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black shadow-md"
                >
                  حفظ وتعيين الموظف
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Daily Financial Report Modal */}
      <DailyFinancialReportModal
        isOpen={showDailyReport}
        onClose={() => setShowDailyReport(false)}
      />

    </div>
  );
};
