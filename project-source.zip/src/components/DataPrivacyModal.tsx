import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  ShieldCheck, 
  X, 
  Copy, 
  Check, 
  Share2, 
  Users, 
  Lock, 
  Eye, 
  EyeOff, 
  Send, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  Coins,
  Package,
  FileBarChart,
  MessageCircle,
  RotateCw,
  UserCheck,
  UserX
} from 'lucide-react';

interface DataPrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DataPrivacyModal: React.FC<DataPrivacyModalProps> = ({ isOpen, onClose }) => {
  const { 
    currentUser, 
    userRole, 
    currentWorkspace, 
    collaborations, 
    joinRequests,
    sendCollaborationRequest,
    respondToCollaboration,
    updateSharingSettings,
    approveJoinRequest,
    rejectJoinRequest,
    renewInviteCode,
    showToast 
  } = useApp();

  const [copiedWsId, setCopiedWsId] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [targetWsInput, setTargetWsInput] = useState('');
  const [isSubmittingCollab, setIsSubmittingCollab] = useState(false);
  const [isRenewingCode, setIsRenewingCode] = useState(false);

  if (!isOpen) return null;

  const handleCopyWsId = () => {
    if (!currentWorkspace?.short_id) return;
    navigator.clipboard.writeText(currentWorkspace.short_id);
    setCopiedWsId(true);
    showToast('تم نسخ معرّف مساحة العمل (6 أحرف) بنجاح', 'success');
    setTimeout(() => setCopiedWsId(false), 2000);
  };

  const handleCopyCode = () => {
    if (!currentWorkspace?.invite_code) return;
    navigator.clipboard.writeText(currentWorkspace.invite_code);
    setCopiedCode(true);
    showToast('تم نسخ رمز دعوة العمال بنجاح', 'success');
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleRenewCode = async () => {
    setIsRenewingCode(true);
    try {
      await renewInviteCode();
      showToast('تم توليد رمز دعوة جديد عشوائي بنجاح', 'success');
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setIsRenewingCode(false);
    }
  };

  const handleSendCollaboration = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanId = targetWsInput.trim().toUpperCase();
    if (cleanId.length !== 6) {
      showToast('معرّف مساحة العمل يجب أن يتكون من 6 أحرف', 'error');
      return;
    }

    setIsSubmittingCollab(true);
    try {
      const res = await sendCollaborationRequest(cleanId);
      if (res.success) {
        showToast(res.message || 'تم إرسال طلب التعاون بنجاح', 'success');
        setTargetWsInput('');
      } else {
        showToast(res.error || 'تعذر إرسال طلب التعاون', 'error');
      }
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setIsSubmittingCollab(false);
    }
  };

  const pendingJoinRequests = joinRequests.filter(r => r.status === 'pending');
  const myWorkspaceId = currentWorkspace?.id;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 animate-fadeIn overflow-y-auto">
      <div className="fixed inset-0 bg-[#060A14]/90 backdrop-blur-xs" onClick={onClose} />

      <div 
        className="w-full max-w-2xl rounded-3xl bg-[#0F172A] border border-amber-500/30 p-5 sm:p-6 shadow-2xl text-right overflow-hidden relative z-10 my-4 space-y-5"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500/20 to-emerald-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <span>من يمكنه رؤية بياناتي؟</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                  عزل تام 100%
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                التحكم بالخصوصية، وموافقة انضمام العمال، والتعاون المستقل بين المدراء
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 1. Workspace Isolation & Identity */}
        <div className="bg-[#0B1220] p-4 rounded-2xl border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-slate-400 block">معرّف مساحة العمل الفريد (الخاص بمديرك):</span>
              <span className="text-xs text-white font-bold">{currentWorkspace?.name}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xl sm:text-2xl font-black font-mono tracking-widest text-amber-400 bg-slate-900 px-3 py-1 rounded-xl border border-amber-500/30">
                {currentWorkspace?.short_id || '------'}
              </span>
              <button
                onClick={handleCopyWsId}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition"
                title="نسخ المعرف"
              >
                {copiedWsId ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            كل مدير يملك مساحة عمل مستقلة معزولة تماماً في قاعدة البيانات (RLS). لا يمكن لأي شخص آخر الاطلاع على سجلاتك أو محطاتك إلا بعد تبادل الموافقة بينكما واختيار ما تود مشاركته تحديداً.
          </p>
        </div>

        {/* 2. WhatsApp Number Privacy Reassurance */}
        <div className="bg-emerald-950/20 border border-emerald-500/30 p-3.5 rounded-2xl flex items-start gap-3">
          <MessageCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          <div className="text-xs space-y-1">
            <span className="font-bold text-emerald-300 block">خصوصية رقم الواتساب:</span>
            <p className="text-slate-300 leading-relaxed text-[11px]">
              رقم الواتساب الخاص بك ({currentUser?.whatsapp_number || currentUser?.phone}) محمي ومحجوب عن الغرباء؛ فهو يظهر <strong>فقط</strong> لأعضاء مساحة عملك وللمدراء الآخرين الذين وافقت على التعاون معهم.
            </p>
          </div>
        </div>

        {/* 3. Worker Join Requests & Renewable Code (Admin Only) */}
        {userRole === 'owner' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-black text-amber-400 flex items-center gap-1.5">
                <Users className="w-4 h-4" />
                <span>انضمام العمال بالمحطات والموافقة عليهم</span>
              </h3>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono text-slate-300 bg-slate-900 px-2 py-0.5 rounded-lg border border-slate-700">
                  رمز الدعوة: {currentWorkspace?.invite_code}
                </span>
                <button
                  onClick={handleCopyCode}
                  className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
                  title="نسخ رمز الدعوة"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={handleRenewCode}
                  disabled={isRenewingCode}
                  className="flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[10px] text-amber-300 border border-slate-700"
                  title="تجديد رمز الدعوة"
                >
                  <RotateCw className={`w-3 h-3 ${isRenewingCode ? 'animate-spin' : ''}`} />
                  <span>تجديد الرمز</span>
                </button>
              </div>
            </div>

            {/* Pending Requests List */}
            {pendingJoinRequests.length > 0 ? (
              <div className="space-y-2">
                <span className="text-[11px] font-bold text-amber-300 block">
                  طلبات معلقة بانتظار موافقتك ({pendingJoinRequests.length}):
                </span>
                {pendingJoinRequests.map(req => (
                  <div 
                    key={req.id}
                    className="p-3 rounded-2xl bg-[#0B1220] border border-amber-500/30 flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-white block">{req.user_name}</span>
                      <div className="flex items-center gap-3 text-[10px] text-slate-400 mt-0.5">
                        <span dir="ltr">هاتف: {req.user_phone}</span>
                        <span dir="ltr">واتساب: {req.user_whatsapp}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => approveJoinRequest(req.id)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs transition"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>قبول العامل</span>
                      </button>
                      <button
                        onClick={() => rejectJoinRequest(req.id)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 font-bold text-xs border border-rose-500/30 transition"
                      >
                        <UserX className="w-3.5 h-3.5" />
                        <span>رفض</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-3 rounded-xl bg-[#0B1220] border border-slate-800 text-[11px] text-slate-400">
                لا توجد طلبات انضمام جديدة معلقة حالياً. عند إدخال العامل لرمز الدعوة، سيظهر طلبه هنا للموافقة عليه قبل منحه أي صلاحية.
              </div>
            )}
          </div>
        )}

        {/* 4. Collaboration Between Admins (Admin Only) */}
        {userRole === 'owner' && (
          <div className="space-y-3 pt-2 border-t border-slate-800">
            <h3 className="text-xs font-black text-amber-400 flex items-center gap-1.5">
              <Share2 className="w-4 h-4" />
              <span>التعاون والمشاركة الاختيارية مع مدراء آخرين</span>
            </h3>

            {/* Send Request Form */}
            <form onSubmit={handleSendCollaboration} className="flex gap-2">
              <input
                type="text"
                placeholder="أدخل معرّف مساحة العمل للمدير الآخر (6 أحرف)"
                maxLength={6}
                value={targetWsInput}
                onChange={e => setTargetWsInput(e.target.value.toUpperCase())}
                className="flex-1 bg-[#0B1220] border border-slate-700 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white font-mono tracking-widest placeholder-slate-500 focus:outline-none"
              />
              <button
                type="submit"
                disabled={isSubmittingCollab || !targetWsInput.trim()}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 text-xs font-black flex items-center gap-1.5 transition disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" />
                <span>إرسال طلب</span>
              </button>
            </form>

            {/* List of Collaborations */}
            <div className="space-y-3">
              {collaborations.length === 0 ? (
                <div className="p-3 rounded-xl bg-[#0B1220] border border-slate-800 text-[11px] text-slate-400">
                  لا توجد شراكات مع مدراء آخرين حتى الآن. بياناتك معزولة 100% ولا يراها أي شخص سواك.
                </div>
              ) : (
                collaborations.map(collab => {
                  const isRequester = collab.requester_workspace_id === myWorkspaceId;
                  const partnerName = isRequester ? (collab.target_workspace_name || 'إدارة شريكة') : (collab.requester_workspace_name || 'إدارة شريكة');
                  const isPendingForMe = !isRequester && collab.status === 'pending';

                  const myShareCash = isRequester ? collab.requester_share_cash : collab.target_share_cash;
                  const myShareParcels = isRequester ? collab.requester_share_parcels : collab.target_share_parcels;
                  const myShareReports = isRequester ? collab.requester_share_reports : collab.target_share_reports;

                  const partnerShareCash = isRequester ? collab.target_share_cash : collab.requester_share_cash;
                  const partnerShareParcels = isRequester ? collab.target_share_parcels : collab.requester_share_parcels;

                  return (
                    <div 
                      key={collab.id}
                      className="p-4 rounded-2xl bg-[#0B1220] border border-slate-800 space-y-3 text-xs"
                    >
                      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                        <div>
                          <span className="font-black text-white block text-sm">{partnerName}</span>
                          <span className="text-[10px] text-slate-400">
                            {collab.status === 'accepted' ? 'شراكة نشطة ومقبولة' : collab.status === 'pending' ? 'طلب شراكة قيد الانتظار' : 'طلب مرفوض'}
                          </span>
                        </div>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                          collab.status === 'accepted' 
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        }`}>
                          {collab.status === 'accepted' ? 'نشط' : 'قيد المراجعة'}
                        </span>
                      </div>

                      {/* If pending for this user to accept */}
                      {isPendingForMe && (
                        <div className="flex items-center justify-between bg-slate-900/80 p-3 rounded-xl border border-amber-500/30">
                          <span className="text-[11px] text-slate-300">
                            أرسل لك هذا المدير طلب تعاون. هل تقبل؟
                          </span>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => respondToCollaboration(collab.id, true)}
                              className="px-3 py-1.5 rounded-xl bg-emerald-500 text-slate-950 font-black text-xs"
                            >
                              قبول الشراكة
                            </button>
                            <button
                              onClick={() => respondToCollaboration(collab.id, false)}
                              className="px-3 py-1.5 rounded-xl bg-slate-800 text-rose-400 font-bold text-xs"
                            >
                              رفض
                            </button>
                          </div>
                        </div>
                      )}

                      {/* If accepted: Show Granular Controls */}
                      {collab.status === 'accepted' && (
                        <div className="space-y-3 pt-1">
                          <span className="text-[11px] font-bold text-amber-300 block">
                            ماذا تختار أن تشاركه أنت مع هذا المدير؟ (الافتراضي: لا شيء):
                          </span>
                          
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                            {/* Cash toggle */}
                            <button
                              onClick={() => updateSharingSettings(collab.id, !myShareCash, myShareParcels, myShareReports)}
                              className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 text-right transition ${
                                myShareCash 
                                  ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300' 
                                  : 'bg-slate-900 border-slate-800 text-slate-400'
                              }`}
                            >
                              <div className="flex items-center gap-1.5">
                                <Coins className="w-3.5 h-3.5" />
                                <span className="font-bold text-[11px]">حركة الأموال</span>
                              </div>
                              {myShareCash ? <Eye className="w-3.5 h-3.5 text-emerald-400" /> : <EyeOff className="w-3.5 h-3.5 text-slate-500" />}
                            </button>

                            {/* Parcels toggle */}
                            <button
                              onClick={() => updateSharingSettings(collab.id, myShareCash, !myShareParcels, myShareReports)}
                              className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 text-right transition ${
                                myShareParcels 
                                  ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300' 
                                  : 'bg-slate-900 border-slate-800 text-slate-400'
                              }`}
                            >
                              <div className="flex items-center gap-1.5">
                                <Package className="w-3.5 h-3.5" />
                                <span className="font-bold text-[11px]">تتبع الطرود</span>
                              </div>
                              {myShareParcels ? <Eye className="w-3.5 h-3.5 text-emerald-400" /> : <EyeOff className="w-3.5 h-3.5 text-slate-500" />}
                            </button>

                            {/* Reports toggle */}
                            <button
                              onClick={() => updateSharingSettings(collab.id, myShareCash, myShareParcels, !myShareReports)}
                              className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 text-right transition ${
                                myShareReports 
                                  ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300' 
                                  : 'bg-slate-900 border-slate-800 text-slate-400'
                              }`}
                            >
                              <div className="flex items-center gap-1.5">
                                <FileBarChart className="w-3.5 h-3.5" />
                                <span className="font-bold text-[11px]">التقارير المالية</span>
                              </div>
                              {myShareReports ? <Eye className="w-3.5 h-3.5 text-emerald-400" /> : <EyeOff className="w-3.5 h-3.5 text-slate-500" />}
                            </button>
                          </div>

                          {/* Partner status display */}
                          <div className="text-[10px] text-slate-400 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800/80 flex items-center justify-between">
                            <span>ما يشاركه الطرف الآخر معك حالياً:</span>
                            <span className="font-bold text-amber-300">
                              {partnerShareCash && partnerShareParcels ? 'الأموال والطرود' : partnerShareCash ? 'الأموال فقط' : partnerShareParcels ? 'الطرود فقط' : 'لم يفعّل أي مشاركة بعد (مخفي)'}
                            </span>
                          </div>

                          <p className="text-[10px] text-slate-500 italic">
                            * البيانات المشتركة تظهر بصلاحية القراءة فقط، ويمكنك إخفاؤها في أي وقت بنقرة واحدة دون التأثير على الطرف الآخر.
                          </p>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="pt-2 text-center">
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
