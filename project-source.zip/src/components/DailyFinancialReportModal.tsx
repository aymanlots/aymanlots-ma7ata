import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { X, Download, Calendar, DollarSign, ArrowDownLeft, ArrowUpRight, TrendingUp, Store } from 'lucide-react';

interface DailyFinancialReportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DailyFinancialReportModal: React.FC<DailyFinancialReportModalProps> = ({ isOpen, onClose }) => {
  const { 
    transactions, 
    stations, 
    currencies, 
    selectedStationId, 
    exchangeRate,
    convertCurrency 
  } = useApp();

  const [selectedStation, setSelectedStation] = useState<string>('all');
  const [reportDate, setReportDate] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });

  if (!isOpen) return null;

  // Filter transactions for report date & station
  const filteredTxs = useMemo(() => {
    return transactions.filter(tx => {
      if (tx.status !== 'confirmed' || tx.deleted_at) return false;
      if (selectedStation !== 'all' && tx.station_id !== selectedStation) return false;
      
      const txDate = tx.created_at.split('T')[0];
      return txDate === reportDate;
    });
  }, [transactions, selectedStation, reportDate]);

  // Aggregate by currency
  const summary = useMemo(() => {
    const res: Record<string, { in: number; out: number; net: number; count: number }> = {
      MAD: { in: 0, out: 0, net: 0, count: 0 },
      MRU: { in: 0, out: 0, net: 0, count: 0 },
    };

    filteredTxs.forEach(tx => {
      const curr = tx.currency || 'MAD';
      if (!res[curr]) {
        res[curr] = { in: 0, out: 0, net: 0, count: 0 };
      }

      const amt = Number(tx.amount) || 0;
      res[curr].count++;

      const isInflow = tx.type === 'cash_in' || tx.type === 'parcel_shipping_fee' || tx.type === 'parcel_cod_collection';
      const isOutflow = tx.type === 'cash_out' || tx.type === 'goods_payment' || tx.type === 'parcel_cod_payout';

      if (isInflow) {
        res[curr].in += amt;
      } else if (isOutflow) {
        res[curr].out += amt;
      }
    });

    Object.keys(res).forEach(c => {
      res[c].net = Math.round((res[c].in - res[c].out) * 100) / 100;
      res[c].in = Math.round(res[c].in * 100) / 100;
      res[c].out = Math.round(res[c].out * 100) / 100;
    });

    return res;
  }, [filteredTxs]);

  const handleExportCSV = () => {
    const headers = ['المعرف', 'التاريخ', 'المحطة', 'النوع', 'المبلغ', 'العملة', 'الهاتف', 'السبب', 'ملاحظات'];
    const rows = filteredTxs.map(t => [
      t.id,
      new Date(t.created_at).toLocaleString('ar-MA'),
      t.station_name || t.station_id,
      t.type,
      t.amount,
      t.currency,
      t.phone_number || '',
      `"${(t.reason || '').replace(/"/g, '""')}"`,
      `"${(t.note || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + 
      [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `تقرير_مالي_محطة_الاتحادية_${reportDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const currentStationObj = stations.find(s => s.id === selectedStation);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-[#0F172A] border border-amber-500/30 rounded-3xl shadow-2xl overflow-hidden my-6 text-right">
        
        {/* Top Bar (Hidden in Print) */}
        <div className="print:hidden flex items-center justify-between p-4 border-b border-slate-800 bg-[#0B1220]/90">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-500/15 text-amber-400">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">التقرير المالي اليومي للصناديق</h3>
              <p className="text-[11px] text-slate-400">كشف الإيرادات والمصروفات بالدرهم والأوقية</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition"
              title="تصدير إلى Excel / CSV"
            >
              <Download className="w-4 h-4" />
              <span>CSV</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Toolbar (Hidden in Print) */}
        <div className="print:hidden p-4 bg-[#0B1220] border-b border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div>
            <label className="text-[11px] font-bold text-slate-400 block mb-1">
              تاريخ الكشف:
            </label>
            <input
              type="date"
              value={reportDate}
              onChange={(e) => setReportDate(e.target.value)}
              className="w-full bg-[#0F172A] border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-mono"
            />
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-400 block mb-1">
              المحطة:
            </label>
            <select
              value={selectedStation}
              onChange={(e) => setSelectedStation(e.target.value)}
              className="w-full bg-[#0F172A] border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-bold"
            >
              <option value="all">جميع المحطات مجتمعة</option>
              {stations.map(st => (
                <option key={st.id} value={st.id}>{st.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Printable Statement Content */}
        <div className="p-6 overflow-y-auto max-h-[70vh] print:max-h-none print:p-0 print:bg-white print:text-black">
          <div className="bg-white text-slate-900 rounded-2xl p-6 shadow-inner print:shadow-none space-y-5">
            
            {/* Header */}
            <div className="text-center border-b border-dashed border-slate-300 pb-4">
              <div className="flex justify-center items-center gap-2 mb-2">
                <div 
                  className="w-12 h-12 rounded-full overflow-hidden flex items-center justify-center p-0 border border-slate-300 shadow-sm"
                  style={{ background: 'transparent', borderRadius: '50%', padding: 0, overflow: 'hidden' }}
                >
                  <img 
                    src="/logo.png" 
                    alt="محطة الاتحادية" 
                    style={{ borderRadius: '50%', width: '100%', height: '100%', objectFit: 'cover', background: 'transparent', display: 'block' }} 
                  />
                </div>
              </div>
              <h2 className="text-lg font-black text-slate-900">محطة الاتحادية - السفر ونقل البضائع والكوليات</h2>
              <p className="text-xs font-bold text-amber-800">التقرير المالي اليومي الشامل (Journal Financier)</p>
              <div className="flex justify-center gap-4 text-xs text-slate-600 mt-2">
                <span>التاريخ: <strong>{reportDate}</strong></span>
                <span>•</span>
                <span>المحطة: <strong>{currentStationObj ? currentStationObj.name : 'كافة المحطات'}</strong></span>
                <span>•</span>
                <span>عدد السندات: <strong>{filteredTxs.length}</strong></span>
              </div>
            </div>

            {/* Dual Currency Balance Summary Boxes */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* MAD Summary */}
              <div className="border border-slate-200 rounded-xl p-4 bg-slate-50">
                <div className="flex justify-between items-center mb-2 pb-1 border-b border-slate-200">
                  <span className="font-black text-sm text-slate-900">صندوق الدرهم المغربي (MAD)</span>
                  <span className="text-xs font-bold text-slate-500">{summary.MAD.count} عملية</span>
                </div>

                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-600">إجمالي المقبوضات (In):</span>
                    <span className="font-bold font-mono text-emerald-700">+{summary.MAD.in} MAD</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">إجمالي المصروفات (Out):</span>
                    <span className="font-bold font-mono text-rose-700">-{summary.MAD.out} MAD</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-slate-300 font-bold text-sm">
                    <span className="text-slate-900">الصافي اليومي (Net):</span>
                    <span className={`font-mono ${summary.MAD.net >= 0 ? 'text-emerald-800' : 'text-rose-800'}`}>
                      {summary.MAD.net} MAD
                    </span>
                  </div>
                </div>
              </div>

              {/* MRU Summary */}
              <div className="border border-slate-200 rounded-xl p-4 bg-slate-50">
                <div className="flex justify-between items-center mb-2 pb-1 border-b border-slate-200">
                  <span className="font-black text-sm text-slate-900">صندوق الأوقية الموريتانية (MRU)</span>
                  <span className="text-xs font-bold text-slate-500">{summary.MRU.count} عملية</span>
                </div>

                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-600">إجمالي المقبوضات (In):</span>
                    <span className="font-bold font-mono text-emerald-700">+{summary.MRU.in} MRU</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">إجمالي المصروفات (Out):</span>
                    <span className="font-bold font-mono text-rose-700">-{summary.MRU.out} MRU</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-slate-300 font-bold text-sm">
                    <span className="text-slate-900">الصافي اليومي (Net):</span>
                    <span className={`font-mono ${summary.MRU.net >= 0 ? 'text-emerald-800' : 'text-rose-800'}`}>
                      {summary.MRU.net} MRU
                    </span>
                  </div>
                </div>
              </div>

            </div>

            {/* Currency conversion rate footnote */}
            <div className="bg-amber-50 p-2.5 rounded-lg border border-amber-200 text-xs text-amber-950 flex items-center justify-between">
              <span>سعر الصرف المعتمد للتحويل:</span>
              <span className="font-mono font-bold">1 درهم مغربي ≈ {exchangeRate} أوقية موريتانية</span>
            </div>

            {/* Transactions table */}
            <div>
              <h4 className="font-bold text-xs text-slate-700 mb-2">تفاصيل السندات المسجلة اليوم:</h4>
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-100 border-b border-slate-300 text-slate-600">
                      <th className="p-2">الوقت</th>
                      <th className="p-2">المحطة</th>
                      <th className="p-2">النوع</th>
                      <th className="p-2">المبلغ</th>
                      <th className="p-2">البيان / السبب</th>
                      <th className="p-2">المسؤول</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {filteredTxs.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="text-center py-6 text-slate-400">
                          لا توجد سندات مسجلة في هذا اليوم
                        </td>
                      </tr>
                    ) : (
                      filteredTxs.map(t => {
                        const isInflow = t.type === 'cash_in' || t.type === 'parcel_shipping_fee' || t.type === 'parcel_cod_collection';
                        return (
                          <tr key={t.id} className="hover:bg-slate-50">
                            <td className="p-2 font-mono text-[11px] text-slate-500">
                              {new Date(t.created_at).toLocaleTimeString('ar-MA', { hour: '2-digit', minute: '2-digit' })}
                            </td>
                            <td className="p-2 text-[11px]">{t.station_name}</td>
                            <td className="p-2 text-[11px] font-bold">
                              {isInflow ? (
                                <span className="text-emerald-700">قبض (In)</span>
                              ) : (
                                <span className="text-rose-700">صرف (Out)</span>
                              )}
                            </td>
                            <td className="p-2 font-mono font-bold text-left" dir="ltr">
                              {isInflow ? `+${t.amount}` : `-${t.amount}`} {t.currency}
                            </td>
                            <td className="p-2 text-[11px] text-slate-700">{t.reason || t.note || '-'}</td>
                            <td className="p-2 text-[11px] text-slate-500">{t.creator_name}</td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Signatures */}
            <div className="grid grid-cols-2 gap-8 pt-8 border-t border-slate-300 text-center text-xs text-slate-600">
              <div>
                <p className="font-bold text-slate-800 mb-8">توقيع وخاتم أمين الصندوق بالمحطة</p>
                <div className="border-b border-dashed border-slate-400 w-36 mx-auto"></div>
              </div>
              <div>
                <p className="font-bold text-slate-800 mb-8">مصادقة مدير عام محطة الاتحادية</p>
                <div className="border-b border-dashed border-slate-400 w-36 mx-auto"></div>
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
