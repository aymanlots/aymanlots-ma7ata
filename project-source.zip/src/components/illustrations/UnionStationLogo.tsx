import React from 'react';

interface UnionStationLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showTagline?: boolean;
  stacked?: boolean;
}

export const UnionStationLogo: React.FC<UnionStationLogoProps> = ({
  className = '',
  size = 'md',
  showTagline = true,
  stacked = false,
}) => {
  const dimensions = {
    sm: { w: 42, h: 42, titleSize: 'text-sm', tagSize: 'text-[9px]' },
    md: { w: 56, h: 56, titleSize: 'text-base', tagSize: 'text-[11px]' },
    lg: { w: 72, h: 72, titleSize: 'text-xl', tagSize: 'text-xs' },
    xl: { w: 96, h: 96, titleSize: 'text-2xl', tagSize: 'text-sm' },
  }[size];

  return (
    <div className={`flex ${stacked ? 'flex-col items-center text-center' : 'items-center gap-3 text-right'} ${className}`} dir="rtl">
      <div 
        className="shrink-0 overflow-hidden rounded-full p-0 flex items-center justify-center"
        style={{ background: 'transparent', borderRadius: '50%', padding: 0, overflow: 'hidden' }}
      >
        <img
          src="/logo.png"
          alt="شعار محطة الاتحادية"
          width={dimensions.w}
          height={dimensions.h}
          style={{
            borderRadius: '50%',
            width: `${dimensions.w}px`,
            height: `${dimensions.h}px`,
            objectFit: 'cover',
            background: 'transparent',
            display: 'block'
          }}
          className="shrink-0 drop-shadow-md"
        />
      </div>

      {/* Typography */}
      <div className={stacked ? 'mt-2' : ''}>
        <div className={`font-black text-white leading-tight flex items-center ${stacked ? 'justify-center' : ''} gap-1.5 ${dimensions.titleSize}`}>
          <span>محطة الاتحادية</span>
        </div>
        {showTagline && (
          <p className={`font-bold text-amber-400 tracking-wide mt-0.5 leading-snug ${dimensions.tagSize}`}>
            السفر ونقل البضائع والكوليات
          </p>
        )}
      </div>
    </div>
  );
};
