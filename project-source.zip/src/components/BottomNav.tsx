import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  LayoutDashboard, 
  Package, 
  Coins, 
  Settings, 
  Plus, 
  X
} from 'lucide-react';

export type NavTab = 'dashboard' | 'parcels' | 'cash' | 'settings';

interface BottomNavProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onOpenNewVoucher: () => void;
  onOpenNewParcel: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onSelectTab,
  onOpenNewVoucher,
  onOpenNewParcel,
}) => {
  const { parcels, currentWorkspace } = useApp();
  const [showAddMenu, setShowAddMenu] = useState(false);

  // Check if parcels module is enabled (defaults to true)
  const isParcelsEnabled = currentWorkspace?.parcels_module_enabled !== false;

  // Active parcels in progress (registered + in_transit)
  const activeCount = parcels.filter(p => p.status === 'registered' || p.status === 'in_transit').length;

  return (
    <>
      {/* Quick Add Popover Menu */}
      {showAddMenu && (
        <div 
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end justify-center p-4 pb-20 animate-fadeIn"
          onClick={() => setShowAddMenu(false)}
        >
          <div 
            className="w-full max-w-[360px] bg-[#1a0f00]/95 border border-[#D4AF37]/60 rounded-3xl p-5 shadow-2xl space-y-3 text-right"
            onClick={(e) => e.stopPropagation()}
            dir="rtl"
          >
            <div className="flex items-center justify-between border-b border-[#D4AF37]/25 pb-2">
              <span className="text-xs font-black text-[#E6C37A]">تسجيل عملية جديدة سريعة</span>
              <button 
                onClick={() => setShowAddMenu(false)}
                className="p-1 rounded-lg text-[#C8B08A] hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Option 1: New Parcel Intake (Only if Parcels Module is Enabled) */}
            {isParcelsEnabled && (
              <button
                onClick={() => {
                  setShowAddMenu(false);
                  onOpenNewParcel();
                }}
                className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-gradient-to-r from-[#F3A952]/20 to-[#D4AF37]/10 hover:from-[#F3A952]/30 hover:to-[#D4AF37]/20 border border-[#D4AF37]/50 text-[#FFF8EB] transition active:scale-95 group text-right"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] flex items-center justify-center font-bold shadow-md shadow-[#D4AF37]/20 group-hover:scale-105 transition">
                    <Package className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-[#FFF8EB]">تسجيل كولي جديد (إرسالية)</h4>
                    <p className="text-[11px] text-[#E6C37A]/90">شحن طرد وتوليد تذكرة حرارية</p>
                  </div>
                </div>
              </button>
            )}

            {/* Option 2: Cash Voucher (In/Out) */}
            <button
              onClick={() => {
                setShowAddMenu(false);
                onOpenNewVoucher();
              }}
              className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-[#120a00]/90 hover:bg-[#241500] border border-[#D4AF37]/40 text-[#FFF8EB] transition active:scale-95 group text-right"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/20 border border-[#D4AF37]/50 text-[#E6C37A] flex items-center justify-center font-bold group-hover:scale-105 transition">
                  <Coins className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-[#FFF8EB]">سند مالي (قبض / صرف)</h4>
                  <p className="text-[11px] text-[#C8B08A]">تسجيل حركة نقدية بصندوق المحطة</p>
                </div>
              </div>
            </button>
          </div>
        </div>
      )}

      {/* Floating Bottom Nav (Constrained to 390px Mobile Frame) */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 w-full max-w-[390px] mx-auto bg-[#0b0600]/95 backdrop-blur-xl border-t border-[#D4AF37]/35 border-x border-x-[#D4AF37]/20 pb-safe shadow-2xl" dir="rtl">
        <div className="w-full px-3 h-15 flex items-center justify-around relative">
          
          {/* Tab 1: لوحة التحكم */}
          <button
            onClick={() => onSelectTab('dashboard')}
            className={`flex flex-col items-center justify-center w-14 h-full transition-all active:scale-95 ${
              currentTab === 'dashboard' ? 'text-[#F3A952] font-black' : 'text-[#A68966] hover:text-[#E6C37A]'
            }`}
          >
            <LayoutDashboard className="w-5 h-5 mb-1" />
            <span className="text-[10px] leading-tight font-bold">الرئيسية</span>
          </button>

          {/* Tab 2: الكوليات (Only shown if parcels_module_enabled is true) */}
          {isParcelsEnabled && (
            <button
              onClick={() => onSelectTab('parcels')}
              className={`relative flex flex-col items-center justify-center w-14 h-full transition-all active:scale-95 ${
                currentTab === 'parcels' ? 'text-[#F3A952] font-black' : 'text-[#A68966] hover:text-[#E6C37A]'
              }`}
            >
              <div className="relative">
                <Package className="w-5 h-5 mb-1" />
                {activeCount > 0 && (
                  <span className="absolute -top-1 -right-2 px-1 py-0.2 min-w-4 h-4 rounded-full bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] text-[9px] font-black flex items-center justify-center">
                    {activeCount}
                  </span>
                )}
              </div>
              <span className="text-[10px] leading-tight font-bold">الكوليات</span>
            </button>
          )}

          {/* Center Prominent Button: + عملية جديدة */}
          <div className="relative -top-4">
            <button
              onClick={() => setShowAddMenu(true)}
              className="w-13 h-13 rounded-full bg-gradient-to-tr from-[#D4882A] via-[#E5953E] to-[#F6C478] hover:brightness-110 text-[#1a0f00] flex flex-col items-center justify-center shadow-xl shadow-[#D4AF37]/30 border-4 border-[#060300] transition-transform active:scale-90"
              title="تسجيل عملية جديدة"
            >
              <Plus className="w-6 h-6 stroke-[3]" />
            </button>
            <span className="block text-center text-[10px] font-black text-[#E6C37A] mt-0.5">
              جديد
            </span>
          </div>

          {/* Tab 3: الصناديق والقيود (لاكيس) */}
          <button
            onClick={() => onSelectTab('cash')}
            className={`flex flex-col items-center justify-center w-14 h-full transition-all active:scale-95 ${
              currentTab === 'cash' ? 'text-[#F3A952] font-black' : 'text-[#A68966] hover:text-[#E6C37A]'
            }`}
          >
            <Coins className="w-5 h-5 mb-1" />
            <span className="text-[10px] leading-tight font-bold">الصناديق</span>
          </button>

          {/* Tab 4: الإعدادات */}
          <button
            onClick={() => onSelectTab('settings')}
            className={`flex flex-col items-center justify-center w-14 h-full transition-all active:scale-95 ${
              currentTab === 'settings' ? 'text-[#F3A952] font-black' : 'text-[#A68966] hover:text-[#E6C37A]'
            }`}
          >
            <Settings className="w-5 h-5 mb-1" />
            <span className="text-[10px] leading-tight font-bold">الإعدادات</span>
          </button>

        </div>
      </nav>
    </>
  );
};
