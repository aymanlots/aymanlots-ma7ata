import React, { useState, useEffect } from 'react';
import { 
  Parcel, 
  ParcelStatus, 
  ParcelPayer, 
  ParcelStatusHistoryEntry, 
  ParcelPaymentEntry 
} from '../types/database';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Printer, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  User, 
  Phone, 
  MapPin, 
  Package, 
  DollarSign, 
  MessageCircle, 
  Layers, 
  Send,
  CreditCard,
  PlusCircle,
  FileText,
  AlertCircle,
  Truck
} from 'lucide-react';

interface ParcelDetailModalProps {
  parcel: Parcel | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenTicket: (parcel: Parcel) => void;
}

export const ParcelDetailModal: React.FC<ParcelDetailModalProps> = ({
  parcel: parcelProp,
  isOpen,
  onClose,
  onOpenTicket
}) => {
  const { 
    currentUser, 
    userRole, 
    parcels,
    updateParcelStatus, 
    recordParcelPayment,
    showToast 
  } = useApp();

  const parcel = parcels.find(p => p.id === parcelProp?.id) || parcelProp;

  const [activeTab, setActiveTab] = useState<'info' | 'status' | 'payments'>('info');

  // Status update state
  const [selectedStatus, setSelectedStatus] = useState<ParcelStatus>('registered');
  const [statusNote, setStatusNote] = useState('');
  const [deliveredToInput, setDeliveredToInput] = useState('');
  const [statusCondition, setStatusCondition] = useState<'normal' | 'abnormal'>('normal');
  const [statusConditionNotes, setStatusConditionNotes] = useState('');
  const [showUnpaidWarning, setShowUnpaidWarning] = useState(false);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);

  // Initialize condition when parcel opens
  useEffect(() => {
    if (parcel) {
      setStatusCondition(parcel.condition || 'normal');
      setStatusConditionNotes(parcel.condition_notes || '');
    }
  }, [parcel]);

  // Payment record state
  const [paymentAmount, setPaymentAmount] = useState('');
  const [payerNameInput, setPayerNameInput] = useState('');
  const [paymentNote, setPaymentNote] = useState('');
  const [isRecordingPayment, setIsRecordingPayment] = useState(false);

  if (!isOpen || !parcel) return null;

  const remaining = Math.max(0, Math.round((parcel.amount_due - parcel.amount_paid) * 100) / 100);
  const isSettled = remaining <= 0;

  const statusNames: Record<ParcelStatus, string> = {
    registered: 'تم التسجيل في المحطة',
    in_transit: 'في الطريق (قيد النقل الدولي)',
    arrived: 'وصلت إلى محطة الوجهة',
    delivered: 'تم التسليم للمستلم',
    cancelled: 'ملغاة',
    pending: 'قيد التسجيل والانتظار'
  };

  const payerTitle = parcel.payer === 'sender' ? 'المرسل' : 'المستلم';

  // Handling Status Change with Warning if Unpaid
  const handleInitiateStatusChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedStatus === 'delivered' && remaining > 0 && !showUnpaidWarning) {
      setShowUnpaidWarning(true);
      return;
    }
    executeStatusUpdate();
  };

  const executeStatusUpdate = async () => {
    setIsUpdatingStatus(true);
    try {
      const res = await updateParcelStatus(
        parcel.id,
        selectedStatus,
        {
          delivered_to: deliveredToInput.trim() || parcel.receiver_name,
          notes: statusNote.trim() || undefined,
          condition: statusCondition,
          condition_notes: statusCondition === 'abnormal' ? statusConditionNotes.trim() : undefined
        }
      );

      if (res.success) {
        showToast(`تم تحديث حالة الكولي إلى "${statusNames[selectedStatus]}" بنجاح`, 'success');
        setStatusNote('');
        setShowUnpaidWarning(false);
      } else {
        showToast(res.error || 'تعذر تحديث الحالة', 'error');
      }
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  // Handling Partial Payment Record
  const handleAddPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(paymentAmount);
    if (!amt || amt <= 0) {
      showToast('يرجى إدخال مبلغ صحيح', 'error');
      return;
    }

    setIsRecordingPayment(true);
    try {
      const res = await recordParcelPayment(
        parcel.id,
        amt,
        payerNameInput.trim() || (parcel.payer === 'sender' ? parcel.sender_name : parcel.receiver_name),
        paymentNote.trim() || undefined
      );

      if (res.success) {
        showToast(`تم تسجيل دفعة بقيمة ${amt} ${parcel.currency} بنجاح`, 'success');
        setPaymentAmount('');
        setPaymentNote('');
      } else {
        showToast(res.error || 'تعذر تسجيل الدفعة', 'error');
      }
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setIsRecordingPayment(false);
    }
  };

  // WhatsApp Link Helper
  const getWhatsAppLink = (rawPhone: string) => {
    const clean = rawPhone.replace(/[^0-9]/g, '');
    return `https://wa.me/${clean}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 animate-fadeIn overflow-y-auto">
      <div className="fixed inset-0 bg-black/90 backdrop-blur-sm" onClick={onClose} />

      <div 
        className="w-full max-w-[380px] rounded-[24px] bg-[#140b00] border border-[#D4AF37]/65 p-4 shadow-2xl text-right overflow-hidden relative z-10 my-4 space-y-3.5"
        onClick={e => e.stopPropagation()}
        dir="rtl"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#D4AF37]/25 pb-2.5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] flex items-center justify-center">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-black text-[#F5D799]">
                  كولي #{parcel.parcel_number}
                </h2>
                <span className="font-mono text-[11px] text-[#E6C37A] bg-[#1a0f00] px-2 py-0.5 rounded-lg border border-[#D4AF37]/40">
                  {parcel.tracking_code}
                </span>
              </div>
              <p className="text-[11px] text-[#C8B08A]">
                {parcel.origin_station_name} ➔ {parcel.destination_station_name}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-[#1a0f00] border border-[#D4AF37]/40 text-[#E6C37A] hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex bg-[#0d0700] border border-[#D4AF37]/30 rounded-2xl p-1 gap-1">
          <button
            onClick={() => setActiveTab('info')}
            className={`flex-1 py-2 text-[11px] font-bold rounded-xl transition ${
              activeTab === 'info'
                ? 'bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black shadow-sm'
                : 'text-[#C8B08A] hover:text-white'
            }`}
          >
            تفاصيل الكولي
          </button>
          <button
            onClick={() => setActiveTab('status')}
            className={`flex-1 py-2 text-[11px] font-bold rounded-xl transition flex items-center justify-center gap-1 ${
              activeTab === 'status'
                ? 'bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black shadow-sm'
                : 'text-[#C8B08A] hover:text-white'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>حالة التتبع ({parcel.status_history?.length || 1})</span>
          </button>
          <button
            onClick={() => setActiveTab('payments')}
            className={`flex-1 py-2 text-[11px] font-bold rounded-xl transition flex items-center justify-center gap-1 ${
              activeTab === 'payments'
                ? 'bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black shadow-sm'
                : 'text-[#C8B08A] hover:text-white'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span>المدفوعات ({isSettled ? 'خالص' : `${remaining}`})</span>
          </button>
        </div>

        {/* TAB 1: INFO */}
        {activeTab === 'info' && (
          <div className="space-y-3 text-xs">
            {/* Sender & Receiver Card */}
            <div className="grid grid-cols-1 gap-2.5">
              {/* Sender */}
              <div className="bg-[#1a0f00]/80 p-3 rounded-2xl border border-[#D4AF37]/40 space-y-1">
                <span className="font-bold text-[11px] text-[#E6C37A] block">بيانات المرسل:</span>
                <span className="font-black text-[#FFF8EB] text-sm block">{parcel.sender_name}</span>
                <div className="flex items-center justify-between text-[#C8B08A] font-mono text-[11px] pt-1">
                  <span dir="ltr">{parcel.sender_phone}</span>
                  <a
                    href={getWhatsAppLink(parcel.sender_phone)}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 text-[#F5D799] font-bold bg-[#120a00] px-2.5 py-0.5 rounded-lg border border-[#D4AF37]/40"
                  >
                    <MessageCircle className="w-3.5 h-3.5 text-[#F3A952]" />
                    <span>واتساب</span>
                  </a>
                </div>
              </div>

              {/* Receiver */}
              <div className="bg-[#1a0f00]/80 p-3 rounded-2xl border border-[#D4AF37]/40 space-y-1">
                <span className="font-bold text-[11px] text-[#E6C37A] block">بيانات المستلم:</span>
                <span className="font-black text-[#FFF8EB] text-sm block">{parcel.receiver_name}</span>
                <div className="flex items-center justify-between text-[#C8B08A] font-mono text-[11px] pt-1">
                  <span dir="ltr">{parcel.receiver_phone}</span>
                  <a
                    href={getWhatsAppLink(parcel.receiver_phone)}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 text-[#F5D799] font-bold bg-[#120a00] px-2.5 py-0.5 rounded-lg border border-[#D4AF37]/40"
                  >
                    <MessageCircle className="w-3.5 h-3.5 text-[#F3A952]" />
                    <span>واتساب</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Goods Details */}
            <div className="bg-[#1a0f00]/80 p-3 rounded-2xl border border-[#D4AF37]/40 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-[#C8B08A] block">بيان ووصف البضاعة:</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-[#120a00] text-[#F5D799] border border-[#D4AF37]/40">
                  {(parcel.condition || 'normal') === 'normal' ? '✓ عادي (سليم)' : '⚠ غير عادي'}
                </span>
              </div>

              <p className="text-[#FFF8EB] text-xs leading-relaxed bg-[#120a00] p-2.5 rounded-xl border border-[#D4AF37]/30">
                {parcel.description}
              </p>

              <div className="grid grid-cols-2 gap-2 pt-1 text-[11px]">
                <div className="bg-[#120a00] p-2 rounded-xl border border-[#D4AF37]/25 text-center">
                  <span className="text-[#C8B08A] block">العدد / الكمية</span>
                  <span className="font-bold text-[#FFF8EB]">{parcel.items_count} طرد</span>
                </div>
                <div className="bg-[#120a00] p-2 rounded-xl border border-[#D4AF37]/25 text-center">
                  <span className="text-[#C8B08A] block">الوزن</span>
                  <span className="font-bold text-[#FFF8EB]">{parcel.weight_kg ? `${parcel.weight_kg} كغ` : 'غير محدد'}</span>
                </div>
                <div className="bg-[#120a00] p-2 rounded-xl border border-[#D4AF37]/25 text-center">
                  <span className="text-[#C8B08A] block">محطة الانطلاق</span>
                  <span className="font-bold text-[#FFF8EB]">{parcel.origin_station_name}</span>
                </div>
                <div className="bg-[#120a00] p-2 rounded-xl border border-[#D4AF37]/25 text-center">
                  <span className="text-[#C8B08A] block">محطة الوصول</span>
                  <span className="font-bold text-[#FFF8EB]">{parcel.destination_station_name}</span>
                </div>
              </div>
            </div>

            {/* Financial Summary */}
            <div className="bg-gradient-to-r from-[#6E4720]/40 to-[#1a0f00]/80 p-3 rounded-2xl border border-[#D4AF37]/50 flex items-center justify-between">
              <div>
                <span className="text-[#C8B08A] block text-[10px]">المبلغ الإجمالي ({payerTitle}):</span>
                <span className="text-base font-black text-[#FFF8EB]">{parcel.amount_due} {parcel.currency}</span>
              </div>
              <div className="text-left">
                <span className="text-[#C8B08A] block text-[10px]">المتبقي للتحصيل:</span>
                <span className={`text-base font-black font-mono ${remaining > 0 ? 'text-rose-400' : 'text-[#F5D799]'}`}>
                  {remaining} {parcel.currency}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: STATUS & TRACKING TIMELINE */}
        {activeTab === 'status' && (
          <div className="space-y-3.5 text-xs">
            <form onSubmit={handleInitiateStatusChange} className="bg-[#1a0f00]/80 p-3.5 rounded-2xl border border-[#D4AF37]/45 space-y-2.5">
              <span className="font-bold text-[#F5D799] block">تحديث حالة التتبع الآن:</span>
              
              <div className="grid grid-cols-2 gap-2">
                {(['registered', 'in_transit', 'arrived', 'delivered'] as ParcelStatus[]).map(st => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => {
                      setSelectedStatus(st);
                      setShowUnpaidWarning(false);
                    }}
                    className={`p-2 rounded-xl border text-center font-bold text-[11px] transition ${
                      selectedStatus === st
                        ? 'bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] border-[#F8C885] font-black shadow-sm'
                        : 'bg-[#120a00] border-[#D4AF37]/35 text-[#E6C37A]'
                    }`}
                  >
                    {statusNames[st]}
                  </button>
                ))}
              </div>

              {selectedStatus === 'delivered' && (
                <div>
                  <label className="block text-[#C8B08A] mb-1 text-[11px]">اسم الشخص المستلم فعلياً:</label>
                  <input
                    type="text"
                    placeholder={parcel.receiver_name}
                    value={deliveredToInput}
                    onChange={e => setDeliveredToInput(e.target.value)}
                    className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
              )}

              <div>
                <label className="block text-[#C8B08A] mb-1 text-[11px]">ملاحظة أو بيان مرحلة النقل (اختياري):</label>
                <input
                  type="text"
                  placeholder="مثال: تم العبور من معبر الكركرات الدولي بنجاح"
                  value={statusNote}
                  onChange={e => setStatusNote(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              {showUnpaidWarning && (
                <div className="bg-rose-950/60 border border-rose-500/40 p-3 rounded-xl space-y-2 animate-fadeIn">
                  <div className="flex items-center gap-2 text-rose-300 font-bold">
                    <AlertTriangle className="w-5 h-5 shrink-0" />
                    <span>تنبيه هام: يوجد رصيد غير مدفوع على هذا الكولي!</span>
                  </div>
                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={executeStatusUpdate}
                      disabled={isUpdatingStatus}
                      className="px-3 py-1.5 rounded-xl bg-rose-500 text-white font-bold text-xs"
                    >
                      تأكيد التسليم
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowUnpaidWarning(false)}
                      className="px-3 py-1.5 rounded-xl bg-[#120a00] text-[#E6C37A] text-xs font-bold"
                    >
                      إلغاء
                    </button>
                  </div>
                </div>
              )}

              {!showUnpaidWarning && (
                <button
                  type="submit"
                  disabled={isUpdatingStatus}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black text-xs transition"
                >
                  {isUpdatingStatus ? 'جاري التحديث...' : 'حفظ ونشر الحالة الجديدة'}
                </button>
              )}
            </form>

            {/* Golden Timeline List */}
            <div className="bg-[#1a0f00]/80 p-3.5 rounded-2xl border border-[#D4AF37]/45 space-y-3">
              <span className="font-bold text-[#F5D799] block text-[11px]">سجل التتبع والمراحل:</span>
              
              <div className="space-y-3 relative before:absolute before:right-2.5 before:top-2 before:bottom-2 before:w-[1.5px] before:bg-[#D4AF37]/60">
                {(parcel.status_history || []).map((entry, idx) => (
                  <div key={idx} className="relative pr-7 space-y-1">
                    <div className="absolute right-0.5 top-0.5 w-4 h-4 rounded-full bg-[#F39C3D] text-[#1a0f00] flex items-center justify-center text-[9px] font-black">
                      ✓
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#FFF8EB]">{statusNames[entry.status] || entry.status}</span>
                      <span className="text-[10px] text-[#C8B08A] font-mono" dir="ltr">
                        {new Date(entry.timestamp).toLocaleString('ar-MA')}
                      </span>
                    </div>
                    {entry.notes && (
                      <p className="text-[11px] text-[#F5D799] bg-[#120a00] p-2 rounded-lg mt-1 border border-[#D4AF37]/30">
                        {entry.notes}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: PAYMENTS & BALANCE */}
        {activeTab === 'payments' && (
          <div className="space-y-3.5 text-xs">
            <div className="bg-[#1a0f00]/80 p-3 rounded-2xl border border-[#D4AF37]/45 grid grid-cols-3 gap-2 text-center">
              <div className="bg-[#120a00] p-2 rounded-xl border border-[#D4AF37]/25">
                <span className="text-[#C8B08A] block text-[10px]">الإجمالي</span>
                <span className="font-black text-[#FFF8EB] text-xs">{parcel.amount_due} {parcel.currency}</span>
              </div>
              <div className="bg-[#120a00] p-2 rounded-xl border border-[#D4AF37]/25">
                <span className="text-[#C8B08A] block text-[10px]">المدفوع</span>
                <span className="font-black text-[#F5D799] text-xs">{parcel.amount_paid} {parcel.currency}</span>
              </div>
              <div className="bg-[#120a00] p-2 rounded-xl border border-[#D4AF37]/25">
                <span className="text-[#C8B08A] block text-[10px]">المتبقي</span>
                <span className={`font-black text-xs ${remaining > 0 ? 'text-rose-400' : 'text-[#F5D799]'}`}>
                  {remaining} {parcel.currency}
                </span>
              </div>
            </div>

            {remaining > 0 && (
              <form onSubmit={handleAddPayment} className="bg-[#1a0f00]/80 p-3.5 rounded-2xl border border-[#D4AF37]/50 space-y-2.5">
                <span className="font-bold text-[#F5D799] flex items-center gap-1.5 text-xs">
                  <PlusCircle className="w-4 h-4 text-[#F3A952]" />
                  <span>تسجيل دفعة نقدية جديدة ({payerTitle}):</span>
                </span>

                <input
                  type="number"
                  step="0.01"
                  min="1"
                  max={remaining}
                  placeholder={`المبلغ المستلم (أقصى حد: ${remaining})`}
                  required
                  value={paymentAmount}
                  onChange={e => setPaymentAmount(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-[#D4AF37]"
                />

                <button
                  type="submit"
                  disabled={isRecordingPayment}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black text-xs transition"
                >
                  {isRecordingPayment ? 'جاري التسجيل...' : 'تأكيد استلام الدفعة وتحديث الرصيد'}
                </button>
              </form>
            )}
          </div>
        )}

        {/* Footer */}
        <div className="pt-2 border-t border-[#D4AF37]/25 flex justify-between items-center gap-2">
          <button
            type="button"
            onClick={() => onOpenTicket(parcel)}
            className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black text-xs transition active:scale-95 shadow-sm"
          >
            <Printer className="w-4 h-4 stroke-[2.5]" />
            <span>طباعة</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-[#1a0f00] border border-[#D4AF37]/50 text-[#E6C37A] font-bold text-xs"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
