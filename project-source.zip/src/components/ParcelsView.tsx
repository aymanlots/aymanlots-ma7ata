import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Parcel, ParcelStatus, ParcelCondition, Trip } from '../types/database';
import { ParcelStickerModal } from './ParcelStickerModal';
import { ParcelDetailModal } from './ParcelDetailModal';
import { NewTripModal } from './NewTripModal';
import { TripDispatchModal } from './TripDispatchModal';
import { TripArrivalModal } from './TripArrivalModal';
import { QuickDeliverModal } from './QuickDeliverModal';
import { BarcodeScannerModal } from './BarcodeScannerModal';
import { exportService } from '../services/exportService';
import { playSuccessBeep, playErrorBeep } from '../utils/audioFeedback';
import { 
  Package, 
  Search, 
  Filter, 
  PlusCircle, 
  MapPin, 
  Phone, 
  Printer, 
  Clock, 
  Eye, 
  AlertTriangle,
  DollarSign,
  MessageCircle,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  Truck,
  Scan,
  UserCheck,
  ArrowRightLeft,
  Send,
  Calendar,
  Layers,
  Sparkles,
  Inbox,
  CheckSquare,
  Square,
  Users
} from 'lucide-react';

interface ParcelsViewProps {
  onOpenNewParcel: () => void;
}

export const ParcelsView: React.FC<ParcelsViewProps> = ({ 
  onOpenNewParcel 
}) => {
  const { 
    parcels, 
    trips,
    stations, 
    selectedStationId,
    currentWorkspace, 
    userRole,
    userAssignedStationId,
    showToast 
  } = useApp();

  // Navigation Tabs within Parcels Module
  const [activeTab, setActiveTab] = useState<'parcels' | 'trips' | 'incoming' | 'overview'>('parcels');

  // Search & Filter state for Parcels Tab
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [paymentFilter, setPaymentFilter] = useState<'all' | 'settled' | 'unpaid'>('all');
  const [stationFilter, setStationFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<string>('all');
  const [conditionFilter, setConditionFilter] = useState<string>('all');

  // Modals state
  const [ticketParcel, setTicketParcel] = useState<Parcel | null>(null);
  const [batchStickerParcels, setBatchStickerParcels] = useState<Parcel[] | undefined>(undefined);
  const [isBatchStickerModalOpen, setIsBatchStickerModalOpen] = useState(false);
  const [selectedParcelIds, setSelectedParcelIds] = useState<Set<string>>(new Set());
  const [detailParcel, setDetailParcel] = useState<Parcel | null>(null);
  const [isNewTripOpen, setIsNewTripOpen] = useState(false);
  const [dispatchTrip, setDispatchTrip] = useState<Trip | null>(null);
  const [arrivalTrip, setArrivalTrip] = useState<Trip | null>(null);
  const [quickDeliverParcel, setQuickDeliverParcel] = useState<Parcel | null>(null);
  const [isQuickDeliverOpen, setIsQuickDeliverOpen] = useState(false);
  const [isBarcodeScannerOpen, setIsBarcodeScannerOpen] = useState(false);

  // Active Station context (for workers or selected station)
  const activeStationId = (userRole === 'worker' && userAssignedStationId)
    ? userAssignedStationId
    : (selectedStationId || stations[0]?.id || '');
  const activeStation = stations.find(s => s.id === activeStationId) || stations[0];

  // 1. Filtered Parcels List
  const filteredParcels = useMemo(() => {
    return parcels.filter(p => {
      // Status Filter
      if (statusFilter !== 'all' && p.status !== statusFilter) return false;

      // Condition Filter (عادي / غير عادي)
      if (conditionFilter !== 'all') {
        const cond = p.condition || 'normal';
        if (cond !== conditionFilter) return false;
      }

      // Station Filter
      if (stationFilter !== 'all') {
        if (p.origin_station_id !== stationFilter && p.destination_station_id !== stationFilter) {
          return false;
        }
      }

      // Payment Filter
      const remaining = Math.max(0, Math.round((p.amount_due - p.amount_paid) * 100) / 100);
      if (paymentFilter === 'settled' && remaining > 0) return false;
      if (paymentFilter === 'unpaid' && remaining <= 0) return false;

      // Date Filter
      if (dateFilter !== 'all') {
        const parcelDate = p.created_at.split('T')[0];
        const today = new Date().toISOString().split('T')[0];
        if (dateFilter === 'today' && parcelDate !== today) return false;
      }

      // Search Query (Number, Code, Sender, Receiver, Phone, Description, Driver, Plate)
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchNum = p.parcel_number?.toString().includes(q);
        const matchCode = p.tracking_code.toLowerCase().includes(q);
        const matchSender = p.sender_name.toLowerCase().includes(q) || p.sender_phone.includes(q);
        const matchReceiver = p.receiver_name.toLowerCase().includes(q) || p.receiver_phone.includes(q);
        const matchDesc = p.description.toLowerCase().includes(q);
        const matchDriver = p.driver_name?.toLowerCase().includes(q);
        const matchPlate = p.vehicle_plate?.toLowerCase().includes(q);
        if (!matchNum && !matchCode && !matchSender && !matchReceiver && !matchDesc && !matchDriver && !matchPlate) {
          return false;
        }
      }

      return true;
    });
  }, [parcels, statusFilter, conditionFilter, paymentFilter, stationFilter, dateFilter, searchQuery]);

  // Statistics
  const stats = useMemo(() => {
    let registered = 0;
    let inTransit = 0;
    let arrived = 0;
    let delivered = 0;
    let abnormalCount = 0;
    let totalUnpaidMad = 0;
    let totalUnpaidMru = 0;

    parcels.forEach(p => {
      if (p.status === 'registered') registered++;
      else if (p.status === 'in_transit') inTransit++;
      else if (p.status === 'arrived') arrived++;
      else if (p.status === 'delivered') delivered++;

      if (p.condition === 'abnormal') abnormalCount++;

      const rem = Math.max(0, Math.round((p.amount_due - p.amount_paid) * 100) / 100);
      if (rem > 0) {
        if (p.currency === 'MRU') totalUnpaidMru += rem;
        else totalUnpaidMad += rem;
      }
    });

    return {
      total: parcels.length,
      registered,
      inTransit,
      arrived,
      delivered,
      abnormalCount,
      totalUnpaidMad: Math.round(totalUnpaidMad * 100) / 100,
      totalUnpaidMru: Math.round(totalUnpaidMru * 100) / 100
    };
  }, [parcels]);

  // Incoming trips heading to my station
  const incomingTrips = useMemo(() => {
    return trips.filter(t => {
      const isHeadingToMyStation = t.destination_station_id === activeStationId;
      const isEnRouteOrArrived = t.status === 'departed' || t.status === 'arrived';
      return isHeadingToMyStation && isEnRouteOrArrived;
    });
  }, [trips, activeStationId]);

  // Export CSV
  const handleExportCSV = () => {
    if (parcels.length === 0) {
      showToast('لا توجد كوليات لتصديرها حالياً', 'info');
      return;
    }
    exportService.exportParcelsToCSV(parcels, currentWorkspace?.name || 'محطة الاتحادية');
    showToast('تم تصدير سجل الكوليات إلى ملف CSV بنجاح', 'success');
  };

  const getWhatsAppLink = (rawPhone: string) => {
    const clean = rawPhone.replace(/[^0-9]/g, '');
    return `https://wa.me/${clean}`;
  };

  const handleGlobalScanResult = (code: string) => {
    const clean = code.trim().toUpperCase();
    const found = parcels.find(p => 
      p.tracking_code.toUpperCase() === clean || 
      String(p.parcel_number) === clean ||
      p.id === clean
    );

    if (found) {
      playSuccessBeep();
      setDetailParcel(found);
      showToast(`تم العثور على الكولي #${found.parcel_number} (${found.tracking_code})`, 'success');
    } else {
      playErrorBeep();
      showToast(`لم يتم العثور على أي كولي بالرقم [${code}]`, 'error');
    }
  };

  const statusNames: Record<string, string> = {
    registered: 'تم التسجيل بالمحطة',
    in_transit: 'في الطريق (قيد النقل)',
    arrived: 'دخلت المحطة (وصلت)',
    delivered: 'تم التسليم للمستلم',
    cancelled: 'ملغاة'
  };

  const tripStatusNames: Record<string, { label: string; color: string }> = {
    loading: { label: 'قيد التحميل والشحن', color: 'bg-[#120a00] text-[#F5D799] border-[#D4AF37]/40' },
    departed: { label: 'انطلقت في الطريق 🚚', color: 'bg-[#2a1800] text-[#F3A952] border-[#D4AF37]/60' },
    arrived: { label: 'وصلت محطة الوجهة 🏁', color: 'bg-[#120a00] text-[#E6C37A] border-[#D4AF37]/40' },
    closed: { label: 'مغلقة ومكتملة ✓', color: 'bg-[#120a00] text-[#C8B08A] border-[#D4AF37]/25' }
  };

  return (
    <div className="space-y-3.5 pb-24 text-right">
      
      {/* ===================================================================== */}
      {/* HERO LIVE TRACKING SHOWCASE (100% Match to Mobile Reference Image)    */}
      {/* ===================================================================== */}
      <div className="space-y-2.5">
        {/* 1. Desert Road Map: Dakhla -> Nouadhibou with White Van */}
        <div className="relative rounded-t-[24px] overflow-hidden border-t border-x border-[#D4AF37]/40 shadow-2xl">
          <svg
            viewBox="52 268 653 465"
            className="w-full h-auto block"
            preserveAspectRatio="xMidYMid slice"
          >
            <image
              href="/assets/aistudio/IIII_3d3dff03.jpeg"
              width="757"
              height="1600"
            />
          </svg>
        </div>

        {/* 2. Translucent Brown Shipment Status & Golden Timeline Card */}
        <div className="-mt-8 relative z-10 rounded-[22px] bg-[#1a0f00]/80 backdrop-blur-md border border-[#D4AF37]/65 p-4 shadow-[0_12px_35px_rgba(0,0,0,0.85)]">
          <div className="text-right">
            <h2 className="text-[18px] font-black text-[#F5D799] leading-tight">
              حالة الشحنة • <span dir="ltr" className="font-sans">In Transit</span>
            </h2>
            <p className="text-[12px] text-[#D8C3A5] font-medium mt-0.5">
              رقم <span dir="ltr" className="font-mono font-bold text-[#FFF8EB]">{filteredParcels[0]?.tracking_code || 'TRT-847291-MR'}</span>
            </p>
          </div>

          {/* Horizontal Golden Progress Bar */}
          <div className="relative flex items-center justify-between my-3 px-1">
            <div className="absolute left-2 right-2 top-1/2 -translate-y-1/2 h-[1.5px] bg-[#D4AF37]/45" />
            <div className="relative z-10 w-3 h-3 rounded-full bg-[#F39C3D] ring-2 ring-[#1a0f00]" />
            <div className="relative z-10 w-2.5 h-2.5 rounded-full bg-[#E6B86A]" />
            <div className="relative z-10 w-2.5 h-2.5 rounded-full bg-[#E6B86A]" />
            <div className="relative z-10 w-2.5 h-2.5 rounded-full bg-[#E6B86A]" />
            <div className="relative z-10 w-2.5 h-2.5 rounded-full bg-[#E6B86A]" />
          </div>

          {/* Vertical Golden Timeline */}
          <div className="relative space-y-3 pr-7 mt-2 before:absolute before:right-[9px] before:top-2 before:bottom-6 before:w-[1.5px] before:bg-[#D4AF37]/60">
            <div className="relative">
              <div className="absolute -right-7 top-0.5 w-5 h-5 rounded-full bg-[#F39C3D] text-[#1a0f00] flex items-center justify-center text-[11px] font-black shadow-md">
                ✓
              </div>
              <div className="text-[13px] font-bold text-[#FFF8EB] leading-snug">
                فالمحطة
              </div>
              <div className="text-[11px] text-[#C8B08A]">اليوم، 09:15</div>
            </div>

            <div className="relative">
              <div className="absolute -right-7 top-0.5 w-5 h-5 rounded-full bg-[#F39C3D] text-[#1a0f00] flex items-center justify-center text-[11px] font-black shadow-md">
                ✓
              </div>
              <div className="text-[13px] font-bold text-[#FFF8EB] leading-snug">
                فالطريق
              </div>
              <div className="text-[11px] text-[#C8B08A]">اليوم، 11:40</div>
            </div>

            <div className="relative">
              <div className="absolute -right-7 top-0.5 w-5 h-5 rounded-full bg-[#F39C3D] text-[#1a0f00] flex items-center justify-center text-[11px] font-black shadow-md">
                ✓
              </div>
              <div className="text-[13px] font-bold text-[#FFF8EB] leading-snug">
                وصلات
              </div>
              <div className="text-[11px] text-[#C8B08A]">اليوم، 13:20</div>
            </div>

            <div className="relative">
              <div className="absolute -right-7 top-0.5 w-5 h-5 rounded-full bg-[#1a0f00] border-2 border-[#F39C3D] flex items-center justify-center shadow-[0_0_10px_rgba(243,156,61,0.6)]">
                <span className="w-2 h-2 rounded-full bg-[#F5D799]" />
              </div>
              <div className="text-[13px] font-bold text-[#FFF8EB] leading-snug">
                تسلمات
              </div>
              <div className="text-[11px] text-[#E6C37A]">متوقع • 15:45 • جاري الآن</div>
            </div>
          </div>
        </div>

        {/* 3. QR Code & Expected Arrival Split Card */}
        <div className="rounded-[22px] bg-[#1a0f00]/80 backdrop-blur-md border border-[#D4AF37]/65 p-3.5 shadow-2xl grid grid-cols-2 gap-3 items-center">
          <div className="text-right pr-1 border-l border-[#D4AF37]/30 pl-2 space-y-1.5">
            <div className="flex items-center justify-start gap-1.5 text-[#F5D799] font-bold text-[14px]">
              <span>الوصول المتوقع</span>
              <Clock className="w-4 h-4 text-[#E6C37A]" />
            </div>
            <div className="text-[12px] font-bold text-[#FFF8EB]">
              اليوم، 17:30 • 3 س 10 د
            </div>
            <div className="text-[11px] text-[#D9B36C] font-mono" dir="ltr">
              → 142 km to Nouadhibou
            </div>
          </div>

          <div
            onClick={() => setIsBarcodeScannerOpen(true)}
            className="flex flex-col items-center justify-center cursor-pointer"
          >
            <span className="text-[12px] font-bold text-[#F5D799] mb-1.5">رمز الاستلام QR</span>
            <div className="flex items-center gap-2">
              <div className="w-[74px] h-[74px] rounded-lg bg-[#E5953E] p-1.5 shadow-md flex items-center justify-center">
                <svg viewBox="0 0 21 21" className="w-full h-full fill-[#1a0f00]">
                  <path d="M0,0 h7 v7 h-7 z M1,1 v5 h5 v-5 z M2,2 h3 v3 h-3 z M14,0 h7 v7 h-7 z M15,1 v5 h5 v-5 z M16,2 h3 v3 h-3 z M0,14 h7 v7 h-7 z M1,15 v5 h5 v-5 z M2,16 h3 v3 h-3 z M8,0 h2 v2 h-2 z M11,1 h2 v2 h-2 z M8,4 h3 v2 h-3 z M12,4 h1 v3 h-1 z M0,8 h3 v2 h-3 z M4,8 h2 v3 h-2 z M8,8 h5 v2 h-5 z M15,8 h2 v2 h-2 z M18,9 h3 v2 h-3 z M1,11 h2 v2 h-2 z M6,11 h3 v2 h-3 z M11,11 h2 v3 h-2 z M14,12 h3 v2 h-3 z M8,15 h2 v3 h-2 z M12,16 h2 v2 h-2 z M15,15 h3 v3 h-3 z M19,15 h2 v2 h-2 z M9,19 h4 v2 h-4 z M15,19 h6 v2 h-6 z" />
                </svg>
              </div>
              <span className="text-[18px] font-bold text-[#D99B4E] font-mono">82</span>
            </div>
            <span className="text-[10px] font-bold text-[#E6C37A] mt-1.5">امسح عند الاستلام</span>
          </div>
        </div>

        {/* 4. Bottom Dual Action Buttons */}
        <div className="grid grid-cols-2 gap-2.5 pt-0.5">
          <button
            onClick={() => setDetailParcel(filteredParcels[0] || parcels[0] || null)}
            className="py-3 px-3 rounded-2xl bg-gradient-to-r from-[#F5B05B] via-[#E5953E] to-[#D4882A] hover:brightness-110 text-[#1a0f00] font-black text-[13px] flex items-center justify-center gap-1.5 shadow-lg shadow-[#E5953E]/25 border border-[#F8C885] active:scale-95 transition"
          >
            <span>تفاصيل الشحنة</span>
            <Eye className="w-4 h-4 stroke-[2.5]" />
          </button>

          <button
            onClick={() => setTicketParcel(filteredParcels[0] || parcels[0] || null)}
            className="py-3 px-3 rounded-2xl bg-[#1a0f00]/90 hover:bg-[#2a1800] text-[#E6C37A] font-bold text-[13px] flex items-center justify-center gap-1.5 border border-[#D4AF37]/65 active:scale-95 transition"
          >
            <span>مشاركة التتبع</span>
            <Printer className="w-4 h-4 text-[#D4AF37]" />
          </button>
        </div>
      </div>

      {/* Top Banner & Main Quick Actions */}
      <div className="bg-[#1a0f00]/80 p-3.5 rounded-[22px] border border-[#D4AF37]/50 shadow-xl space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div>
            <h1 className="text-sm font-black text-[#F5D799] flex items-center gap-1.5">
              <Package className="w-4 h-4 text-[#D4AF37]" />
              <span>إدارة الكوليات والديسباتش</span>
            </h1>
            <p className="text-[10px] text-[#C8B08A] mt-0.5">
              تتبع البضائع، مسح الباركود، والشحن بين المحطات
            </p>
          </div>
          <span className="text-[10px] px-2.5 py-1 rounded-full bg-[#120a00] text-[#E6C37A] border border-[#D4AF37]/40 font-bold shrink-0">
            {stats.total} كولي
          </span>
        </div>

        {/* Quick Action Buttons Grid */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setIsBarcodeScannerOpen(true)}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black text-xs transition shadow-md active:scale-95"
            title="مسح سريع بالكاميرا أو القارئ"
          >
            <Scan className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>مسح باركود / QR</span>
          </button>

          <button
            onClick={() => {
              setQuickDeliverParcel(null);
              setIsQuickDeliverOpen(true);
            }}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-[#120a00] border border-[#D4AF37]/55 text-[#F5D799] font-bold text-xs transition active:scale-95"
            title="تسليم كولي للزبون واستخلاص المستحقات"
          >
            <UserCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>تسليم سريع</span>
          </button>

          <button
            onClick={() => setIsNewTripOpen(true)}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-[#120a00] border border-[#D4AF37]/45 text-[#E6C37A] font-bold text-xs transition active:scale-95"
            title="إنشاء رحلة شحن جديدة"
          >
            <Truck className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>رحلة جديدة</span>
          </button>

          <button
            onClick={onOpenNewParcel}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-[#120a00] border border-[#D4AF37]/45 text-[#E6C37A] font-bold text-xs transition active:scale-95"
          >
            <PlusCircle className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>كولي جديد</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              const chosen = parcels.filter(p => selectedParcelIds.has(p.id));
              setBatchStickerParcels(chosen.length > 0 ? chosen : filteredParcels.slice(0, 1));
              setIsBatchStickerModalOpen(true);
            }}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-[#2a1800] hover:bg-[#3a2200] text-[#F5D799] font-black text-xs transition border border-[#D4AF37]/60 active:scale-95"
            title="فتح نافذة طباعة الملصقات (مفردة أو جماعية)"
          >
            <Printer className="w-3.5 h-3.5 text-[#F3A952]" />
            <span>
              طباعة الملصقات{selectedParcelIds.size > 0 ? ` (${selectedParcelIds.size})` : ''}
            </span>
          </button>

          <button
            onClick={handleExportCSV}
            className="p-2 rounded-xl bg-[#120a00] hover:bg-[#2a1800] text-[#E6C37A] transition border border-[#D4AF37]/40"
            title="تصدير السجل إلى Excel / CSV"
          >
            <FileSpreadsheet className="w-4 h-4 text-[#D4AF37]" />
          </button>
        </div>

        {/* 4 Core Module Navigation Tabs */}
        <div className="grid grid-cols-2 gap-1.5 border-t border-[#D4AF37]/25 pt-2.5 text-[11px] font-bold">
          <button
            onClick={() => setActiveTab('parcels')}
            className={`flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl transition ${
              activeTab === 'parcels'
                ? 'bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black shadow-md'
                : 'bg-[#120a00] text-[#C8B08A] border border-[#D4AF37]/25 hover:text-white'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>الكوليات ({parcels.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('trips')}
            className={`flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl transition ${
              activeTab === 'trips'
                ? 'bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black shadow-md'
                : 'bg-[#120a00] text-[#C8B08A] border border-[#D4AF37]/25 hover:text-white'
            }`}
          >
            <Truck className="w-3.5 h-3.5" />
            <span>الرحلات ({trips.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('incoming')}
            className={`flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl transition relative ${
              activeTab === 'incoming'
                ? 'bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black shadow-md'
                : 'bg-[#120a00] text-[#C8B08A] border border-[#D4AF37]/25 hover:text-white'
            }`}
          >
            <Inbox className="w-3.5 h-3.5" />
            <span>الوارد لمحطتي ({incomingTrips.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('overview')}
            className={`flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl transition ${
              activeTab === 'overview'
                ? 'bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black shadow-md'
                : 'bg-[#120a00] text-[#C8B08A] border border-[#D4AF37]/25 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>نظرة المحطات</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: PARCELS LIST (الكوليات والإرساليات) */}
      {/* ========================================================================= */}
      {activeTab === 'parcels' && (
        <div className="space-y-3">
          {/* Stats Metric Bar */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="bg-[#1a0f00]/80 p-2.5 rounded-2xl border border-[#D4AF37]/40 text-center">
              <span className="text-[10px] text-[#C8B08A] block mb-0.5">تم التسجيل</span>
              <span className="text-base font-black text-[#F5D799]">{stats.registered}</span>
            </div>
            <div className="bg-[#1a0f00]/80 p-2.5 rounded-2xl border border-[#D4AF37]/40 text-center">
              <span className="text-[10px] text-[#C8B08A] block mb-0.5">في الطريق</span>
              <span className="text-base font-black text-[#F3A952]">{stats.inTransit}</span>
            </div>
            <div className="bg-[#1a0f00]/80 p-2.5 rounded-2xl border border-[#D4AF37]/40 text-center">
              <span className="text-[10px] text-[#C8B08A] block mb-0.5">وصلت المحطة</span>
              <span className="text-base font-black text-[#E6C37A]">{stats.arrived}</span>
            </div>
            <div className="bg-[#1a0f00]/80 p-2.5 rounded-2xl border border-[#D4AF37]/40 text-center">
              <span className="text-[10px] text-[#C8B08A] block mb-0.5">تم التسليم</span>
              <span className="text-base font-black text-[#FFF8EB]">{stats.delivered}</span>
            </div>
          </div>

          {/* Unpaid Warning Banner */}
          {(stats.totalUnpaidMad > 0 || stats.totalUnpaidMru > 0) && (
            <div className="bg-[#1a0f00]/90 border border-[#D4AF37]/50 p-3 rounded-2xl flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-[#F3A952] shrink-0" />
                <span className="font-bold text-[#F5D799]">المتبقي للتحصيل:</span>
              </div>
              <div className="flex items-center gap-2.5 font-mono font-black text-xs text-[#FFF8EB]" dir="ltr">
                {stats.totalUnpaidMad > 0 && <span>{stats.totalUnpaidMad} MAD</span>}
                {stats.totalUnpaidMru > 0 && <span>{stats.totalUnpaidMru} MRU</span>}
              </div>
            </div>
          )}

          {/* Search and Filters */}
          <div className="bg-[#1a0f00]/80 p-3.5 rounded-[22px] border border-[#D4AF37]/50 space-y-2.5">
            <div className="relative">
              <input
                type="text"
                placeholder="البحث برقم الكولي، الكود، الزبون، الهاتف..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full bg-[#120a00] border border-[#D4AF37]/40 focus:border-[#D4AF37] rounded-xl px-3.5 py-2 text-xs text-white placeholder-[#A68966] focus:outline-none pl-9"
              />
              <Search className="w-4 h-4 text-[#D4AF37] absolute left-3 top-1/2 -translate-y-1/2" />
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <select
                value={statusFilter}
                onChange={e => setStatusFilter(e.target.value)}
                className="w-full bg-[#120a00] border border-[#D4AF37]/35 rounded-xl px-2.5 py-1.5 text-[#E6C37A] text-xs focus:outline-none focus:border-[#D4AF37]"
              >
                <option value="all">جميع الحالات</option>
                <option value="registered">تم التسجيل</option>
                <option value="in_transit">في الطريق</option>
                <option value="arrived">دخلت المحطة</option>
                <option value="delivered">تم التسليم</option>
              </select>

              <select
                value={conditionFilter}
                onChange={e => setConditionFilter(e.target.value)}
                className="w-full bg-[#120a00] border border-[#D4AF37]/35 rounded-xl px-2.5 py-1.5 text-[#E6C37A] text-xs focus:outline-none focus:border-[#D4AF37]"
              >
                <option value="all">حالة الطرد (الكل)</option>
                <option value="normal">✓ عادي وسليم</option>
                <option value="abnormal">⚠ غير عادي</option>
              </select>

              <select
                value={paymentFilter}
                onChange={e => setPaymentFilter(e.target.value as any)}
                className="w-full bg-[#120a00] border border-[#D4AF37]/35 rounded-xl px-2.5 py-1.5 text-[#E6C37A] text-xs focus:outline-none focus:border-[#D4AF37]"
              >
                <option value="all">جميع حالات الدفع</option>
                <option value="settled">خالص بالكامل</option>
                <option value="unpaid">متبقي بذمة العميل</option>
              </select>

              <select
                value={stationFilter}
                onChange={e => setStationFilter(e.target.value)}
                className="w-full bg-[#120a00] border border-[#D4AF37]/35 rounded-xl px-2.5 py-1.5 text-[#E6C37A] text-xs focus:outline-none focus:border-[#D4AF37]"
              >
                <option value="all">جميع المحطات</option>
                {stations.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>

            {/* Multi-Parcel Selection & Batch Print Bar */}
            {filteredParcels.length > 0 && (
              <div className="flex flex-col gap-2 pt-2 border-t border-[#D4AF37]/25 text-xs">
                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      const allSelected = filteredParcels.every(p => selectedParcelIds.has(p.id));
                      if (allSelected) {
                        setSelectedParcelIds(new Set());
                      } else {
                        setSelectedParcelIds(new Set(filteredParcels.map(p => p.id)));
                      }
                    }}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-[#120a00] text-[#E6C37A] border border-[#D4AF37]/40 font-bold transition"
                  >
                    <CheckSquare className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>
                      {filteredParcels.every(p => selectedParcelIds.has(p.id))
                        ? 'إلغاء الكل'
                        : 'تحديد الكل'}
                    </span>
                  </button>

                  {(() => {
                    const refParcel =
                      parcels.find(p => selectedParcelIds.has(p.id)) || filteredParcels[0];
                    if (!refParcel) return null;
                    const refPhone = (refParcel.sender_phone || '').trim();
                    const refName = (refParcel.sender_name || '').trim().toLowerCase();
                    const sameSenderList = parcels.filter(
                      p =>
                        (refPhone && (p.sender_phone || '').trim() === refPhone) ||
                        (refName && (p.sender_name || '').trim().toLowerCase() === refName)
                    );
                    return (
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedParcelIds(new Set(sameSenderList.map(p => p.id)));
                        }}
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-[#2a1800] text-[#F5D799] border border-[#D4AF37]/50 font-bold transition truncate max-w-full"
                      >
                        <Users className="w-3.5 h-3.5 text-[#F3A952] shrink-0" />
                        <span className="truncate">
                          جميع كوليات هذا المرسل ({sameSenderList.length})
                        </span>
                      </button>
                    );
                  })()}
                </div>

                {selectedParcelIds.size > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      const chosen = parcels.filter(p => selectedParcelIds.has(p.id));
                      setBatchStickerParcels(chosen);
                      setIsBatchStickerModalOpen(true);
                    }}
                    className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black transition shadow-md"
                  >
                    <Printer className="w-3.5 h-3.5 stroke-[2.5]" />
                    <span>طباعة الملصقات المحددة ({selectedParcelIds.size})</span>
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Parcels List */}
          {filteredParcels.length === 0 ? (
            <div className="rounded-[22px] bg-[#1a0f00]/80 border border-[#D4AF37]/45 p-6 text-center space-y-2">
              <div className="w-11 h-11 rounded-2xl bg-[#120a00] border border-[#D4AF37]/30 text-[#D4AF37] flex items-center justify-center mx-auto">
                <Package className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-[#F5D799]">لا توجد كوليات مطابقة</h3>
              <p className="text-xs text-[#C8B08A]">
                جرب تغيير شروط البحث أو اضغط على كولي جديد.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredParcels.map(parcel => {
                const remaining = Math.max(0, Math.round((parcel.amount_due - parcel.amount_paid) * 100) / 100);
                const isSettled = remaining <= 0;
                const payerLabel = parcel.payer === 'sender' ? 'المرسل' : 'المستلم';
                const isNormal = (parcel.condition || 'normal') === 'normal';

                return (
                  <div 
                    key={parcel.id}
                    className="bg-[#1a0f00]/80 hover:bg-[#241500]/90 p-3.5 rounded-[22px] border border-[#D4AF37]/50 transition shadow-lg space-y-2.5 text-xs"
                  >
                    {/* Top Row: Meta and Badges */}
                    <div className="flex items-center justify-between pb-2 border-b border-[#D4AF37]/25 flex-wrap gap-1.5">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedParcelIds(prev => {
                              const next = new Set(prev);
                              if (next.has(parcel.id)) {
                                next.delete(parcel.id);
                              } else {
                                next.add(parcel.id);
                              }
                              return next;
                            });
                          }}
                          className="p-1 rounded-lg bg-[#120a00] text-[#F3A952] transition"
                          title="تحديد للطباعة الجماعية"
                        >
                          {selectedParcelIds.has(parcel.id) ? (
                            <CheckSquare className="w-4 h-4 text-[#F3A952]" />
                          ) : (
                            <Square className="w-4 h-4 text-[#A68966]" />
                          )}
                        </button>
                        <span className="font-mono text-xs font-black text-[#F5D799] bg-[#120a00] px-2 py-0.5 rounded-lg border border-[#D4AF37]/40">
                          #{parcel.parcel_number}
                        </span>
                        <span className="font-mono text-[11px] text-[#C8B08A] font-bold">
                          {parcel.tracking_code}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                          isSettled 
                            ? 'bg-[#120a00] text-[#F5D799] border border-[#D4AF37]/40' 
                            : 'bg-rose-950/60 text-rose-300 border border-rose-500/40'
                        }`}>
                          {isSettled ? '✓ خالص' : `متبقي ${remaining} ${parcel.currency}`}
                        </span>

                        <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-gradient-to-r from-[#6E4720] to-[#42280E] text-[#FFF8EB] border border-[#D4AF37]/40">
                          {statusNames[parcel.status] || parcel.status}
                        </span>
                      </div>
                    </div>

                    {/* Abnormal Notes if present */}
                    {!isNormal && parcel.condition_notes && (
                      <div className="bg-[#2a1800] border border-[#D4AF37]/50 rounded-xl p-2 text-[11px] text-[#F5D799] flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 text-[#F3A952] shrink-0 mt-0.5" />
                        <div>
                          <span className="font-bold block">ملاحظة حالة الكولي:</span>
                          <span>{parcel.condition_notes}</span>
                        </div>
                      </div>
                    )}

                    {/* Route and Stations */}
                    <div className="flex items-center justify-between text-[#E6C37A] text-[11px]">
                      <div className="flex items-center gap-1 font-bold">
                        <MapPin className="w-3.5 h-3.5 text-[#F3A952] shrink-0" />
                        <span>{parcel.origin_station_name}</span>
                        <span className="text-[#D4AF37]">➔</span>
                        <span>{parcel.destination_station_name}</span>
                      </div>
                      <span className="text-[#C8B08A] font-mono text-[10px]" dir="ltr">
                        {new Date(parcel.created_at).toLocaleDateString('ar-MA')}
                      </span>
                    </div>

                    {/* Sender & Receiver with WhatsApp link */}
                    <div className="space-y-1.5 bg-[#120a00]/90 p-2.5 rounded-xl border border-[#D4AF37]/30">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[#C8B08A] text-[10px]">المرسل:</span>
                          <span className="font-bold text-[#FFF8EB]">{parcel.sender_name}</span>
                        </div>
                        <a
                          href={getWhatsAppLink(parcel.sender_phone)}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center gap-1 text-[11px] text-[#E6C37A] font-mono"
                          dir="ltr"
                        >
                          <MessageCircle className="w-3 h-3 text-[#F3A952]" />
                          <span>{parcel.sender_phone}</span>
                        </a>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[#C8B08A] text-[10px]">المستلم:</span>
                          <span className="font-bold text-[#FFF8EB]">{parcel.receiver_name}</span>
                        </div>
                        <a
                          href={getWhatsAppLink(parcel.receiver_phone)}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center gap-1 text-[11px] text-[#E6C37A] font-mono"
                          dir="ltr"
                        >
                          <MessageCircle className="w-3 h-3 text-[#F3A952]" />
                          <span>{parcel.receiver_phone}</span>
                        </a>
                      </div>
                    </div>

                    {/* Driver & Trip Info if loaded on a trip */}
                    {parcel.driver_name && (
                      <div className="flex items-center gap-2 bg-[#120a00] border border-[#D4AF37]/35 px-3 py-1.5 rounded-xl text-[11px] text-[#F5D799]">
                        <Truck className="w-3.5 h-3.5 text-[#F3A952] shrink-0" />
                        <span className="font-bold">الشيفور: {parcel.driver_name}</span>
                        {parcel.vehicle_plate && (
                          <span className="font-mono text-[#E6C37A]" dir="ltr">({parcel.vehicle_plate})</span>
                        )}
                      </div>
                    )}

                    {/* Bottom Row: Financials and Action Buttons */}
                    <div className="space-y-2 pt-1.5 border-t border-[#D4AF37]/25">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="font-bold text-[#FFF8EB] truncate max-w-[170px]">
                          {parcel.items_count} طرد - {parcel.description}
                        </span>
                        <span className="font-mono font-black text-[#F3A952]">
                          {parcel.amount_due} {parcel.currency} <span className="text-[10px] text-[#C8B08A] font-sans">({payerLabel})</span>
                        </span>
                      </div>

                      <div className="flex items-center justify-end gap-1.5">
                        {parcel.status !== 'delivered' && (
                          <button
                            onClick={() => {
                              setQuickDeliverParcel(parcel);
                              setIsQuickDeliverOpen(true);
                            }}
                            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-[#120a00] hover:bg-[#2a1800] text-[#F5D799] font-bold text-[11px] border border-[#D4AF37]/45 transition"
                          >
                            <UserCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
                            <span>تسليم</span>
                          </button>
                        )}

                        <button
                          onClick={() => setTicketParcel(parcel)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-[#120a00] hover:bg-[#2a1800] text-[#E6C37A] font-bold text-[11px] transition border border-[#D4AF37]/45"
                          title="طباعة لاصقة الكولي (10cm × 10cm)"
                        >
                          <Printer className="w-3.5 h-3.5 text-[#F3A952]" />
                          <span>طباعة</span>
                        </button>

                        <button
                          onClick={() => setDetailParcel(parcel)}
                          className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black text-[11px] transition shadow-sm"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>التفاصيل والتتبع</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: TRIPS MANAGEMENT (الرحلات والديسباتش) */}
      {/* ========================================================================= */}
      {activeTab === 'trips' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between bg-[#1a0f00]/80 p-3.5 rounded-[22px] border border-[#D4AF37]/50">
            <div>
              <h2 className="text-xs font-black text-[#F5D799] flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-[#F3A952]" />
                <span>رحلات الشحن بين المحطات</span>
              </h2>
            </div>
            <button
              onClick={() => setIsNewTripOpen(true)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black text-xs transition shadow-md active:scale-95"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>رحلة جديدة</span>
            </button>
          </div>

          {trips.length === 0 ? (
            <div className="rounded-[22px] bg-[#1a0f00]/80 border border-[#D4AF37]/45 p-6 text-center space-y-3">
              <Truck className="w-6 h-6 text-[#D4AF37] mx-auto" />
              <h3 className="text-sm font-bold text-[#F5D799]">لا توجد رحلات شحن مسجلة بعد</h3>
              <button
                onClick={() => setIsNewTripOpen(true)}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black text-xs transition"
              >
                إنشاء أول رحلة شحن الآن
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {trips.map(trip => {
                const statusMeta = tripStatusNames[trip.status] || { label: trip.status, color: 'bg-[#120a00] text-[#E6C37A]' };
                const loadedCount = trip.loaded_parcel_ids.length;
                const receivedCount = trip.received_parcel_ids.length;
                const missingCount = Math.max(0, loadedCount - receivedCount);

                return (
                  <div
                    key={trip.id}
                    className="bg-[#1a0f00]/80 p-3.5 rounded-[22px] border border-[#D4AF37]/50 shadow-md space-y-2.5 text-xs"
                  >
                    <div className="flex items-center justify-between pb-2 border-b border-[#D4AF37]/25">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-black text-xs text-[#F5D799] bg-[#120a00] px-2 py-0.5 rounded-lg border border-[#D4AF37]/40">
                          {trip.trip_code}
                        </span>
                        <span className="font-mono text-[10px] text-[#C8B08A]" dir="ltr">
                          #{trip.trip_number}
                        </span>
                      </div>
                      <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold border ${statusMeta.color}`}>
                        {statusMeta.label}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[#FFF8EB] font-bold text-xs">
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-[#F3A952]" />
                        <span>{trip.origin_station_name}</span>
                        <span className="text-[#D4AF37]">➔</span>
                        <span>{trip.destination_station_name}</span>
                      </div>
                      <span className="text-[10px] text-[#C8B08A] font-mono" dir="ltr">
                        {new Date(trip.created_at).toLocaleDateString('ar-MA')}
                      </span>
                    </div>

                    <div className="bg-[#120a00]/90 p-2.5 rounded-xl border border-[#D4AF37]/30 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[#C8B08A] text-[11px]">الشيفور: <strong className="text-[#FFF8EB]">{trip.driver_name}</strong></span>
                        <span className="font-mono font-bold text-[#E6C37A]" dir="ltr">{trip.vehicle_plate}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[11px] bg-[#120a00] px-3 py-1.5 rounded-xl border border-[#D4AF37]/20">
                      <span className="text-[#C8B08A]">
                        الكوليات المحملة: <strong className="text-[#F3A952]">{loadedCount}</strong>
                      </span>
                      {trip.status !== 'loading' && (
                        <span className="text-[#C8B08A]">
                          المستلم: <strong className="text-[#F5D799]">{receivedCount}</strong> / مفقود: <strong className={missingCount > 0 ? 'text-rose-400' : 'text-[#E6C37A]'}>{missingCount}</strong>
                        </span>
                      )}
                    </div>

                    <div className="pt-1">
                      {trip.status === 'loading' ? (
                        <button
                          onClick={() => setDispatchTrip(trip)}
                          className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black text-xs transition flex items-center justify-center gap-1.5 shadow-md"
                        >
                          <Scan className="w-4 h-4 stroke-[2.5]" />
                          <span>فتح لشحن ومسح الكوليات (ديسباتش) ➔</span>
                        </button>
                      ) : (
                        <div className="flex items-center gap-2 w-full">
                          <button
                            onClick={() => setDispatchTrip(trip)}
                            className="flex-1 py-2 rounded-xl bg-[#120a00] border border-[#D4AF37]/40 text-[#E6C37A] font-bold text-[11px] transition text-center"
                          >
                            مانيفست الشحن ({loadedCount})
                          </button>
                          
                          {trip.status !== 'closed' && (
                            <button
                              onClick={() => setArrivalTrip(trip)}
                              className="flex-1 py-2 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black text-[11px] transition text-center flex items-center justify-center gap-1"
                            >
                              <Inbox className="w-3.5 h-3.5" />
                              <span>استقبال وتفريغ</span>
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: INCOMING TRIPS TO STATION */}
      {/* ========================================================================= */}
      {activeTab === 'incoming' && (
        <div className="space-y-3">
          <div className="bg-[#1a0f00]/80 p-3.5 rounded-[22px] border border-[#D4AF37]/50 space-y-1">
            <h2 className="text-xs font-black text-[#F5D799] flex items-center gap-1.5">
              <Inbox className="w-4 h-4 text-[#F3A952]" />
              <span>الرحلات القادمة نحو [{activeStation?.name || 'المحطة'}]</span>
            </h2>
          </div>

          {incomingTrips.length === 0 ? (
            <div className="rounded-[22px] bg-[#1a0f00]/80 border border-[#D4AF37]/45 p-6 text-center space-y-2">
              <Truck className="w-6 h-6 text-[#D4AF37] mx-auto" />
              <h3 className="text-xs font-bold text-[#F5D799]">لا توجد رحلات قادمة في الطريق حالياً</h3>
            </div>
          ) : (
            <div className="space-y-3">
              {incomingTrips.map(trip => {
                const totalLoaded = trip.loaded_parcel_ids.length;
                const receivedCount = trip.received_parcel_ids.length;
                const missingCount = Math.max(0, totalLoaded - receivedCount);
                const isFinished = missingCount === 0 && totalLoaded > 0;

                return (
                  <div 
                    key={trip.id}
                    className="bg-[#1a0f00]/80 p-4 rounded-[22px] border border-[#D4AF37]/60 space-y-3 shadow-xl"
                  >
                    <div className="flex items-center justify-between pb-2 border-b border-[#D4AF37]/25">
                      <div>
                        <span className="font-mono font-black text-xs text-[#F5D799] bg-[#120a00] px-2 py-0.5 rounded-lg border border-[#D4AF37]/40">
                          {trip.trip_code}
                        </span>
                        <p className="text-[11px] text-[#C8B08A] mt-1">
                          الشيفور: <strong className="text-white">{trip.driver_name}</strong> ({trip.vehicle_plate})
                        </p>
                      </div>

                      <button
                        onClick={() => setArrivalTrip(trip)}
                        className="px-3 py-2 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black text-xs transition shadow-md flex items-center gap-1"
                      >
                        <Scan className="w-3.5 h-3.5 stroke-[2.5]" />
                        <span>مسح الاستقبال</span>
                      </button>
                    </div>

                    <div className="text-[11px] text-[#E6C37A]">
                      {isFinished ? '✓ تم مسح جميع الكوليات' : `${receivedCount} تم مسحه / ${missingCount} متبقي`}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: STATION OVERVIEW */}
      {/* ========================================================================= */}
      {activeTab === 'overview' && (
        <div className="space-y-3">
          {stations.map(st => {
            const inTransitParcels = parcels.filter(
              p => p.destination_station_id === st.id && p.status === 'in_transit'
            );
            const waitingForDelivery = parcels.filter(
              p => p.destination_station_id === st.id && p.status === 'arrived'
            );

            return (
              <div 
                key={st.id}
                className="bg-[#1a0f00]/80 p-4 rounded-[22px] border border-[#D4AF37]/50 space-y-3 shadow-md"
              >
                <div className="flex items-center justify-between pb-2 border-b border-[#D4AF37]/25">
                  <div className="flex items-center gap-2">
                    <span className="text-base">{st.country === 'MA' ? '🇲🇦' : '🇲🇷'}</span>
                    <div>
                      <h3 className="text-xs font-black text-[#F5D799]">{st.name} ({st.city})</h3>
                      <span className="text-[10px] text-[#C8B08A]">{st.address}</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-[#120a00] p-2.5 rounded-xl border border-[#D4AF37]/30 text-center">
                    <span className="block text-[10px] text-[#C8B08A]">قادم في الطريق</span>
                    <span className="font-black text-sm text-[#F3A952]">{inTransitParcels.length} كولي</span>
                  </div>
                  <div className="bg-[#120a00] p-2.5 rounded-xl border border-[#D4AF37]/30 text-center">
                    <span className="block text-[10px] text-[#C8B08A]">بانتظار التسليم</span>
                    <span className="font-black text-sm text-[#F5D799]">{waitingForDelivery.length} كولي</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ========================================================================= */}
      {/* ALL MODALS */}
      {/* ========================================================================= */}

      <NewTripModal
        isOpen={isNewTripOpen}
        onClose={() => setIsNewTripOpen(false)}
        onTripCreated={(newT) => {
          setIsNewTripOpen(false);
          setDispatchTrip(newT);
        }}
      />

      <TripDispatchModal
        trip={dispatchTrip}
        isOpen={Boolean(dispatchTrip)}
        onClose={() => setDispatchTrip(null)}
        onOpenTicket={(p) => setTicketParcel(p)}
      />

      <TripArrivalModal
        trip={arrivalTrip}
        isOpen={Boolean(arrivalTrip)}
        onClose={() => setArrivalTrip(null)}
        onOpenTicket={(p) => setTicketParcel(p)}
      />

      <QuickDeliverModal
        isOpen={isQuickDeliverOpen}
        onClose={() => {
          setIsQuickDeliverOpen(false);
          setQuickDeliverParcel(null);
        }}
        initialParcel={quickDeliverParcel}
        onOpenTicket={(p) => setTicketParcel(p)}
      />

      <BarcodeScannerModal
        isOpen={isBarcodeScannerOpen}
        onClose={() => setIsBarcodeScannerOpen(false)}
        onScan={handleGlobalScanResult}
        title="مسح باركود أو رمز كولي (QR)"
        subtitle="امسح تذكرة الكولي بالكاميرا أو بقارئ الباركود اليدوي لعرض تفاصيله وتسليمه"
      />

      <ParcelStickerModal
        parcel={ticketParcel}
        initialSelectedParcels={batchStickerParcels}
        isOpen={Boolean(ticketParcel) || isBatchStickerModalOpen}
        onClose={() => {
          setTicketParcel(null);
          setBatchStickerParcels(undefined);
          setIsBatchStickerModalOpen(false);
        }}
      />

      <ParcelDetailModal
        parcel={detailParcel}
        isOpen={Boolean(detailParcel)}
        onClose={() => setDetailParcel(null)}
        onOpenTicket={(p) => setTicketParcel(p)}
      />

    </div>
  );
};
