import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  AlertTriangle, 
  MessageCircle, 
  ShieldCheck, 
  Sparkles, 
  X,
  CheckCircle,
  Clock
} from 'lucide-react';

interface PaywallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PaywallModal: React.FC<PaywallModalProps> = ({ isOpen, onClose }) => {
  const { 
    currentTeam, 
    subscription, 
    isSubscriptionExpired, 
    daysUntilExpiry, 
    extendSubscription 
  } = useApp();

  if (!isOpen) return null;

  const adminWhatsApp = import.meta.env.VITE_ADMIN_WHATSAPP || '212600000000';

  const handleOpenWhatsApp = () => {
    const text = `السلام عليكم ورحمة الله،
أريد تجديد اشتراك فريق "${currentTeam?.name || 'محطة الاتحادية'}" في تطبيق محطة الاتحادية لإدارة الإرساليات والتحويلات المالية والصناديق النقدية.
معرف الفريق: ${currentTeam?.id}
المبلغ: 99 درهماً شهرياً`;

    window.open(`https://wa.me/${adminWhatsApp.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4 animate-fadeIn">
      <div 
        className="w-full max-w-sm rounded-3xl bg-[#131C2E] border border-slate-700/80 p-5 shadow-2xl text-right overflow-hidden relative"
        onClick={e => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 left-4 p-1.5 rounded-full text-slate-400 hover:text-white bg-slate-800/80 transition"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Top Logo & Status Badge */}
        <div className="relative w-16 h-16 mx-auto mb-3">
          <div 
            className="w-16 h-16 rounded-full ring-2 ring-amber-500/40 shadow-xl shadow-amber-950/50 overflow-hidden flex items-center justify-center p-0"
            style={{ background: 'transparent', borderRadius: '50%', padding: 0, overflow: 'hidden' }}
          >
            <img 
              src="/logo.png" 
              alt="شعار محطة الاتحادية" 
              style={{ borderRadius: '50%', width: '100%', height: '100%', objectFit: 'cover', background: 'transparent', display: 'block' }}
            />
          </div>
          <div className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center shadow-lg border-2 border-[#131C2E] ${
            isSubscriptionExpired 
              ? 'bg-rose-500 text-white' 
              : 'bg-emerald-500 text-slate-950'
          }`}>
            {isSubscriptionExpired ? (
              <AlertTriangle className="w-3.5 h-3.5 stroke-[2.5]" />
            ) : (
              <Clock className="w-3.5 h-3.5 stroke-[2.5]" />
            )}
          </div>
        </div>

        {/* Title & Status */}
        <h3 className="text-lg font-black text-white text-center mb-1">
          {isSubscriptionExpired ? 'انتهت صلاحية الاشتراك' : 'حالة اشتراك الفريق'}
        </h3>

        <div className="text-center mb-4">
          {isSubscriptionExpired ? (
            <span className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
              مطلوب التجديد لمتابعة إضافة الإيصالات
            </span>
          ) : (
            <span className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              فترة تجريبية مجانية (يتبقى {daysUntilExpiry} أيام)
            </span>
          )}
        </div>

        {/* Explanation Card */}
        <div className="bg-[#0B1220] p-4 rounded-2xl border border-slate-800 space-y-2.5 text-xs text-slate-300 mb-4">
          <p className="font-bold text-white text-sm">
            {isSubscriptionExpired ? 'سداد 99 درهماً للمشرف عبر تطبيق المراسلة' : 'رسوم الاشتراك: 99 درهماً شهرياً'}
          </p>

          <div className="flex items-start gap-2 pt-1">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <p className="text-[11px] text-slate-400">
              <strong className="text-slate-200">الاطلاع متاح دائماً:</strong> يمكنك دوماً فحص الأرصدة وسجل الإيصالات وأداء المحطات حتى عند انتهاء الاشتراك.
            </p>
          </div>

          <div className="flex items-start gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <p className="text-[11px] text-slate-400">
              <strong className="text-slate-200">الحماية في قاعدة البيانات:</strong> منع تسجيل الإيصالات الجديدة ينفذه المشغل التلقائي في قاعدة البيانات لحماية حساب الفريق.
            </p>
          </div>
        </div>

        {/* Renewal CTA Button */}
        <button
          onClick={handleOpenWhatsApp}
          className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-slate-950 font-bold text-sm shadow-xl shadow-emerald-500/20 transition active:scale-98 flex items-center justify-center gap-2 mb-2"
        >
          <MessageCircle className="w-5 h-5 fill-slate-950" />
          <span>تجديد الاشتراك عبر تطبيق المراسلة (99 درهماً)</span>
        </button>

        {/* Instant Demo Extension for quick testing */}
        <button
          onClick={() => {
            extendSubscription(30);
            onClose();
          }}
          className="w-full py-2.5 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>تفعيل وتمديد 30 يوماً تجريبياً (محاكاة فورية)</span>
        </button>

        <p className="text-[10px] text-slate-500 text-center mt-3">
          رقم المشرف للتواصل: {adminWhatsApp}
        </p>

      </div>
    </div>
  );
};
