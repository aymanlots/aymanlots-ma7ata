import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Parcel, ParcelPayer } from '../types/database';
import confetti from 'canvas-confetti';
import { 
  X, 
  Package, 
  MapPin, 
  Phone, 
  User, 
  CheckCircle2, 
  DollarSign, 
  FileText, 
  ArrowRightLeft, 
  AlertCircle,
  Truck,
  Printer,
  Scale
} from 'lucide-react';

interface NewParcelModalProps {
  isOpen: boolean;
  onClose: () => void;
  onParcelCreated?: (parcel: Parcel) => void;
}

export const NewParcelModal: React.FC<NewParcelModalProps> = ({ 
  isOpen, 
  onClose,
  onParcelCreated 
}) => {
  const { 
    stations, 
    selectedStationId, 
    currencies, 
    createParcel, 
    isSubscriptionExpired,
    showToast 
  } = useApp();

  const [originStationId, setOriginStationId] = useState<string>(
    selectedStationId || stations[0]?.id || ''
  );
  const [destinationStationId, setDestinationStationId] = useState<string>(
    stations.find(s => s.id !== (selectedStationId || stations[0]?.id))?.id || stations[1]?.id || ''
  );

  const [senderName, setSenderName] = useState('');
  const [senderPhone, setSenderPhone] = useState('');
  const [receiverName, setReceiverName] = useState('');
  const [receiverPhone, setReceiverPhone] = useState('');

  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('طرد بضائع عامة');
  const [itemsCount, setItemsCount] = useState('1');
  const [weightKg, setWeightKg] = useState('');
  
  // Financial fields
  const [amountDue, setAmountDue] = useState('200');
  const [payer, setPayer] = useState<ParcelPayer>('sender');
  const [amountPaid, setAmountPaid] = useState('200'); // Default upfront paid
  const [currency, setCurrency] = useState(currencies[0]?.code || 'MAD');
  const [notes, setNotes] = useState('');

  // حالة الكولي (عادي / غير عادي)
  const [condition, setCondition] = useState<'normal' | 'abnormal'>('normal');
  const [conditionNotes, setConditionNotes] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const originSt = stations.find(s => s.id === originStationId);
  const destSt = stations.find(s => s.id === destinationStationId);

  const categories = [
    'طرد بضائع عامة',
    'ملابس وأقمشة صحراوية',
    'أجهزة إلكترونية وهواتف',
    'قطع غيار سيارات وشاحنات',
    'مواد غذائية وشاي تقليدي',
    'وثائق ومستندات ورقية',
    'بضائع تجارية أخرى'
  ];

  const handlePayerChange = (newPayer: ParcelPayer) => {
    setPayer(newPayer);
    if (newPayer === 'sender') {
      // If sender pays, default already paid to total
      setAmountPaid(amountDue);
    } else {
      // If receiver pays, default already paid to 0
      setAmountPaid('0');
    }
  };

  const handleAmountDueChange = (val: string) => {
    setAmountDue(val);
    if (payer === 'sender') {
      setAmountPaid(val);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (isSubscriptionExpired) {
      setErrorMessage('انتهت صلاحية اشتراك مساحة العمل. يرجى التجديد لتسجيل كوليات جديدة.');
      return;
    }

    if (!senderName.trim()) {
      setErrorMessage('يرجى إدخال اسم المرسل');
      return;
    }
    if (!senderPhone.trim() || senderPhone.trim().length < 6) {
      setErrorMessage('يرجى إدخال رقم هاتف المرسل بشكل صحيح');
      return;
    }
    if (!receiverName.trim()) {
      setErrorMessage('يرجى إدخال اسم المستلم');
      return;
    }
    if (!receiverPhone.trim() || receiverPhone.trim().length < 6) {
      setErrorMessage('يرجى إدخال رقم هاتف المستلم بشكل صحيح');
      return;
    }
    if (!description.trim()) {
      setErrorMessage('يرجى إدخال وصف حر للبضاعة');
      return;
    }
    if (originStationId === destinationStationId) {
      setErrorMessage('لا يمكن أن تكون محطة الانطلاق والوصول هي نفس المحطة');
      return;
    }

    const dueNum = parseFloat(amountDue) || 0;
    const paidNum = parseFloat(amountPaid) || 0;

    if (dueNum < 0) {
      setErrorMessage('المبلغ المستحق لا يمكن أن يكون سالباً');
      return;
    }
    if (paidNum > dueNum) {
      setErrorMessage('المبلغ المدفوع لا يمكن أن يتجاوز المبلغ الإجمالي المستحق');
      return;
    }

    if (condition === 'abnormal' && !conditionNotes.trim()) {
      setErrorMessage('يرجى كتابة ملاحظات وتفاصيل حالة الكولي غير العادية (مثل تمزق أو رطوبة أو كسر)');
      return;
    }

    try {
      setIsSubmitting(true);

      const res = await createParcel({
        origin_station_id: originStationId,
        destination_station_id: destinationStationId,
        sender_name: senderName.trim(),
        sender_phone: senderPhone.trim(),
        receiver_name: receiverName.trim(),
        receiver_phone: receiverPhone.trim(),
        description: description.trim(),
        category,
        items_count: parseInt(itemsCount, 10) || 1,
        weight_kg: weightKg ? parseFloat(weightKg) : undefined,
        amount_due: dueNum,
        payer,
        amount_paid: paidNum,
        currency,
        notes: notes.trim() || undefined,
        condition,
        condition_notes: condition === 'abnormal' ? conditionNotes.trim() : undefined,
        route: `${originSt?.city || 'الداخلة'} ➔ الكركرات ➔ ${destSt?.city || 'نواذيبو'}`
      });

      setIsSubmitting(false);

      if (res.success && res.parcel) {
        try {
          confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
        } catch {}

        if (onParcelCreated) {
          onParcelCreated(res.parcel);
        }
        onClose();
      } else {
        setErrorMessage(res.error || 'حدث خطأ أثناء حفظ الكولي');
      }
    } catch (err: any) {
      setIsSubmitting(false);
      setErrorMessage(err.message || 'حدث خطأ غير متوقع');
    }
  };

  const remaining = Math.max(0, Math.round(((parseFloat(amountDue) || 0) - (parseFloat(amountPaid) || 0)) * 100) / 100);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 animate-fadeIn overflow-y-auto" dir="rtl">
      <div className="fixed inset-0 bg-black/90 backdrop-blur-sm" onClick={onClose} />

      <div 
        className="w-full max-w-[380px] rounded-[24px] bg-[#140b00] border border-[#D4AF37]/65 p-4 shadow-2xl text-right overflow-hidden relative z-10 my-4 space-y-3.5 max-h-[90vh] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#D4AF37]/25 pb-2.5 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] flex items-center justify-center">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black text-[#F5D799]">
                تسجيل كولي جديد (إرسالية بضائع)
              </h2>
              <p className="text-[10px] text-[#E6C37A] font-bold">
                توليد رقم كولي وتذكرة حرارية تلقائياً
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-[#1a0f00] border border-[#D4AF37]/40 text-[#E6C37A] hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Error message */}
        {errorMessage && (
          <div className="bg-rose-950/60 border border-rose-500/40 p-3 rounded-2xl text-xs text-rose-300 flex items-center gap-2 font-bold shrink-0">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Form Body - Scrollable */}
        <form onSubmit={handleSubmit} className="space-y-3 overflow-y-auto pr-1 text-xs flex-1">
          
          {/* 1. Stations Selection (From / To) */}
          <div className="bg-[#1a0f00]/80 p-3 rounded-2xl border border-[#D4AF37]/45 space-y-2">
            <span className="font-bold text-[#F5D799] flex items-center gap-1.5 text-xs">
              <MapPin className="w-3.5 h-3.5 text-[#F3A952]" />
              <span>خط النقل والمحطات:</span>
            </span>
            <div className="grid grid-cols-1 gap-2">
              <div>
                <label className="block text-[#C8B08A] mb-1 font-bold text-[11px]">محطة الانطلاق (الشحن):</label>
                <select
                  value={originStationId}
                  onChange={e => setOriginStationId(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-[#FFF8EB] font-bold text-xs focus:outline-none focus:border-[#D4AF37]"
                  required
                >
                  {stations.map(st => (
                    <option key={st.id} value={st.id}>
                      {st.name} ({st.city})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[#C8B08A] mb-1 font-bold text-[11px]">محطة الوصول (التسليم):</label>
                <select
                  value={destinationStationId}
                  onChange={e => setDestinationStationId(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-[#FFF8EB] font-bold text-xs focus:outline-none focus:border-[#D4AF37]"
                  required
                >
                  {stations.map(st => (
                    <option key={st.id} value={st.id}>
                      {st.name} ({st.city})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* 2. Sender and Receiver Information */}
          <div className="grid grid-cols-1 gap-2.5">
            {/* Sender */}
            <div className="bg-[#1a0f00]/80 p-3 rounded-2xl border border-[#D4AF37]/45 space-y-2">
              <span className="font-bold text-[#F5D799] block text-xs">بيانات المرسل:</span>
              <div>
                <label className="block text-[#C8B08A] mb-1 text-[11px]">الاسم الكامل *</label>
                <input
                  type="text"
                  placeholder="اسم مرسل البضاعة"
                  required
                  value={senderName}
                  onChange={e => setSenderName(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
              <div>
                <label className="block text-[#C8B08A] mb-1 text-[11px]">رقم الهاتف / الواتساب *</label>
                <input
                  type="tel"
                  placeholder="0600000000 أو 222..."
                  required
                  value={senderPhone}
                  onChange={e => setSenderPhone(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
            </div>

            {/* Receiver */}
            <div className="bg-[#1a0f00]/80 p-3 rounded-2xl border border-[#D4AF37]/45 space-y-2">
              <span className="font-bold text-[#E6C37A] block text-xs">بيانات المستلم:</span>
              <div>
                <label className="block text-[#C8B08A] mb-1 text-[11px]">الاسم الكامل *</label>
                <input
                  type="text"
                  placeholder="اسم المستلم في الوجهة"
                  required
                  value={receiverName}
                  onChange={e => setReceiverName(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
              <div>
                <label className="block text-[#C8B08A] mb-1 text-[11px]">رقم الهاتف / الواتساب *</label>
                <input
                  type="tel"
                  placeholder="0600000000 أو 222..."
                  required
                  value={receiverPhone}
                  onChange={e => setReceiverPhone(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
            </div>
          </div>

          {/* 3. Goods Free-Text Description, Quantity, Weight */}
          <div className="bg-[#1a0f00]/80 p-3 rounded-2xl border border-[#D4AF37]/45 space-y-2">
            <span className="font-bold text-[#F5D799] block text-xs">مواصفات وبيان البضاعة:</span>
            
            <div>
              <label className="block text-[#C8B08A] mb-1 text-[11px]">وصف حر لمحتوى الطرد أو البضاعة *</label>
              <textarea
                placeholder="اكتب بالتفصيل نوع البضاعة، الماركة، أو أي تفاصيل تميز الكولي..."
                rows={2}
                required
                value={description}
                onChange={e => setDescription(e.target.value)}
                className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-[#D4AF37] leading-relaxed"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="col-span-2">
                <label className="block text-[#C8B08A] mb-1 text-[11px]">تصنيف البضاعة:</label>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-1.5 text-white text-xs focus:outline-none focus:border-[#D4AF37]"
                >
                  {categories.map(c => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[#C8B08A] mb-1 text-[11px]">عدد الطرود *</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={itemsCount}
                  onChange={e => setItemsCount(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div>
                <label className="block text-[#C8B08A] mb-1 text-[11px]">الوزن (كغ) [اختياري]:</label>
                <input
                  type="number"
                  step="0.1"
                  placeholder="مثال: 15.5"
                  value={weightKg}
                  onChange={e => setWeightKg(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
            </div>
          </div>

          {/* 4. Financial Details (Amount Due, Payer, Amount Paid, Currency) */}
          <div className="bg-[#1a0f00]/80 p-3 rounded-2xl border border-[#D4AF37]/45 space-y-2.5">
            <span className="font-bold text-[#F5D799] flex items-center gap-1.5 text-xs">
              <DollarSign className="w-3.5 h-3.5 text-[#F3A952]" />
              <span>المستحقات المالية وطريقة الأداء:</span>
            </span>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[#C8B08A] mb-1 text-[11px]">المبلغ الإجمالي *</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  required
                  value={amountDue}
                  onChange={e => handleAmountDueChange(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white font-mono font-bold text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div>
                <label className="block text-[#C8B08A] mb-1 text-[11px]">العملة:</label>
                <select
                  value={currency}
                  onChange={e => setCurrency(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white font-mono font-bold text-xs focus:outline-none focus:border-[#D4AF37]"
                >
                  {currencies.map(c => (
                    <option key={c.code} value={c.code}>
                      {c.code} ({c.label_ar})
                    </option>
                  ))}
                </select>
              </div>

              <div className="col-span-2">
                <label className="block text-[#C8B08A] mb-1 text-[11px]">الطرف الملزم بالأداء *</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handlePayerChange('sender')}
                    className={`py-2 rounded-xl text-xs font-bold border transition ${
                      payer === 'sender'
                        ? 'bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] border-[#F8C885] font-black'
                        : 'bg-[#120a00] text-[#C8B08A] border-[#D4AF37]/35'
                    }`}
                  >
                    المرسل
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePayerChange('receiver')}
                    className={`py-2 rounded-xl text-xs font-bold border transition ${
                      payer === 'receiver'
                        ? 'bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] border-[#F8C885] font-black'
                        : 'bg-[#120a00] text-[#C8B08A] border-[#D4AF37]/35'
                    }`}
                  >
                    المستلم
                  </button>
                </div>
              </div>
            </div>

            {/* Amount Paid Upfront */}
            <div className="grid grid-cols-1 gap-2 pt-1">
              <div>
                <label className="block text-[#C8B08A] mb-1 text-[11px]">المبلغ المدفوع الآن في المحطة:</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  max={amountDue}
                  required
                  value={amountPaid}
                  onChange={e => setAmountPaid(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white font-mono font-bold text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div className="bg-[#120a00] p-2.5 rounded-xl border border-[#D4AF37]/30 flex items-center justify-between">
                <span className="text-[11px] text-[#C8B08A]">المبلغ المتبقي للتحصيل:</span>
                <span className={`font-mono font-black text-xs ${remaining > 0 ? 'text-rose-400' : 'text-[#F5D799]'}`}>
                  {remaining} {currency} {remaining === 0 ? '(خالص)' : '(متبقي)'}
                </span>
              </div>
            </div>
          </div>

          {/* 5. Parcel Condition (حالة الكولي: عادي / غير عادي) */}
          <div className="bg-[#1a0f00]/80 p-3 rounded-2xl border border-[#D4AF37]/45 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[#F5D799] block text-xs">حالة وسلامة الكولي:</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-[#120a00] text-[#E6C37A] border border-[#D4AF37]/40">
                {condition === 'normal' ? '✓ سليم وعادي' : '⚠ غير عادي'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setCondition('normal')}
                className={`flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl text-xs font-bold border transition ${
                  condition === 'normal'
                    ? 'bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] border-[#F8C885] font-black shadow-sm'
                    : 'bg-[#120a00] text-[#C8B08A] border-[#D4AF37]/35'
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>عادي (سليم)</span>
              </button>

              <button
                type="button"
                onClick={() => setCondition('abnormal')}
                className={`flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl text-xs font-bold border transition ${
                  condition === 'abnormal'
                    ? 'bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] border-[#F8C885] font-black shadow-sm'
                    : 'bg-[#120a00] text-[#C8B08A] border-[#D4AF37]/35'
                }`}
              >
                <AlertCircle className="w-3.5 h-3.5" />
                <span>غير عادي (عيب)</span>
              </button>
            </div>

            {condition === 'abnormal' && (
              <div className="pt-1 space-y-1">
                <label className="block text-[#F5D799] text-[11px] font-bold">
                  وصف حالة العيب أو التلف (إلزامي للتوثيق) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: الكرتون ممزق من الزاوية..."
                  value={conditionNotes}
                  onChange={e => setConditionNotes(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/60 rounded-xl px-3 py-2 text-white text-xs placeholder-[#A68966] focus:outline-none"
                />
              </div>
            )}
          </div>

          {/* Notes */}
          <div>
            <label className="block text-[#C8B08A] mb-1 text-[11px]">ملاحظات إضافية (اختياري):</label>
            <input
              type="text"
              placeholder="مثال: يرجى الاتصال بالمستلم قبل التوصيل"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-[#D4AF37]"
            />
          </div>

          {/* Submit Button */}
          <div className="pt-2 shrink-0">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#F5B05B] via-[#E5953E] to-[#D4882A] hover:brightness-110 text-[#1a0f00] font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-[#E5953E]/25 border border-[#F8C885] active:scale-95 transition disabled:opacity-50"
            >
              <Package className="w-4 h-4" />
              <span>{isSubmitting ? 'جاري تسجيل الكولي...' : 'تأكيد التسجيل وطباعة التذكرة الحرارية'}</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
