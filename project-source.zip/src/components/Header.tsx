import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PWAInstallButton } from './PWAInstallButton';
import { 
  Store, 
  User, 
  Crown, 
  Clock, 
  AlertTriangle,
  Database,
  Menu,
  X,
  ChevronDown,
  Settings,
  LogOut,
  Sparkles,
  ShieldCheck
} from 'lucide-react';

interface HeaderProps {
  onOpenSettings: () => void;
  onOpenPaywall: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  onOpenSettings, 
  onOpenPaywall
}) => {
  const { 
    currentUser, 
    userRole, 
    stations, 
    selectedStationId, 
    setSelectedStationId,
    daysUntilExpiry,
    isSubscriptionExpired,
    logout,
    isSupabaseLive,
    exchangeRate
  } = useApp();

  const [showStationMenu, setShowStationMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const currentStation = stations.find(s => s.id === selectedStationId);

  return (
    <>
      <header className="sticky top-0 z-40 bg-[#080502]/95 backdrop-blur-xl border-b border-[#D4AF37]/20 px-3.5 py-2.5 pt-safe relative shadow-2xl">
        <div className="w-full mx-auto flex items-center justify-between gap-2 relative z-10" dir="rtl">
          
          {/* Right Section (RTL): Large Golden Title "محطة الاتحادية" + Subtitle "تتبع الشحنة" + Compact Station/Menu Control */}
          <div className="flex flex-col items-start text-right min-w-0 flex-1">
            <h1 className="text-[24px] font-black tracking-tight text-[#E6C37A] leading-tight truncate drop-shadow-[0_2px_8px_rgba(212,175,55,0.25)]">
              محطة الاتحادية
            </h1>
            <div className="flex items-center gap-2 mt-0.5">
              <p className="text-[14px] text-[#D9B36C] font-bold leading-tight">
                تتبع الشحنة
              </p>
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-[#1a0f00]/80 border border-[#D4AF37]/40 text-[10px] font-bold text-[#E6C37A] hover:border-[#D4AF37] transition active:scale-95"
                title="القائمة والمحطات"
              >
                <Store className="w-2.5 h-2.5 text-[#D4AF37] shrink-0" />
                <span className="max-w-[75px] truncate">{currentStation ? currentStation.city : 'المحطة'}</span>
                <Menu className="w-3 h-3 text-[#D4AF37] mr-0.5" />
              </button>
            </div>
          </div>

          {/* Left Section (RTL): Circular 3D Official Logo (Matches Reference 100%) */}
          <div 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="shrink-0 overflow-hidden rounded-full p-0 flex items-center justify-center cursor-pointer shadow-[0_0_20px_rgba(212,175,55,0.25)] active:scale-95 transition"
            style={{ background: 'transparent', borderRadius: '50%', padding: 0, overflow: 'hidden', width: '74px', height: '74px', border: '2px solid #D4AF37' }}
            title="القائمة الرئيسية"
          >
            <img 
              src="/logo.png" 
              alt="شعار محطة الاتحادية" 
              style={{ borderRadius: '50%', width: '74px', height: '74px', objectFit: 'cover', background: 'transparent', display: 'block' }}
            />
          </div>

        </div>
      </header>

      {/* Mobile Drawer / Full Dropdown Menu (Constrained to 390px) */}
      {mobileMenuOpen && (
        <div 
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm animate-fadeIn flex flex-col justify-end items-center"
          onClick={() => setMobileMenuOpen(false)}
        >
          <div 
            className="w-full max-w-[390px] bg-[#140b00] border-t-2 border-[#D4AF37]/60 rounded-t-3xl p-5 shadow-2xl max-h-[85vh] overflow-y-auto space-y-4 text-right"
            onClick={e => e.stopPropagation()}
            dir="rtl"
          >
            {/* Header of Drawer */}
            <div className="flex items-center justify-between border-b border-[#D4AF37]/25 pb-3">
              <div className="flex items-center gap-2.5">
                <div 
                  className="w-10 h-10 rounded-full border border-[#D4AF37] overflow-hidden shrink-0 flex items-center justify-center p-0"
                  style={{ background: 'transparent', borderRadius: '50%', padding: 0, overflow: 'hidden' }}
                >
                  <img 
                    src="/logo.png" 
                    alt="محطة الاتحادية" 
                    style={{ borderRadius: '50%', width: '100%', height: '100%', objectFit: 'cover', background: 'transparent', display: 'block' }} 
                  />
                </div>
                <div>
                  <h3 className="text-sm font-black text-[#E6C37A]">محطة الاتحادية</h3>
                  <p className="text-[10px] text-[#D9B36C] font-semibold">السفر ونقل البضائع والكوليات</p>
                </div>
              </div>
              <button 
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 rounded-xl bg-[#1a0f00] border border-[#D4AF37]/40 text-[#E6C37A] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* User Profile Card */}
            <div className="bg-[#1a0f00]/80 p-3.5 rounded-2xl border border-[#D4AF37]/40 flex items-center justify-between">
              <div className="min-w-0">
                <p className="text-xs font-black text-white truncate">{currentUser?.name || 'مستخدم مسجل'}</p>
                <p className="text-[11px] text-[#C8B08A] font-mono mt-0.5" dir="ltr">{currentUser?.phone}</p>
                <p className="text-[10px] text-[#E6C37A] font-bold mt-1">
                  {userRole === 'owner' ? '👑 مالك المحطة (المشرف العام)' : '💼 عامل مكتب المحطة'}
                </p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/40 flex items-center justify-center">
                {userRole === 'owner' ? <Crown className="w-5 h-5 text-[#D4AF37]" /> : <User className="w-5 h-5 text-[#E6C37A]" />}
              </div>
            </div>

            {/* Live Exchange Rate Card */}
            <div className="bg-[#1a0f00]/80 p-3 rounded-2xl border border-[#D4AF37]/40 text-xs">
              <span className="text-[10px] font-bold text-[#C8B08A] block mb-1">سعر الصرف اللحظي المعتمد:</span>
              <div className="flex items-center justify-between font-mono font-bold text-[#E6C37A] bg-[#0d0700] px-3 py-2 rounded-xl border border-[#D4AF37]/30">
                <span>1 درهم مغربي (MAD)</span>
                <span>=</span>
                <span>{exchangeRate} أوقية موريتانية (MRU)</span>
              </div>
            </div>

            {/* Station Selection */}
            <div>
              <span className="text-[11px] font-bold text-[#E6C37A] block mb-2">المحطة الحالية النشطة:</span>
              <div className="grid grid-cols-2 gap-2">
                {stations.map(station => (
                  <button
                    key={station.id}
                    onClick={() => {
                      setSelectedStationId(station.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`p-2.5 rounded-xl border text-right transition ${
                      station.id === selectedStationId
                        ? 'bg-gradient-to-r from-[#F3A952] to-[#D4882A] border-[#F6C478] text-[#1a0f00] font-black'
                        : 'bg-[#1a0f00]/80 border-[#D4AF37]/35 text-[#FFF8EB] hover:border-[#D4AF37]'
                    }`}
                  >
                    <div className="text-xs font-black truncate">{station.city}</div>
                    <div className={`text-[10px] mt-0.5 ${station.id === selectedStationId ? 'text-[#1a0f00]/80 font-bold' : 'text-[#C8B08A]'}`}>
                      {station.country === 'MA' ? '🇲🇦 المغرب' : '🇲🇷 موريتانيا'}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Subscription & System Actions */}
            <div className="pt-2 border-t border-[#D4AF37]/25 space-y-2">
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#1a0f00]/80 border border-[#D4AF37]/35 text-xs">
                <span className="text-[#C8B08A]">حالة الاشتراك:</span>
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenPaywall();
                  }}
                  className="font-bold text-[#E6C37A] underline"
                >
                  {isSubscriptionExpired ? 'منتهٍ (تجديد الآن)' : `${daysUntilExpiry} يوم متبقية`}
                </button>
              </div>

              <div className="flex items-center gap-2">
                <PWAInstallButton />
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenSettings();
                  }}
                  className="flex-1 flex items-center justify-center gap-2 p-2.5 rounded-xl bg-[#1a0f00] hover:bg-[#2a1800] border border-[#D4AF37]/50 text-[#E6C37A] text-xs font-bold transition"
                >
                  <Settings className="w-4 h-4 text-[#D4AF37]" />
                  <span>الإعدادات</span>
                </button>
              </div>

              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  logout();
                }}
                className="w-full flex items-center justify-center gap-2 p-2.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 border border-rose-500/40 text-rose-300 text-xs font-bold transition mt-2"
              >
                <LogOut className="w-4 h-4" />
                <span>تسجيل الخروج من الحساب</span>
              </button>
            </div>

          </div>
        </div>
      )}
    </>
  );
};
