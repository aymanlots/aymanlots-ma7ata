import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Settings, 
  Key, 
  RotateCw, 
  Share2, 
  Copy, 
  Check, 
  Database, 
  LogOut, 
  Crown, 
  User, 
  Code2, 
  ShieldCheck, 
  Sparkles,
  Info,
  Server,
  Languages,
  Store,
  DollarSign,
  MessageCircle,
  Eye,
  Users,
  Download,
  FileSpreadsheet,
  FileJson,
  Wifi,
  WifiOff,
  Trash2,
  AlertTriangle,
  Smartphone
} from 'lucide-react';
import { saveSupabaseConfig, clearSupabaseConfig, isSupabaseConfigured } from '../lib/supabase';
import { exportService } from '../services/exportService';
import { PWAInstallButton } from './PWAInstallButton';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

interface SettingsViewProps {
  onOpenSQLModal: () => void;
  onOpenPaywall: () => void;
  onOpenPrivacyModal?: () => void;
  onOpenPlatformOwner?: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ 
  onOpenSQLModal, 
  onOpenPaywall,
  onOpenPrivacyModal,
  onOpenPlatformOwner
}) => {
  const { 
    currentUser, 
    userRole, 
    currentWorkspace,
    workspaceMembers,
    removeWorkerFromTeam,
    transactions,
    parcels,
    stations,
    renewInviteCode, 
    logout,
    subscription,
    daysUntilExpiry,
    isSubscriptionExpired,
    exchangeRate,
    setExchangeRate,
    collaborations,
    joinRequests,
    hasDemoData,
    deleteDemoData,
    showToast
  } = useApp();

  const isOnline = useOnlineStatus();

  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedWsId, setCopiedWsId] = useState(false);
  const [isRegenerating, setIsRegenerating] = useState(false);

  // Exchange rate form state
  const [rateInput, setRateInput] = useState(exchangeRate.toString());

  // Worker removal confirmation modal state
  const [workerToDelete, setWorkerToDelete] = useState<{ id: string; name: string } | null>(null);
  const [isDeletingWorker, setIsDeletingWorker] = useState(false);

  // Demo data deletion confirmation modal state
  const [showDeleteDemoConfirm, setShowDeleteDemoConfirm] = useState(false);

  const handleCopyInviteCode = () => {
    if (!currentWorkspace?.invite_code) return;
    navigator.clipboard.writeText(currentWorkspace.invite_code);
    setCopiedCode(true);
    showToast('تم نسخ رمز دعوة مساحة العمل بنجاح', 'success');
    setTimeout(() => setCopiedCode(false), 2500);
  };

  const handleCopyShortId = () => {
    if (!currentWorkspace?.short_id) return;
    navigator.clipboard.writeText(currentWorkspace.short_id);
    setCopiedWsId(true);
    showToast(`تم نسخ المعرف القصير [${currentWorkspace.short_id}] بنجاح`, 'success');
    setTimeout(() => setCopiedWsId(false), 2500);
  };

  const handleRegenerateCode = async () => {
    setIsRegenerating(true);
    try {
      const newCode = await renewInviteCode();
      showToast(`تم تجديد رمز الدعوة بنجاح: ${newCode}`, 'success');
    } catch {
      showToast('تعذر تجديد رمز الدعوة', 'error');
    } finally {
      setIsRegenerating(false);
    }
  };

  const handleUpdateExchangeRate = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseFloat(rateInput);
    if (!parsed || parsed <= 0) {
      showToast('يرجى إدخال سعر صرف صحيح أكبر من صفر', 'error');
      return;
    }
    setExchangeRate(parsed);
    showToast(`تم تحديث سعر الصرف الرسمي: 1 درهم = ${parsed} أوقية`, 'success');
  };

  const handleConfirmDeleteWorker = async () => {
    if (!workerToDelete) return;
    setIsDeletingWorker(true);
    try {
      await removeWorkerFromTeam(workerToDelete.id);
      showToast(`تم حذف الموظف [${workerToDelete.name}] من مساحة العمل بنجاح`, 'success');
      setWorkerToDelete(null);
    } catch {
      showToast('تعذر حذف الموظف', 'error');
    } finally {
      setIsDeletingWorker(false);
    }
  };

  const pendingJoinRequestsCount = (joinRequests || []).filter(r => r.status === 'pending').length;

  return (
    <div className="space-y-3.5 pb-24 text-right animate-fadeIn" dir="rtl">
      
      {/* 1. Header Card */}
      <div className="rounded-[22px] bg-[#1a0f00]/80 backdrop-blur-md border border-[#D4AF37]/55 p-4 shadow-xl space-y-2.5">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] flex items-center justify-center font-black shrink-0 shadow-md">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black text-[#F5D799]">إعدادات النظام ومساحة العمل</h2>
              <p className="text-[11px] text-[#C8B08A] font-medium">
                {currentWorkspace?.name || 'محطة الاتحادية'}
              </p>
            </div>
          </div>
        </div>

        {/* Connection status badge */}
        <div className="flex flex-wrap items-center gap-1.5">
          <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold border ${
            isOnline 
              ? 'bg-[#120a00] text-[#F5D799] border-[#D4AF37]/40' 
              : 'bg-rose-950/60 text-rose-300 border-rose-500/40 animate-pulse'
          }`}>
            {isOnline ? <Wifi className="w-3 h-3 text-[#F3A952]" /> : <WifiOff className="w-3 h-3" />}
            <span>{isOnline ? 'متصل بالإنترنت' : 'وضع غير متصل (أوفلاين)'}</span>
          </div>

          {isSupabaseConfigured() && (
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold bg-[#120a00] text-[#E6C37A] border border-[#D4AF37]/40">
              <Database className="w-3 h-3 text-[#D4AF37]" />
              <span>قاعدة بيانات سحابية</span>
            </div>
          )}
        </div>
      </div>

      {/* 2. Platform Owner Panel Launcher (Shown if userRole === 'platform_owner') */}
      {userRole === 'platform_owner' && onOpenPlatformOwner && (
        <div className="rounded-[22px] bg-[#1a0f00]/90 border-2 border-[#D4AF37]/75 p-4 shadow-2xl space-y-2.5">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] flex items-center justify-center font-black shrink-0">
              <Crown className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xs font-black text-[#F5D799]">
                لوحة تحكم مالك المنصة (Platform Owner)
              </h3>
              <p className="text-[10px] text-[#C8B08A]">
                إدارة وتفعيل اشتراكات جميع مدراء مساحات العمل
              </p>
            </div>
          </div>

          <button
            onClick={onOpenPlatformOwner}
            className="w-full py-2 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black text-xs shadow-md active:scale-95 transition"
          >
            فتح لوحة المشرف
          </button>
        </div>
      )}

      {/* 3. Who Can See My Data - Privacy and Collaboration Button Card */}
      <div 
        onClick={onOpenPrivacyModal}
        className="rounded-[22px] bg-[#1a0f00]/80 border border-[#D4AF37]/55 hover:border-[#D4AF37] p-4 shadow-xl transition cursor-pointer group active:scale-[0.99]"
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#120a00] border border-[#D4AF37]/40 text-[#F3A952] flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <h3 className="text-xs font-black text-[#F5D799]">
                  من يمكنه رؤية بياناتي؟ (التحكم بالخصوصية)
                </h3>
                {pendingJoinRequestsCount > 0 && (
                  <span className="px-2 py-0.5 text-[10px] font-black rounded-full bg-rose-600 text-white animate-pulse">
                    {pendingJoinRequestsCount} طلب معلق
                  </span>
                )}
              </div>
              <p className="text-[10px] text-[#C8B08A] mt-0.5">
                إدارة المعرف القصير، طلبات انضمام العمال، والخصوصية
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Workspace Identity & Short ID Card */}
      <div className="rounded-[22px] bg-[#1a0f00]/80 border border-[#D4AF37]/50 p-4 shadow-lg space-y-3">
        <div className="flex items-center justify-between border-b border-[#D4AF37]/25 pb-2">
          <div className="flex items-center gap-1.5">
            <Store className="w-4 h-4 text-[#F3A952]" />
            <h3 className="text-xs font-black text-[#F5D799]">معلومات وهوية مساحة العمل:</h3>
          </div>
          <span className="text-[10px] font-mono text-[#C8B08A]">
            {currentWorkspace?.id || 'ws-default'}
          </span>
        </div>

        <div className="space-y-2.5">
          {/* Unique 6-character Short ID */}
          <div className="bg-[#120a00] p-3 rounded-xl border border-[#D4AF37]/35 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-[#E6C37A]">المعرف القصير لمساحة العمل:</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#1a0f00] text-[#F5D799] font-bold border border-[#D4AF37]/30">
                للربط مع المدراء
              </span>
            </div>
            <div className="flex items-center justify-between bg-[#090500] p-2.5 rounded-xl border border-[#D4AF37]/30">
              <span className="font-mono text-sm font-black text-[#F5D799] tracking-wider">
                {currentWorkspace?.short_id || '------'}
              </span>
              <button
                onClick={handleCopyShortId}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] text-xs font-black transition active:scale-95"
              >
                {copiedWsId ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedWsId ? 'تم النسخ' : 'نسخ'}</span>
              </button>
            </div>
          </div>

          {/* Renewable Invite Code for Workers */}
          <div className="bg-[#120a00] p-3 rounded-xl border border-[#D4AF37]/35 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-[#E6C37A]">رمز دعوة العمال:</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#1a0f00] text-[#F5D799] font-bold border border-[#D4AF37]/30">
                يتطلب موافقتك
              </span>
            </div>
            <div className="flex items-center justify-between bg-[#090500] p-2.5 rounded-xl border border-[#D4AF37]/30">
              <span className="font-mono text-sm font-black text-[#E6C37A] tracking-wider">
                {currentWorkspace?.invite_code || '--------'}
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={handleCopyInviteCode}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#1a0f00] border border-[#D4AF37]/50 text-[#F5D799] text-xs font-bold transition active:scale-95"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? 'تم' : 'نسخ'}</span>
                </button>
                {userRole === 'owner' && (
                  <button
                    onClick={handleRegenerateCode}
                    disabled={isRegenerating}
                    title="تجديد الرمز عشوائياً"
                    className="p-1.5 rounded-lg bg-[#1a0f00] border border-[#D4AF37]/40 text-[#E6C37A] transition active:scale-95 disabled:opacity-50"
                  >
                    <RotateCw className={`w-3.5 h-3.5 ${isRegenerating ? 'animate-spin' : ''}`} />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 5. Data Export (JSON & CSV) */}
      <div className="rounded-[22px] bg-[#1a0f00]/80 border border-[#D4AF37]/50 p-4 shadow-lg space-y-3">
        <div className="border-b border-[#D4AF37]/25 pb-2">
          <h3 className="text-xs font-black text-[#F5D799] flex items-center gap-1.5">
            <Download className="w-4 h-4 text-[#F3A952]" />
            <span>تصدير ونسخ بيانات مساحة العمل (JSON و CSV):</span>
          </h3>
        </div>

        <div className="grid grid-cols-1 gap-2">
          {/* Export Cash Transactions CSV */}
          <button
            onClick={() => {
              if (transactions.length === 0) {
                showToast('لا توجد معاملات نقدية لتصديرها حالياً', 'info');
                return;
              }
              exportService.exportTransactionsToCSV(transactions, currentWorkspace?.name || 'محطة الاتحادية');
              showToast('تم تصدير سجلات الصندوق والمعاملات بتنسيق CSV', 'success');
            }}
            className="flex items-center gap-3 p-3 rounded-xl bg-[#120a00] hover:bg-[#2a1800] border border-[#D4AF37]/40 transition text-right active:scale-95"
          >
            <div className="w-9 h-9 rounded-xl bg-[#1a0f00] border border-[#D4AF37]/40 text-[#F3A952] flex items-center justify-center shrink-0">
              <FileSpreadsheet className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-[#FFF8EB] text-xs block">سجلات الصندوق (CSV)</span>
              <span className="text-[10px] text-[#C8B08A]">متوافق مع برنامج Excel</span>
            </div>
          </button>

          {/* Export Parcels CSV */}
          <button
            onClick={() => {
              if (parcels.length === 0) {
                showToast('لا توجد سجلات كوليات لتصديرها حالياً', 'info');
                return;
              }
              exportService.exportParcelsToCSV(parcels, currentWorkspace?.name || 'محطة الاتحادية');
              showToast('تم تصدير سجلات الكوليات والشحنات بتنسيق CSV', 'success');
            }}
            className="flex items-center gap-3 p-3 rounded-xl bg-[#120a00] hover:bg-[#2a1800] border border-[#D4AF37]/40 transition text-right active:scale-95"
          >
            <div className="w-9 h-9 rounded-xl bg-[#1a0f00] border border-[#D4AF37]/40 text-[#F5D799] flex items-center justify-center shrink-0">
              <FileSpreadsheet className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-[#FFF8EB] text-xs block">سجلات الكوليات (CSV)</span>
              <span className="text-[10px] text-[#C8B08A]">شامل المبالغ والمستلمين</span>
            </div>
          </button>

          {/* Export Full Workspace Backup JSON */}
          <button
            onClick={() => {
              if (!currentWorkspace) {
                showToast('تعذر تصدير النسخة الاحتياطية', 'error');
                return;
              }
              exportService.exportWorkspaceBackupJSON(currentWorkspace, transactions, parcels);
              showToast('تم تصدير النسخة الاحتياطية الشاملة بتنسيق JSON', 'success');
            }}
            className="flex items-center gap-3 p-3 rounded-xl bg-[#120a00] hover:bg-[#2a1800] border border-[#D4AF37]/40 transition text-right active:scale-95"
          >
            <div className="w-9 h-9 rounded-xl bg-[#1a0f00] border border-[#D4AF37]/40 text-[#E6C37A] flex items-center justify-center shrink-0">
              <FileJson className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-[#FFF8EB] text-xs block">نسخة احتياطية كاملة (JSON)</span>
              <span className="text-[10px] text-[#C8B08A]">حفظ كامل لبيانات مساحة العمل</span>
            </div>
          </button>
        </div>
      </div>

      {/* 6. Language & Currency Exchange Rate */}
      <div className="rounded-[22px] bg-[#1a0f00]/80 border border-[#D4AF37]/50 p-4 shadow-lg space-y-3">
        <h3 className="text-xs font-black text-[#F5D799] flex items-center gap-1.5">
          <Languages className="w-4 h-4 text-[#F3A952]" />
          <span>اللغة وسعر الصرف المعتمد:</span>
        </h3>

        <div className="space-y-2.5">
          <div className="bg-[#120a00] p-3 rounded-xl border border-[#D4AF37]/35 space-y-1.5">
            <span className="text-[11px] font-bold text-[#C8B08A] block">
              لغة واجهة التطبيق:
            </span>
            <div className="flex items-center gap-2 p-2 rounded-xl bg-[#1a0f00] border border-[#D4AF37]/35 text-xs font-bold text-[#F5D799]">
              <span className="w-2 h-2 rounded-full bg-[#F3A952] shrink-0"></span>
              <span>العربية الفصحى (اللغة الرسمية المعتمدة)</span>
            </div>
          </div>

          <form onSubmit={handleUpdateExchangeRate} className="bg-[#120a00] p-3 rounded-xl border border-[#D4AF37]/35 space-y-2">
            <span className="text-[11px] font-bold text-[#C8B08A] block">
              سعر الصرف: 1 درهم مغربي (MAD) كم يساوي بالأوقية (MRU)؟
            </span>
            <div className="flex gap-2">
              <input
                type="number"
                step="0.01"
                min="0.1"
                required
                value={rateInput}
                onChange={(e) => setRateInput(e.target.value)}
                className="flex-1 bg-[#090500] border border-[#D4AF37]/40 rounded-xl px-3 py-1.5 text-xs text-white font-mono font-bold focus:outline-none focus:border-[#D4AF37]"
              />
              <button
                type="submit"
                className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] text-xs font-black transition active:scale-95"
              >
                تحديث
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* 7. PWA Install Card */}
      <div className="rounded-[22px] bg-[#1a0f00]/80 border border-[#D4AF37]/50 p-4 shadow-lg space-y-2.5">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#120a00] border border-[#D4AF37]/40 text-[#F3A952] flex items-center justify-center shrink-0">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xs font-black text-[#F5D799]">تثبيت التطبيق على الشاشة الرئيسية (PWA)</h3>
            <p className="text-[10px] text-[#C8B08A]">
              يعمل كتطبيق هاتف أصلي وسريع بدون إنترنت
            </p>
          </div>
        </div>

        <div>
          <PWAInstallButton />
        </div>
      </div>

      {/* 8. SQL Schema & Database Connection */}
      <div className="rounded-[22px] bg-[#1a0f00]/80 border border-[#D4AF37]/50 p-4 shadow-lg">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#120a00] border border-[#D4AF37]/40 text-[#F3A952] flex items-center justify-center shrink-0">
              <Code2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xs font-black text-[#F5D799]">مخطط قاعدة البيانات (schema.sql)</h3>
              <p className="text-[10px] text-[#C8B08A]">
                RLS 100% وعزل العمال بالمحطات
              </p>
            </div>
          </div>
          <button
            onClick={onOpenSQLModal}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black text-xs shrink-0 shadow-md active:scale-95 transition"
          >
            عرض الكود
          </button>
        </div>
      </div>

      {/* 9. Team Members & Permissions Management */}
      <div className="rounded-[22px] bg-[#1a0f00]/80 border border-[#D4AF37]/50 p-4 shadow-lg space-y-3">
        <div className="border-b border-[#D4AF37]/25 pb-2">
          <h3 className="text-xs font-black text-[#F5D799] flex items-center gap-1.5">
            <User className="w-4 h-4 text-[#F3A952]" />
            <span>فريق العمل المعتمد ({workspaceMembers.length} أعضاء):</span>
          </h3>
        </div>

        {workspaceMembers.length === 0 ? (
          <div className="text-center py-5 text-[#C8B08A] text-xs bg-[#120a00] rounded-xl border border-[#D4AF37]/30">
            لا يوجد أعضاء آخرين في مساحة العمل حالياً.
          </div>
        ) : (
          <div className="space-y-2">
            {workspaceMembers.map(member => (
              <div 
                key={member.user_id}
                className="bg-[#120a00] p-3 rounded-xl border border-[#D4AF37]/35 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-[#1a0f00] border border-[#D4AF37]/35 flex items-center justify-center font-bold text-[#F5D799]">
                    {member.role === 'admin' || member.role === 'owner' ? <Crown className="w-4 h-4 text-[#F3A952]" /> : <User className="w-4 h-4 text-[#E6C37A]" />}
                  </div>
                  <div>
                    <span className="font-bold text-[#FFF8EB] block">{member.profile?.name || 'عضو الفريق'}</span>
                    <div className="flex items-center gap-2 text-[10px] text-[#C8B08A] font-mono mt-0.5">
                      <span dir="ltr">{member.profile?.phone}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-[#1a0f00] text-[#E6C37A] border border-[#D4AF37]/35">
                    {member.role === 'admin' || member.role === 'owner' ? '👑 مدير' : '💼 عامل'}
                  </span>

                  {userRole === 'owner' && member.user_id !== currentUser?.id && (
                    <button
                      onClick={() => setWorkerToDelete({ id: member.user_id, name: member.profile?.name || 'الموظف' })}
                      className="p-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-500/30 transition"
                      title="حذف من مساحة العمل"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 10. Delete Demo Data (Admin Only) */}
      {(userRole === 'owner' || userRole === 'platform_owner') && (
        <div className="rounded-[22px] bg-[#1a0f00]/80 border border-rose-500/40 p-4 shadow-lg space-y-2.5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-400 flex items-center justify-center shrink-0">
              <Trash2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-black text-white">إدارة البيانات التجريبية</h3>
              <p className="text-[10px] text-[#C8B08A] mt-0.5">
                حذف كافة السجلات التجريبية دون المساس بالبيانات الحقيقية
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setShowDeleteDemoConfirm(true)}
            className="w-full flex items-center justify-center gap-2 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs shadow-md active:scale-95 transition"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>حذف البيانات التجريبية</span>
          </button>
        </div>
      )}

      {/* 11. Logout */}
      <div className="text-center pt-1">
        <button
          onClick={logout}
          className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-[#1a0f00]/90 hover:bg-rose-950/50 border border-[#D4AF37]/45 text-xs font-bold text-rose-300 transition"
        >
          <LogOut className="w-4 h-4" />
          <span>تسجيل الخروج من الحساب</span>
        </button>
      </div>

      {/* Confirmation Dialog: Delete Demo Data */}
      {showDeleteDemoConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-[360px] rounded-[24px] bg-[#140b00] border border-rose-500/50 p-5 shadow-2xl text-right space-y-3.5">
            <div className="flex items-center gap-2.5 text-rose-400">
              <div className="w-9 h-9 rounded-xl bg-rose-950/60 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">تأكيد حذف البيانات التجريبية</h3>
            </div>

            <p className="text-xs text-[#C8B08A] leading-relaxed">
              هل أنت متأكد من رغبتك في حذف <strong className="text-white">جميع البيانات التجريبية</strong>؟ سيتم حذف السجلات التجريبية فقط ولن يتم حذف أي سجل حقيقي.
            </p>

            <div className="flex justify-end gap-2 pt-2 border-t border-[#D4AF37]/25">
              <button
                type="button"
                onClick={() => setShowDeleteDemoConfirm(false)}
                className="px-4 py-2 rounded-xl bg-[#1a0f00] border border-[#D4AF37]/40 text-[#E6C37A] text-xs font-bold"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteDemoData();
                  setShowDeleteDemoConfirm(false);
                }}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md"
              >
                تأكيد الحذف
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Dialog: Delete Worker */}
      {workerToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-[360px] rounded-[24px] bg-[#140b00] border border-rose-500/50 p-5 shadow-2xl text-right space-y-3.5">
            <div className="flex items-center gap-2.5 text-rose-400">
              <div className="w-9 h-9 rounded-xl bg-rose-950/60 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">تأكيد حذف الموظف</h3>
            </div>

            <p className="text-xs text-[#C8B08A] leading-relaxed">
              هل أنت متأكد من رغبتك في حذف الموظف <strong className="text-white">[{workerToDelete.name}]</strong> من مساحة العمل؟
            </p>

            <div className="flex justify-end gap-2 pt-2 border-t border-[#D4AF37]/25">
              <button
                type="button"
                onClick={() => setWorkerToDelete(null)}
                disabled={isDeletingWorker}
                className="px-4 py-2 rounded-xl bg-[#1a0f00] border border-[#D4AF37]/40 text-[#E6C37A] text-xs font-bold"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteWorker}
                disabled={isDeletingWorker}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md disabled:opacity-50"
              >
                {isDeletingWorker ? 'جاري الحذف...' : 'تأكيد الحذف'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
