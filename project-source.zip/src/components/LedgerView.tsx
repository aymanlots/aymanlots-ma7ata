import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Transaction, TransactionType } from '../types/database';
import { DailyFinancialReportModal } from './DailyFinancialReportModal';
import { TransactionDetailModal } from './TransactionDetailModal';
import { 
  FileText, 
  Download, 
  Search, 
  Filter, 
  Store, 
  Phone, 
  Eye, 
  Edit3, 
  Ban, 
  History, 
  CheckCircle2, 
  AlertTriangle,
  X,
  FileSpreadsheet,
  Coins,
  ArrowDownLeft,
  ArrowUpRight,
  Calendar,
  ArrowRightLeft,
  PlusCircle,
  Info,
  Clock,
  User
} from 'lucide-react';

interface LedgerViewProps {
  onOpenNewVoucher: () => void;
}

export const LedgerView: React.FC<LedgerViewProps> = ({ onOpenNewVoucher }) => {
  const { 
    transactions, 
    stations, 
    teamMembers, 
    userRole, 
    stationBalances,
    currencies,
    selectedStationId,
    updateTransaction, 
    cancelTransaction, 
    auditLogs,
    currentTeam,
    exchangeRate,
    convertCurrency,
    showToast 
  } = useApp();

  // Filters
  const [filterStation, setFilterStation] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterDate, setFilterDate] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals
  const [showDailyReport, setShowDailyReport] = useState(false);
  const [showConverter, setShowConverter] = useState(false);
  const [calcAmount, setCalcAmount] = useState('1000');
  const [calcFrom, setCalcFrom] = useState<'MAD' | 'MRU'>('MAD');

  const [detailTx, setDetailTx] = useState<Transaction | null>(null);
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);
  const [editAmount, setEditAmount] = useState<string>('');
  const [editReason, setEditReason] = useState<string>('');
  const [editPhone, setEditPhone] = useState<string>('');
  const [cancellingTx, setCancellingTx] = useState<Transaction | null>(null);
  const [cancelReason, setCancelReason] = useState<string>('');
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);
  const [auditTxId, setAuditTxId] = useState<string | null>(null);

  // Active Station for Quick Balance Card
  const currentStation = stations.find(s => s.id === (filterStation !== 'all' ? filterStation : selectedStationId)) || stations[0];
  const stationBals = currentStation ? (stationBalances[currentStation.id] || {}) : {};

  // Filtered transactions
  const filteredTransactions = useMemo(() => {
    return transactions.filter(tx => {
      // Station filter
      if (filterStation !== 'all' && tx.station_id !== filterStation) return false;

      // Type filter
      if (filterType !== 'all') {
        if (filterType === 'inflow') {
          const isIn = tx.type === 'cash_in' || tx.type === 'parcel_shipping_fee' || tx.type === 'parcel_cod_collection';
          if (!isIn) return false;
        } else if (filterType === 'outflow') {
          const isOut = tx.type === 'cash_out' || tx.type === 'goods_payment' || tx.type === 'parcel_cod_payout';
          if (!isOut) return false;
        } else if (tx.type !== filterType) {
          return false;
        }
      }

      // Date filter
      if (filterDate === 'today') {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (new Date(tx.created_at) < today) return false;
      } else if (filterDate === 'week') {
        const weekAgo = new Date(Date.now() - 7 * 86400000);
        if (new Date(tx.created_at) < weekAgo) return false;
      }

      // Search query (phone, reason, note, creator)
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchPhone = tx.phone_number?.toLowerCase().includes(q);
        const matchReason = tx.reason?.toLowerCase().includes(q);
        const matchNote = tx.note?.toLowerCase().includes(q);
        const matchCreator = tx.creator_name?.toLowerCase().includes(q);
        if (!matchPhone && !matchReason && !matchNote && !matchCreator) return false;
      }

      return true;
    });
  }, [transactions, filterStation, filterType, filterDate, searchQuery]);

  // Export to CSV with UTF-8 BOM
  const exportToCSV = () => {
    if (filteredTransactions.length === 0) {
      showToast('لا توجد بيانات لتصديرها', 'error');
      return;
    }

    const headers = [
      'رقم السند',
      'التاريخ والوقت',
      'المحطة',
      'نوع العملية',
      'المبلغ',
      'العملة',
      'رقم الهاتف',
      'السبب والبيان',
      'الموظف المنشئ',
      'الحالة',
      'ملاحظات'
    ];

    const rows = filteredTransactions.map(tx => [
      tx.id,
      new Date(tx.created_at).toLocaleString('ar-MA'),
      tx.station_name || tx.station_id,
      tx.type,
      tx.amount,
      tx.currency,
      tx.phone_number || '',
      `"${(tx.reason || '').replace(/"/g, '""')}"`,
      tx.creator_name || '',
      tx.status === 'confirmed' ? 'معتمد' : tx.status === 'cancelled' ? 'ملغى' : 'معلق',
      `"${(tx.note || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `كشف_حساب_محطة_الاتحادية_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('تم تصدير جدول البيانات بنجاح', 'success');
  };

  // Open Edit Modal
  const startEdit = (tx: Transaction) => {
    setEditingTx(tx);
    setEditAmount(tx.amount.toString());
    setEditReason(tx.reason || '');
    setEditPhone(tx.phone_number || '');
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTx) return;

    const newAmount = parseFloat(editAmount);
    if (!newAmount || newAmount <= 0) {
      showToast('المبلغ غير صحيح، يرجى إدخال قيمة أكبر من صفر', 'error');
      return;
    }

    if (!editReason.trim()) {
      showToast('يرجى كتابة سبب التعديل للتوثيق في سجل الرقابة المحاسبية', 'error');
      return;
    }

    const res = await updateTransaction(editingTx.id, {
      amount: newAmount,
      reason: editReason.trim(),
      phone_number: editPhone || null,
      note: `${editingTx.note || ''} [معدل]`,
    }, editReason.trim());

    if (res.success) {
      showToast('تم حفظ تعديل السند المالي بنجاح', 'success');
      setEditingTx(null);
    }
  };

  const handleConfirmCancel = async () => {
    if (!cancellingTx) return;

    if (!cancelReason.trim()) {
      showToast('يرجى كتابة سبب الإلغاء للتوثيق في سجل الرقابة المحاسبية', 'error');
      return;
    }

    const res = await cancelTransaction(cancellingTx.id, cancelReason.trim());
    if (res.success) {
      showToast('تم إلغاء السند المالي وتحديث الرصيد', 'success');
      setCancellingTx(null);
      setCancelReason('');
    }
  };

  const getTransactionTypeLabel = (type: TransactionType) => {
    switch (type) {
      case 'cash_in':
        return { label: '📥 إيداع نقدي', color: 'bg-[#120a00] text-[#F5D799] border-[#D4AF37]/40' };
      case 'parcel_shipping_fee':
        return { label: '📦 قبض أجرة شحن', color: 'bg-[#120a00] text-[#F5D799] border-[#D4AF37]/40' };
      case 'parcel_cod_collection':
        return { label: '💰 قبض تحصيل (COD)', color: 'bg-[#2a1800] text-[#F3A952] border-[#D4AF37]/50' };
      case 'cash_out':
        return { label: '📤 صرف نقدي / مصاريف', color: 'bg-rose-950/60 text-rose-300 border-rose-500/40' };
      case 'goods_payment':
        return { label: '🤝 سداد بضاعة للمرسل', color: 'bg-[#2a1800] text-[#E6C37A] border-[#D4AF37]/50' };
      case 'parcel_cod_payout':
        return { label: '📤 تسليم مبلغ COD للتاجر', color: 'bg-rose-950/60 text-rose-300 border-rose-500/40' };
      default:
        return { label: type, color: 'bg-[#120a00] text-[#C8B08A]' };
    }
  };

  return (
    <div className="space-y-3.5 pb-24 text-right">
      
      {/* Top Banner & Action Controls */}
      <div className="bg-[#1a0f00]/80 backdrop-blur-md border border-[#D4AF37]/55 rounded-[22px] p-4 shadow-xl space-y-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="p-2 rounded-xl bg-[#120a00] text-[#F3A952] border border-[#D4AF37]/40">
              <Coins className="w-4 h-4" />
            </div>
            <h2 className="text-sm font-black text-[#F5D799]">دفتر الصناديق والقيود المالية</h2>
          </div>
          <p className="text-[11px] text-[#C8B08A]">
            متابعة الصناديق النقدية بالدرهم المغربي (MAD) والأوقية الموريتانية (MRU) لحظياً
          </p>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setShowDailyReport(true)}
            className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-[#120a00] hover:bg-[#2a1800] border border-[#D4AF37]/45 text-[#F5D799] text-xs font-bold transition active:scale-95"
          >
            <Calendar className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>التقرير اليومي</span>
          </button>

          <button
            onClick={() => setShowConverter(!showConverter)}
            className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-[#120a00] hover:bg-[#2a1800] border border-[#D4AF37]/45 text-[#E6C37A] text-xs font-bold transition active:scale-95"
          >
            <ArrowRightLeft className="w-3.5 h-3.5 text-[#F3A952]" />
            <span>محوّل العملات</span>
          </button>

          <button
            onClick={onOpenNewVoucher}
            className="col-span-2 flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-gradient-to-r from-[#F5B05B] via-[#E5953E] to-[#D4882A] hover:brightness-110 text-[#1a0f00] text-xs font-black transition shadow-lg shadow-[#E5953E]/25 border border-[#F8C885] active:scale-95"
          >
            <PlusCircle className="w-4 h-4 stroke-[2.5]" />
            <span>سند مالي جديد</span>
          </button>
        </div>
      </div>

      {/* Live Currency Converter Widget (Collapsible) */}
      {showConverter && (
        <div className="bg-[#1a0f00]/80 border border-[#D4AF37]/55 rounded-[22px] p-3.5 shadow-xl animate-fadeIn space-y-2.5">
          <div className="flex items-center justify-between border-b border-[#D4AF37]/25 pb-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-[#F5D799]">
              <ArrowRightLeft className="w-3.5 h-3.5 text-[#F3A952]" />
              <span>محوّل العملات الميداني</span>
            </div>
            <span className="text-[10px] font-mono text-[#E6C37A]">
              1 MAD = {exchangeRate} MRU
            </span>
          </div>

          <div className="space-y-2.5 text-xs">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-[#C8B08A] block mb-1">المبلغ:</label>
                <input
                  type="number"
                  value={calcAmount}
                  onChange={(e) => setCalcAmount(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-1.5 text-white font-mono font-bold"
                />
              </div>

              <div>
                <label className="text-[10px] text-[#C8B08A] block mb-1">من العملة:</label>
                <select
                  value={calcFrom}
                  onChange={(e) => setCalcFrom(e.target.value as 'MAD' | 'MRU')}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-2.5 py-1.5 text-[#FFF8EB] font-bold"
                >
                  <option value="MAD">درهم (MAD)</option>
                  <option value="MRU">أوقية (MRU)</option>
                </select>
              </div>
            </div>

            <div className="bg-[#120a00] p-2.5 rounded-xl border border-[#D4AF37]/35 text-center">
              <span className="text-[10px] text-[#C8B08A] block">المبلغ المقابل بالتقريب:</span>
              <span className="text-base font-black font-mono text-[#F5D799]">
                {convertCurrency(parseFloat(calcAmount) || 0, calcFrom, calcFrom === 'MAD' ? 'MRU' : 'MAD')} {calcFrom === 'MAD' ? 'MRU' : 'MAD'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Dual Currency Live Balance Display for Selected Station */}
      <div className="grid grid-cols-1 gap-2.5">
        
        {/* MAD Box */}
        <div className="bg-[#1a0f00]/80 border border-[#D4AF37]/50 rounded-[22px] p-3.5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-[#120a00] border border-[#D4AF37]/40 text-[#F5D799] flex items-center justify-center font-bold text-xs">
                🇲🇦
              </div>
              <div>
                <h3 className="text-xs font-black text-[#FFF8EB]">صندوق الدرهم المغربي (MAD)</h3>
                <p className="text-[10px] text-[#C8B08A]">{currentStation?.name}</p>
              </div>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#120a00] text-[#E6C37A] font-bold border border-[#D4AF37]/35">
              صندوق رئيسي
            </span>
          </div>

          <div className="flex items-baseline justify-between mt-1">
            <span className="text-xs text-[#C8B08A]">الرصيد الصافي المتاح:</span>
            <div className={`text-xl font-black font-mono ${
              (stationBals['MAD'] || 0) < 0 ? 'text-rose-400' : 'text-[#F5D799]'
            }`}>
              {(stationBals['MAD'] || 0).toLocaleString()} <span className="text-xs font-sans font-normal text-[#C8B08A]">درهم</span>
            </div>
          </div>
        </div>

        {/* MRU Box */}
        <div className="bg-[#1a0f00]/80 border border-[#D4AF37]/50 rounded-[22px] p-3.5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-[#120a00] border border-[#D4AF37]/40 text-[#F5D799] flex items-center justify-center font-bold text-xs">
                🇲🇷
              </div>
              <div>
                <h3 className="text-xs font-black text-[#FFF8EB]">صندوق الأوقية الموريتانية (MRU)</h3>
                <p className="text-[10px] text-[#C8B08A]">{currentStation?.name}</p>
              </div>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#120a00] text-[#E6C37A] font-bold border border-[#D4AF37]/35">
              صندوق رئيسي
            </span>
          </div>

          <div className="flex items-baseline justify-between mt-1">
            <span className="text-xs text-[#C8B08A]">الرصيد الصافي المتاح:</span>
            <div className={`text-xl font-black font-mono ${
              (stationBals['MRU'] || 0) < 0 ? 'text-rose-400' : 'text-[#F5D799]'
            }`}>
              {(stationBals['MRU'] || 0).toLocaleString()} <span className="text-xs font-sans font-normal text-[#C8B08A]">أوقية</span>
            </div>
          </div>
        </div>

      </div>

      {/* Filter and Search Bar */}
      <div className="bg-[#1a0f00]/80 p-3.5 rounded-[22px] border border-[#D4AF37]/50 space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-[#F5D799] flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-[#F3A952]" />
            <span>فلترة وبحث ({filteredTransactions.length} سند):</span>
          </span>

          {userRole === 'owner' && (
            <button
              onClick={exportToCSV}
              className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-[#120a00] hover:bg-[#2a1800] border border-[#D4AF37]/40 text-[#E6C37A] text-[11px] font-bold transition"
            >
              <Download className="w-3 h-3 text-[#D4AF37]" />
              <span>تصدير CSV</span>
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          {/* Search */}
          <div className="col-span-2">
            <input
              type="text"
              placeholder="بحث بالهاتف أو السبب..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-xs text-white placeholder-[#A68966] focus:outline-none focus:border-[#D4AF37]"
            />
          </div>

          {/* Station */}
          <select
            value={filterStation}
            onChange={e => setFilterStation(e.target.value)}
            className="bg-[#120a00] border border-[#D4AF37]/35 rounded-xl px-2.5 py-1.5 text-xs text-[#E6C37A] focus:outline-none focus:border-[#D4AF37] font-bold"
          >
            <option value="all">كافة المحطات</option>
            {stations.map(st => (
              <option key={st.id} value={st.id}>{st.name}</option>
            ))}
          </select>

          {/* Type */}
          <select
            value={filterType}
            onChange={e => setFilterType(e.target.value)}
            className="bg-[#120a00] border border-[#D4AF37]/35 rounded-xl px-2.5 py-1.5 text-xs text-[#E6C37A] focus:outline-none focus:border-[#D4AF37] font-bold"
          >
            <option value="all">كافة العمليات</option>
            <option value="inflow">📥 المقبوضات</option>
            <option value="outflow">📤 المصروفات</option>
            <option value="cash_in">إيداع نقدي</option>
            <option value="parcel_shipping_fee">أجرة شحن كولي</option>
            <option value="parcel_cod_collection">تحصيل COD</option>
            <option value="cash_out">تسليم نقدي</option>
            <option value="goods_payment">سداد بضاعة</option>
          </select>

          {/* Date */}
          <select
            value={filterDate}
            onChange={e => setFilterDate(e.target.value)}
            className="col-span-2 bg-[#120a00] border border-[#D4AF37]/35 rounded-xl px-2.5 py-1.5 text-xs text-[#E6C37A] focus:outline-none focus:border-[#D4AF37] font-bold"
          >
            <option value="all">كل التواريخ</option>
            <option value="today">اليوم فقط</option>
            <option value="week">آخر 7 أيام</option>
          </select>
        </div>
      </div>

      {/* Transactions List */}
      <div className="space-y-2.5">
        {filteredTransactions.length === 0 ? (
          <div className="text-center py-8 bg-[#1a0f00]/80 rounded-[22px] border border-dashed border-[#D4AF37]/40 p-5">
            <FileText className="w-8 h-8 text-[#D4AF37] mx-auto mb-2" />
            <p className="text-xs font-bold text-[#F5D799]">لا توجد سندات تطابق الفلترة المحددة</p>
            <p className="text-[11px] text-[#C8B08A] mt-1">جرّب تغيير خيارات البحث أو قم بتسجيل سند جديد</p>
          </div>
        ) : (
          filteredTransactions.map(tx => {
            const isCancelled = tx.status === 'cancelled';
            const isInflow = tx.type === 'cash_in' || tx.type === 'parcel_shipping_fee' || tx.type === 'parcel_cod_collection';
            const badge = getTransactionTypeLabel(tx.type);

            return (
              <div
                key={tx.id}
                className={`rounded-[22px] border p-3.5 transition ${
                  isCancelled
                    ? 'bg-[#1a0f00]/45 border-rose-500/40 opacity-75'
                    : 'bg-[#1a0f00]/80 border-[#D4AF37]/50 hover:border-[#D4AF37]'
                }`}
              >
                {/* Header Row */}
                <div className="flex flex-wrap items-center justify-between pb-2 border-b border-[#D4AF37]/25 text-xs gap-1.5">
                  <div className="flex items-center gap-1.5">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${badge.color}`}>
                      {badge.label}
                    </span>
                    <span className="text-[#E6C37A] font-bold text-[11px]">
                      {tx.station_name}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {isCancelled && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-950/60 text-rose-300 font-bold border border-rose-500/40">
                        ملغى
                      </span>
                    )}
                    <span className="text-[10px] text-[#C8B08A] font-mono flex items-center gap-1" dir="ltr">
                      <Clock className="w-3 h-3 text-[#D4AF37]" />
                      <span>{new Date(tx.created_at).toLocaleDateString('ar-MA')}</span>
                    </span>
                  </div>
                </div>

                {/* Amount & Reason */}
                <div className="flex items-center justify-between py-2">
                  <div className="min-w-0 pr-1">
                    <div className="text-xs font-bold text-[#FFF8EB] mb-0.5">
                      {tx.reason || 'بدون بيان محدد'}
                    </div>
                    {tx.phone_number && (
                      <div className="text-[11px] text-[#C8B08A] flex items-center gap-1 font-mono" dir="ltr">
                        <Phone className="w-3 h-3 text-[#D4AF37]" />
                        <span>{tx.phone_number}</span>
                      </div>
                    )}
                    {tx.note && (
                      <p className="text-[10px] text-[#C8B08A] mt-0.5 italic">
                        "{tx.note}"
                      </p>
                    )}
                  </div>

                  <div className="text-left font-mono shrink-0 pl-2">
                    <div className={`text-base font-black ${
                      isCancelled
                        ? 'line-through text-[#A68966]'
                        : isInflow
                        ? 'text-[#F5D799]'
                        : 'text-rose-400'
                    }`}>
                      {isInflow ? '+' : '-'}{tx.amount} <span className="text-[10px] font-sans font-normal text-[#C8B08A]">{tx.currency}</span>
                    </div>
                  </div>
                </div>

                {/* Edit Notice Banner if Edited */}
                {tx.edit_history && tx.edit_history.length > 0 && (
                  <div className="my-1.5 p-2 rounded-xl bg-[#2a1800] border border-[#D4AF37]/40 text-[10px] text-[#F5D799] space-y-0.5">
                    <div className="flex items-center justify-between">
                      <span className="font-bold flex items-center gap-1">
                        <Edit3 className="w-3 h-3 text-[#F3A952]" />
                        <span>آخر تعديل: <strong>{tx.edit_history[tx.edit_history.length - 1].edited_by_name}</strong></span>
                      </span>
                    </div>
                    <p className="text-[#C8B08A] text-[10px]">
                      <strong className="text-[#F3A952]">السبب:</strong> {tx.edit_history[tx.edit_history.length - 1].reason}
                    </p>
                  </div>
                )}

                {/* Cancellation Notice Banner if Cancelled */}
                {isCancelled && (
                  <div className="my-1.5 p-2 rounded-xl bg-rose-950/60 border border-rose-500/40 text-[10px] text-rose-300 space-y-0.5">
                    <div className="flex items-center justify-between">
                      <span className="font-bold flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3 text-rose-400" />
                        <span>أُلغي بواسطة: <strong>{tx.cancelled_by_name || 'المدير العام'}</strong></span>
                      </span>
                    </div>
                    <p className="text-rose-200 text-[10px]">
                      <strong className="text-rose-400">سبب الإلغاء:</strong> {tx.cancel_reason || 'تم إرجاع المبلغ للصندوق'}
                    </p>
                  </div>
                )}

                {/* Footer: Creator & Actions */}
                <div className="flex flex-wrap items-center justify-between pt-2 border-t border-[#D4AF37]/25 text-[11px] text-[#C8B08A] gap-2">
                  <div className="flex items-center gap-1">
                    <User className="w-3 h-3 text-[#F3A952]" />
                    <span>سجّله: <strong className="text-[#FFF8EB]">{tx.creator_name || 'موظف المحطة'}</strong></span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {/* View Details Button */}
                    <button
                      onClick={() => setDetailTx(tx)}
                      className="flex items-center gap-1 text-[#F5D799] font-bold text-[11px] px-2.5 py-1 rounded-xl bg-[#120a00] hover:bg-[#2a1800] border border-[#D4AF37]/40 transition"
                      title="عرض التفاصيل الكاملة وسجل الرقابة"
                    >
                      <FileText className="w-3 h-3 text-[#F3A952]" />
                      <span>تفاصيل السند</span>
                    </button>

                    {tx.photo_url && (
                      <button
                        onClick={() => setSelectedPhoto(tx.photo_url || null)}
                        className="flex items-center gap-1 text-[#E6C37A] font-bold text-[11px]"
                      >
                        <Eye className="w-3 h-3" />
                        <span>الوصل</span>
                      </button>
                    )}

                    {userRole === 'owner' && !isCancelled && (
                      <>
                        <button
                          onClick={() => startEdit(tx)}
                          className="p-1 rounded-lg text-[#C8B08A] hover:text-[#F3A952] bg-[#120a00] border border-[#D4AF37]/30 transition"
                          title="تعديل السند"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setCancellingTx(tx)}
                          className="p-1 rounded-lg text-[#C8B08A] hover:text-rose-400 bg-[#120a00] border border-[#D4AF37]/30 transition"
                          title="إلغاء السند"
                        >
                          <Ban className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Edit Modal */}
      {editingTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md">
          <div className="w-full max-w-[370px] bg-[#140b00] border border-[#D4AF37]/65 rounded-[24px] p-5 shadow-2xl space-y-3.5 text-right">
            <div className="flex items-center justify-between border-b border-[#D4AF37]/25 pb-2">
              <h3 className="text-sm font-bold text-[#F5D799]">تعديل بيانات السند</h3>
              <button onClick={() => setEditingTx(null)} className="text-[#C8B08A] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3 text-xs">
              <div>
                <label className="text-[#E6C37A] font-bold block mb-1">المبلغ المعدل:</label>
                <input
                  type="number"
                  required
                  value={editAmount}
                  onChange={(e) => setEditAmount(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white font-mono font-bold"
                />
              </div>

              <div>
                <label className="text-[#E6C37A] font-bold block mb-1">البيان / تفاصيل السند:</label>
                <input
                  type="text"
                  value={editReason}
                  onChange={(e) => setEditReason(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-[#E6C37A] font-bold block mb-1">سبب التعديل المكتوب (إلزامي للرقابة):</label>
                <input
                  type="text"
                  required
                  placeholder="اكتب سبب تعديل هذا السند..."
                  value={editReason}
                  onChange={(e) => setEditReason(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/60 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-[#E6C37A] font-bold block mb-1">رقم الهاتف:</label>
                <input
                  type="tel"
                  value={editPhone}
                  onChange={(e) => setEditPhone(e.target.value)}
                  className="w-full bg-[#120a00] border border-[#D4AF37]/40 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingTx(null)}
                  className="px-4 py-2 rounded-xl bg-[#1a0f00] border border-[#D4AF37]/40 text-[#E6C37A] font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#F5B05B] to-[#D4882A] text-[#1a0f00] font-black shadow-md"
                >
                  حفظ التعديل
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Cancel Modal */}
      {cancellingTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md">
          <div className="w-full max-w-[370px] bg-[#140b00] border border-rose-500/45 rounded-[24px] p-5 shadow-2xl space-y-3.5 text-right">
            <div className="flex items-center justify-between border-b border-[#D4AF37]/25 pb-2">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-rose-400" />
                <span>تأكيد إلغاء السند المالي</span>
              </h3>
              <button onClick={() => setCancellingTx(null)} className="text-[#C8B08A] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-[#C8B08A]">
              هل أنت متأكد من إلغاء هذا السند بمبلغ <strong className="text-white">{cancellingTx.amount} {cancellingTx.currency}</strong>؟ سيتم إرجاع المبلغ فوراً إلى رصيد الصندوق وتوثيق العملية في سجل التدقيق.
            </p>

            <div>
              <label className="text-xs text-rose-300 font-bold block mb-1">سبب الإلغاء المكتوب (إلزامي للرقابة):</label>
              <input
                type="text"
                required
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                placeholder="مثال: خطأ في إدخال المبلغ / إلغاء طلب الزبون"
                className="w-full bg-[#120a00] border border-rose-500/50 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCancellingTx(null)}
                className="px-4 py-2 rounded-xl bg-[#1a0f00] border border-[#D4AF37]/40 text-[#E6C37A] text-xs font-bold"
              >
                تراجع
              </button>
              <button
                type="button"
                onClick={handleConfirmCancel}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black shadow-md"
              >
                تأكيد الإلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Photo Preview Modal */}
      {selectedPhoto && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/90 backdrop-blur-md"
          onClick={() => setSelectedPhoto(null)}
        >
          <div className="relative max-w-[370px] w-full bg-[#140b00] border border-[#D4AF37]/60 rounded-2xl p-2 overflow-hidden shadow-2xl">
            <button
              onClick={() => setSelectedPhoto(null)}
              className="absolute top-4 left-4 p-1.5 rounded-full bg-[#1a0f00] text-white border border-[#D4AF37]/40 z-10"
            >
              <X className="w-5 h-5" />
            </button>
            <img src={selectedPhoto} alt="وصل السند" className="w-full h-auto max-h-[80vh] object-contain rounded-xl" />
          </div>
        </div>
      )}

      {/* Daily Financial Report Modal */}
      <DailyFinancialReportModal
        isOpen={showDailyReport}
        onClose={() => setShowDailyReport(false)}
      />

      {/* Transaction Detail Modal (Exact Creator, Timestamp, Edit & Cancel Reasons) */}
      <TransactionDetailModal
        transaction={detailTx}
        isOpen={Boolean(detailTx)}
        onClose={() => setDetailTx(null)}
      />

    </div>
  );
};
