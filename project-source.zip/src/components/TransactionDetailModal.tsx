import React from 'react';
import { Transaction } from '../types/database';
import { 
  X, 
  Coins, 
  Calendar, 
  Clock, 
  User, 
  Phone, 
  Building2, 
  FileText, 
  AlertTriangle, 
  Edit3, 
  CheckCircle2 
} from 'lucide-react';

interface TransactionDetailModalProps {
  transaction: Transaction | null;
  isOpen: boolean;
  onClose: () => void;
}

export const TransactionDetailModal: React.FC<TransactionDetailModalProps> = ({
  transaction,
  isOpen,
  onClose
}) => {
  if (!isOpen || !transaction) return null;

  const isCancelled = transaction.status === 'cancelled';
  const isInflow = transaction.type === 'cash_in' || 
                   transaction.type === 'parcel_shipping_fee' || 
                   transaction.type === 'parcel_cod_collection';

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'cash_in':
        return { label: '📥 إيداع نقدي في الصندوق', color: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' };
      case 'parcel_shipping_fee':
        return { label: '📦 قبض أجرة شحن كولي', color: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' };
      case 'parcel_cod_collection':
        return { label: '💰 قبض تحصيل كولي عند التسليم (COD)', color: 'bg-amber-500/15 text-amber-300 border-amber-500/30' };
      case 'cash_out':
        return { label: '📤 صرف نقدي / مصاريف تشغيلية', color: 'bg-rose-500/15 text-rose-300 border-rose-500/30' };
      case 'goods_payment':
        return { label: '🤝 سداد بضاعة للتاجر / المرسل', color: 'bg-amber-500/15 text-amber-300 border-amber-500/30' };
      case 'parcel_cod_payout':
        return { label: '📤 تسليم مبلغ COD محصل للتاجر', color: 'bg-rose-500/15 text-rose-300 border-rose-500/30' };
      default:
        return { label: type, color: 'bg-slate-700 text-slate-300 border-slate-600' };
    }
  };

  const badge = getTypeLabel(transaction.type);

  const formatExactDateTime = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return `${d.toLocaleDateString('ar-MA')} - ${d.toLocaleTimeString('ar-MA', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      })}`;
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto animate-fadeIn" dir="rtl">
      <div 
        className="w-full max-w-lg bg-[#0F172A] border border-amber-500/30 rounded-3xl p-5 sm:p-6 shadow-2xl text-right overflow-hidden relative my-6 space-y-4 max-h-[92vh] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/15 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold">
              <Coins className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">تفاصيل القيد المالي (لاكيس)</h3>
              <p className="text-[11px] text-slate-400 font-mono">
                المعرف: {transaction.id}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-1 pl-1 text-xs">
          
          {/* Main Status & Amount Card */}
          <div className={`p-4 rounded-2xl border ${
            isCancelled 
              ? 'bg-rose-500/10 border-rose-500/30' 
              : 'bg-gradient-to-br from-[#111C30] to-[#0D1524] border-slate-800'
          }`}>
            <div className="flex items-center justify-between mb-3">
              <span className={`px-3 py-1 rounded-full text-xs font-bold border ${badge.color}`}>
                {badge.label}
              </span>
              <span className="text-slate-400 font-bold flex items-center gap-1">
                <Building2 className="w-3.5 h-3.5 text-amber-400" />
                <span>{transaction.station_name || 'المحطة'}</span>
              </span>
            </div>

            <div className="flex items-baseline justify-between pt-2 border-t border-slate-800/80">
              <span className="text-slate-400">قيمة القيد الصافي:</span>
              <span className={`text-2xl font-black font-mono ${
                isCancelled
                  ? 'line-through text-slate-500'
                  : isInflow
                  ? 'text-emerald-400'
                  : 'text-rose-400'
              }`}>
                {isInflow ? '+' : '-'}{transaction.amount} <span className="text-sm font-sans text-slate-300 font-normal">{transaction.currency}</span>
              </span>
            </div>
          </div>

          {/* Creation Metadata - Who & Exact Date/Time */}
          <div className="bg-[#0B1220] p-4 rounded-2xl border border-slate-800 space-y-2.5">
            <h4 className="text-[11px] font-bold text-amber-400 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5" />
              <span>توثيق التسجيل المالي (من ومتى)</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-slate-800/80">
              <div className="bg-[#0F172A] p-2.5 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 block mb-0.5">سجّله الموظف / المسؤول:</span>
                <span className="font-bold text-white text-xs flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>{transaction.creator_name || 'موظف المحطة'}</span>
                </span>
              </div>

              <div className="bg-[#0F172A] p-2.5 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 block mb-0.5">التاريخ والوقت بالثانية:</span>
                <span className="font-mono font-bold text-amber-300 text-xs" dir="ltr">
                  {formatExactDateTime(transaction.created_at)}
                </span>
              </div>
            </div>
          </div>

          {/* Cancellation Info (If Cancelled) */}
          {isCancelled && (
            <div className="bg-rose-500/15 border border-rose-500/40 p-3.5 rounded-2xl space-y-2">
              <div className="flex items-center gap-1.5 text-rose-300 font-bold text-xs">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>بيانات إلغاء هذا السند المالي:</span>
              </div>
              <div className="text-xs text-rose-200/90 space-y-1 bg-rose-950/40 p-2.5 rounded-xl border border-rose-900/50">
                <p>
                  <strong className="text-white">أُلغي بواسطة:</strong> {transaction.cancelled_by_name || 'المدير العام'}
                </p>
                {transaction.cancelled_at && (
                  <p>
                    <strong className="text-white">تاريخ وتوقيت الإلغاء:</strong> <span className="font-mono text-rose-300" dir="ltr">{formatExactDateTime(transaction.cancelled_at)}</span>
                  </p>
                )}
                <p>
                  <strong className="text-white">السبب المكتوب للإلغاء:</strong> {transaction.cancel_reason || 'تم إرجاع المبلغ للصندوق'}
                </p>
              </div>
            </div>
          )}

          {/* Edit History (If Edited) */}
          {transaction.edit_history && transaction.edit_history.length > 0 && (
            <div className="bg-[#0B1220] p-4 rounded-2xl border border-amber-500/30 space-y-2.5">
              <h4 className="text-[11px] font-bold text-amber-400 flex items-center gap-1.5">
                <Edit3 className="w-3.5 h-3.5" />
                <span>سجل التعديلات السابقة ({transaction.edit_history.length})</span>
              </h4>

              <div className="space-y-2">
                {transaction.edit_history.map((entry, idx) => (
                  <div key={idx} className="bg-[#0F172A] p-2.5 rounded-xl border border-slate-800 text-[11px] space-y-1">
                    <div className="flex items-center justify-between text-slate-300 font-bold">
                      <span>عدّله: {entry.edited_by_name}</span>
                      <span className="font-mono text-[10px] text-slate-500" dir="ltr">
                        {formatExactDateTime(entry.edited_at)}
                      </span>
                    </div>
                    <p className="text-amber-300/90">
                      <strong className="text-slate-400">السبب المكتوب:</strong> {entry.reason}
                    </p>
                    {entry.previous_data?.amount && (
                      <p className="text-slate-400 font-mono text-[10px]">
                        المبلغ السابق: {entry.previous_data.amount}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Party & Reason Details */}
          <div className="bg-[#0B1220] p-4 rounded-2xl border border-slate-800 space-y-2 text-xs">
            <h4 className="text-[11px] font-bold text-slate-400 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5" />
              <span>البيان وتفاصيل المستفيد</span>
            </h4>

            <div className="pt-1 space-y-1.5">
              <div>
                <span className="text-slate-400 text-[10px] block">البيان / السبب:</span>
                <p className="text-white font-bold bg-[#0F172A] p-2 rounded-xl border border-slate-800">
                  {transaction.reason || 'بدون بيان محدد'}
                </p>
              </div>

              {transaction.phone_number && (
                <div>
                  <span className="text-slate-400 text-[10px] block">رقم الهاتف:</span>
                  <p className="text-amber-300 font-mono font-bold bg-[#0F172A] p-2 rounded-xl border border-slate-800 flex items-center gap-1.5" dir="ltr">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>{transaction.phone_number}</span>
                  </p>
                </div>
              )}

              {transaction.note && (
                <div>
                  <span className="text-slate-400 text-[10px] block">ملاحظات إضافية:</span>
                  <p className="text-slate-300 italic bg-[#0F172A] p-2 rounded-xl border border-slate-800">
                    "{transaction.note}"
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Photo Preview if attached */}
          {transaction.photo_url && (
            <div className="bg-[#0B1220] p-3 rounded-2xl border border-slate-800 text-center">
              <span className="text-[10px] text-slate-400 block mb-1.5 font-bold">صورة الوصل المرفقة:</span>
              <img 
                src={transaction.photo_url} 
                alt="وصل السند" 
                className="max-h-56 mx-auto rounded-xl object-contain border border-slate-700" 
              />
            </div>
          )}

        </div>

        {/* Modal Actions */}
        <div className="border-t border-slate-800 pt-3 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs transition"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
