/**
 * محطة الاتحادية | تطبيق إدارة محطات الإرساليات والكوليات والتحويلات المالية والصناديق النقدية
 * بين المملكة المغربية والجمهورية الإسلامية الموريتانية (عبر معبر الكركرات الدولي)
 * React + TypeScript + Vite + Tailwind CSS + PWA Offline-First
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { BottomNav, NavTab } from './components/BottomNav';
import { OwnerDashboard } from './components/OwnerDashboard';
import { WorkerStationView } from './components/WorkerStationView';
import { ParcelsView } from './components/ParcelsView';
import { LedgerView } from './components/LedgerView';
import { SettingsView } from './components/SettingsView';
import { NewVoucherModal } from './components/NewVoucherModal';
import { NewParcelModal } from './components/NewParcelModal';
import { ParcelStickerModal } from './components/ParcelStickerModal';
import { PaywallModal } from './components/PaywallModal';
import { SQLModal } from './components/SQLModal';
import { AuthModal } from './components/AuthModal';
import { OnboardingModal } from './components/OnboardingModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { DataPrivacyModal } from './components/DataPrivacyModal';
import { PlatformOwnerDashboard } from './components/PlatformOwnerDashboard';
import { Toast } from './components/Toast';
import { Parcel } from './types/database';
import { AlertTriangle, Clock } from 'lucide-react';

const MainApp: React.FC = () => {
  const { 
    currentUser, 
    userRole, 
    currentWorkspace, 
    daysUntilExpiry, 
    isSubscriptionExpired 
  } = useApp();

  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [showNewVoucher, setShowNewVoucher] = useState(false);
  const [showNewParcel, setShowNewParcel] = useState(false);
  const [showPaywall, setShowPaywall] = useState(false);
  const [showSQLModal, setShowSQLModal] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [showPlatformOwnerDashboard, setShowPlatformOwnerDashboard] = useState(false);
  const [stickerParcel, setStickerParcel] = useState<Parcel | null>(null);

  // If user is not logged in, prompt Auth modal
  if (!currentUser) {
    return <AuthModal isOpen={true} />;
  }

  // If user has no workspace, prompt Onboarding modal
  if (!currentWorkspace) {
    return <OnboardingModal isOpen={true} />;
  }

  return (
    <div className="min-h-screen w-full bg-black flex justify-center selection:bg-[#D4AF37]/30 selection:text-[#FFF8EB]" dir="rtl">
      <div className="w-full max-w-[390px] min-h-screen bg-[#060300] text-[#FFF8EB] flex flex-col border-x border-[#D4AF37]/25 shadow-[0_0_60px_rgba(0,0,0,1)] relative overflow-x-hidden">
      
        {/* Offline Status Top Banner */}
        <OfflineIndicator />

        {/* Top Header with Responsive Mobile Hamburger & No Text Overlap */}
        <Header
          onOpenSettings={() => setCurrentTab('settings')}
          onOpenPaywall={() => setShowPaywall(true)}
        />

        {/* 3-Day Expiry Warning Banner */}
        {!isSubscriptionExpired && daysUntilExpiry <= 3 && (
          <div 
            onClick={() => setShowPaywall(true)}
            className="bg-[#1a0f00]/90 border-b border-[#D4AF37]/40 px-3.5 py-2 text-xs font-semibold text-[#E6C37A] flex items-center justify-between cursor-pointer hover:bg-[#2a1800] transition text-right"
          >
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#D4AF37] shrink-0" />
              <span>
                تنبيه: يتبقى <strong>{daysUntilExpiry} أيام</strong> على انتهاء اشتراك مساحة العمل. انقر للتجديد.
              </span>
            </div>
            <span className="text-[10px] underline font-bold text-[#F3A952]">تجديد الاشتراك</span>
          </div>
        )}

        {/* Expired Paywall Warning Banner */}
        {isSubscriptionExpired && (
          <div 
            onClick={() => setShowPaywall(true)}
            className="bg-rose-950/60 border-b border-rose-500/40 px-3.5 py-2 text-xs font-bold text-rose-300 flex items-center justify-between cursor-pointer hover:bg-rose-950/80 transition text-right"
          >
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>
                انتهت صلاحية الاشتراك. يرجى تجديد الاشتراك لمتابعة تسجيل الكوليات والسندات النقدية.
              </span>
            </div>
            <span className="text-[10px] underline font-bold">تجديد الآن</span>
          </div>
        )}

        {/* Main View Area */}
        <main className="flex-1 w-full mx-auto px-3 py-2.5">
        {currentTab === 'dashboard' && (
          userRole === 'owner' ? (
            <OwnerDashboard
              onOpenNewVoucher={() => setShowNewVoucher(true)}
              onOpenNewParcel={() => setShowNewParcel(true)}
              onOpenLedger={() => setCurrentTab('cash')}
              onOpenParcels={() => setCurrentTab('parcels')}
              onOpenSettings={() => setCurrentTab('settings')}
            />
          ) : (
            <WorkerStationView
              onOpenNewVoucher={() => setShowNewVoucher(true)}
              onOpenNewParcel={() => setShowNewParcel(true)}
              onGoToParcels={() => setCurrentTab('parcels')}
              onGoToCash={() => setCurrentTab('cash')}
            />
          )
        )}

        {currentTab === 'parcels' && (
          <ParcelsView 
            onOpenNewParcel={() => setShowNewParcel(true)} 
          />
        )}

        {currentTab === 'cash' && (
          <LedgerView 
            onOpenNewVoucher={() => setShowNewVoucher(true)} 
          />
        )}

        {currentTab === 'settings' && (
          <SettingsView
            onOpenSQLModal={() => setShowSQLModal(true)}
            onOpenPaywall={() => setShowPaywall(true)}
            onOpenPrivacyModal={() => setShowPrivacyModal(true)}
            onOpenPlatformOwner={() => setShowPlatformOwnerDashboard(true)}
          />
        )}
      </main>

      {/* Floating Bottom Navigation */}
      <BottomNav
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onOpenNewVoucher={() => setShowNewVoucher(true)}
        onOpenNewParcel={() => setShowNewParcel(true)}
      />

      {/* New Cash Voucher Modal */}
      <NewVoucherModal
        isOpen={showNewVoucher}
        onClose={() => setShowNewVoucher(false)}
      />

      {/* New Parcel Intake Modal */}
      <NewParcelModal
        isOpen={showNewParcel}
        onClose={() => setShowNewParcel(false)}
        onParcelCreated={(parcel) => setStickerParcel(parcel)}
      />

      {/* 10cm x 10cm Parcel Sticker Modal */}
      <ParcelStickerModal
        parcel={stickerParcel}
        isOpen={Boolean(stickerParcel)}
        onClose={() => setStickerParcel(null)}
      />

      {/* Who Can See My Data - Privacy & Collaboration Modal */}
      <DataPrivacyModal
        isOpen={showPrivacyModal}
        onClose={() => setShowPrivacyModal(false)}
      />

      {/* Subscription Paywall Modal */}
      <PaywallModal
        isOpen={showPaywall}
        onClose={() => setShowPaywall(false)}
      />

      {/* SQL Migration Modal */}
      <SQLModal
        isOpen={showSQLModal}
        onClose={() => setShowSQLModal(false)}
      />

      {/* Platform Owner Dashboard Modal */}
      <PlatformOwnerDashboard
        isOpen={showPlatformOwnerDashboard}
        onClose={() => setShowPlatformOwnerDashboard(false)}
      />

      {/* Onboarding Modal */}
      <OnboardingModal
        isOpen={showOnboarding}
        onClose={() => setShowOnboarding(false)}
      />

      {/* Toast Notification Container */}
      <Toast />

      </div>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}
