-- ============================================================================
-- محطة الاتحادية - AL-ITTIHADIYA
-- سكريبت قاعدة البيانات الرئيسي المتكامل لـ Supabase (PostgreSQL + RLS + Functions + Triggers)
-- الإصدار الشامل (Phases 1-8)
-- ============================================================================
-- ميزات وهندسة الأمان:
-- 1. عزل مطلق بين مساحات العمل (Multi-Admin Isolation) عبر workspace_id في كل جدول
-- 2. معرف فريد قصير من 6 أحرف لكل مساحة عمل (Short ID)
-- 3. عزل العمال حسب المحطة (Worker Station Isolation): العامل يرى فقط محطته المعين بها
-- 4. أمان مالك المنصة (Platform Owner): الصلاحية محصورة بجدول platform_owners ولا تُمنح بالهاتف إطلاقاً
-- 5. تفعيل RLS على كل الجداول (100% RLS Coverage) دون أي سياسة تستخدم true أو وصول مجهول anon
-- 6. دوال SECURITY DEFINER مزودة بفحص auth.uid() ومسار بحث محكم: SET search_path = public, pg_temp
-- 7. وحدة كوليات مستقلة مع سجل تاريخ الحالات والدفعات والتذاكر الحرارية
-- 8. تقارير إغلاق اليومية وسجلات الرقابة المحاسبية مع أسباب التعديل والإلغاء
-- ============================================================================

-- 0. الملحقات الضرورية
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================================
-- 1. الجداول الأساسية (TABLES)
-- ============================================================================

-- 1.1 جدول مالكي المنصة (Platform Owners)
-- جدول محمي تماماً: لا يمكن لأي واجهة برمجية أو مستخدم عادي الإدراج فيه
-- يتم التعيين حصراً بأمر SQL يدوي من قِبل المشرف العام
CREATE TABLE IF NOT EXISTS public.platform_owners (
    user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 1.2 جدول ملفات المستخدمين (مرتبط بـ auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    phone TEXT NOT NULL UNIQUE,
    whatsapp_number TEXT NOT NULL,
    avatar_url TEXT,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 1.3 جدول مساحات العمل المستقلة (Workspaces)
CREATE TABLE IF NOT EXISTS public.workspaces (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    short_id VARCHAR(6) UNIQUE NOT NULL,      -- كود فريد من 6 أحرف مثل WK7A9X
    name TEXT NOT NULL,
    invite_code VARCHAR(12) UNIQUE NOT NULL,  -- رمز دعوة عشوائي متجدد للعمال
    parcels_module_enabled BOOLEAN DEFAULT TRUE NOT NULL,
    printer_width VARCHAR(5) DEFAULT '80mm' NOT NULL CHECK (printer_width IN ('58mm', '80mm')),
    owner_phone TEXT,
    owner_whatsapp TEXT,
    admin_notes TEXT,
    last_parcel_number BIGINT DEFAULT 100 NOT NULL,
    created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

ALTER TABLE public.workspaces ADD COLUMN IF NOT EXISTS last_parcel_number BIGINT DEFAULT 100 NOT NULL;

-- 1.4 جدول أعضاء مساحة العمل (Workspace Members)
CREATE TABLE IF NOT EXISTS public.workspace_members (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK (role IN ('admin', 'worker')),
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'pending', 'rejected', 'removed')),
    joined_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE (workspace_id, user_id)
);

-- 1.5 جدول طلبات الانضمام لمساحة العمل (Join Requests)
CREATE TABLE IF NOT EXISTS public.join_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    invite_code_used TEXT NOT NULL,
    user_name TEXT NOT NULL,
    user_phone TEXT NOT NULL,
    user_whatsapp TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    resolved_at TIMESTAMPTZ,
    resolved_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    UNIQUE (workspace_id, user_id)
);

-- 1.6 جدول طلبات استعادة كلمة المرور (Password Reset Requests)
CREATE TABLE IF NOT EXISTS public.password_reset_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    user_name TEXT NOT NULL,
    user_phone TEXT NOT NULL,
    user_whatsapp TEXT NOT NULL,
    workspace_id UUID REFERENCES public.workspaces(id) ON DELETE CASCADE,
    target_role TEXT NOT NULL CHECK (target_role IN ('worker', 'admin')),
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'resolved', 'rejected')),
    temporary_password TEXT,
    requested_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    resolved_at TIMESTAMPTZ,
    resolved_by UUID REFERENCES auth.users(id) ON DELETE SET NULL
);

-- 1.7 جدول التعاون والمشاركة بين المدراء (Workspace Collaborations)
CREATE TABLE IF NOT EXISTS public.workspace_collaborations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    requester_workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
    target_workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected', 'cancelled')),
    
    -- إعدادات الطرف الطالب (ما يشاركه مع الطرف الآخر)
    requester_share_cash BOOLEAN DEFAULT FALSE NOT NULL,
    requester_share_parcels BOOLEAN DEFAULT FALSE NOT NULL,
    requester_share_reports BOOLEAN DEFAULT FALSE NOT NULL,
    
    -- إعدادات الطرف المستهدف (ما يشاركه مع الطرف الطالب)
    target_share_cash BOOLEAN DEFAULT FALSE NOT NULL,
    target_share_parcels BOOLEAN DEFAULT FALSE NOT NULL,
    target_share_reports BOOLEAN DEFAULT FALSE NOT NULL,
    
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    
    CHECK (requester_workspace_id <> target_workspace_id),
    UNIQUE (requester_workspace_id, target_workspace_id)
);

-- 1.8 جدول المحطات الدولية (Stations)
CREATE TABLE IF NOT EXISTS public.stations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    city TEXT NOT NULL,
    country VARCHAR(2) NOT NULL CHECK (country IN ('MA', 'MR')),
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    phone TEXT,
    address TEXT,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 1.9 جدول تعيين العمال في المحطات (Station Workers)
CREATE TABLE IF NOT EXISTS public.station_workers (
    station_id UUID NOT NULL REFERENCES public.stations(id) ON DELETE CASCADE,
    workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    assigned_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    PRIMARY KEY (station_id, user_id)
);

-- 1.10 جدول أرصدة المحطات والصناديق (Station Balances)
CREATE TABLE IF NOT EXISTS public.station_balances (
    station_id UUID NOT NULL REFERENCES public.stations(id) ON DELETE CASCADE,
    workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
    currency VARCHAR(4) NOT NULL CHECK (currency IN ('MAD', 'MRU')),
    balance NUMERIC(14,2) DEFAULT 0.00 NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    PRIMARY KEY (station_id, currency)
);

-- 1.11 جدول المعاملات النقدية والتحويلات (Transactions)
CREATE TABLE IF NOT EXISTS public.transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
    station_id UUID NOT NULL REFERENCES public.stations(id) ON DELETE RESTRICT,
    created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    type TEXT NOT NULL CHECK (type IN (
        'cash_in', 
        'cash_out', 
        'goods_payment', 
        'parcel_shipping_fee', 
        'parcel_cod_collection', 
        'parcel_cod_payout'
    )),
    amount NUMERIC(14,2) NOT NULL CHECK (amount > 0),
    currency VARCHAR(4) NOT NULL CHECK (currency IN ('MAD', 'MRU')),
    person_name TEXT NOT NULL,
    person_phone TEXT,
    reason TEXT,
    photo_url TEXT,
    status TEXT NOT NULL DEFAULT 'confirmed' CHECK (status IN ('confirmed', 'cancelled')),
    note TEXT,
    parcel_id UUID,
    edit_history JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 1.12 جدول الكوليات والإرساليات المستقل (Parcels)
CREATE TABLE IF NOT EXISTS public.parcels (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
    parcel_number BIGINT NOT NULL,
    tracking_code VARCHAR(30) UNIQUE NOT NULL,
    origin_station_id UUID NOT NULL REFERENCES public.stations(id) ON DELETE RESTRICT,
    destination_station_id UUID NOT NULL REFERENCES public.stations(id) ON DELETE RESTRICT,
    sender_name TEXT NOT NULL,
    sender_phone TEXT NOT NULL,
    receiver_name TEXT NOT NULL,
    receiver_phone TEXT NOT NULL,
    route TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT DEFAULT 'بضائع عامة',
    items_count INT DEFAULT 1 NOT NULL CHECK (items_count > 0),
    weight_kg NUMERIC(10,2),
    declared_value NUMERIC(12,2),
    amount_due NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (amount_due >= 0),
    payer TEXT NOT NULL DEFAULT 'sender' CHECK (payer IN ('sender', 'receiver')),
    amount_paid NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (amount_paid >= 0),
    currency VARCHAR(4) NOT NULL DEFAULT 'MAD' CHECK (currency IN ('MAD', 'MRU')),
    status TEXT NOT NULL DEFAULT 'registered' CHECK (status IN (
        'registered', 
        'in_transit', 
        'arrived', 
        'delivered', 
        'cancelled'
    )),
    condition TEXT NOT NULL DEFAULT 'normal' CHECK (condition IN ('normal', 'abnormal')),
    condition_notes TEXT,
    current_trip_id UUID,
    driver_name TEXT,
    vehicle_plate TEXT,
    status_history JSONB NOT NULL DEFAULT '[]'::jsonb,
    payment_history JSONB NOT NULL DEFAULT '[]'::jsonb,
    notes TEXT,
    delivered_to TEXT,
    delivered_at TIMESTAMPTZ,
    created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 1.13 جدول الاشتراكات ومتابعة المدراء (Subscriptions)
CREATE TABLE IF NOT EXISTS public.subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID UNIQUE NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
    status TEXT NOT NULL DEFAULT 'trial' CHECK (status IN ('trial', 'active', 'expired', 'suspended')),
    start_date TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    end_date TIMESTAMPTZ NOT NULL,
    is_trial BOOLEAN DEFAULT TRUE NOT NULL,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 1.14 جدول العملات وأسعار الصرف (Currencies)
CREATE TABLE IF NOT EXISTS public.currencies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
    code VARCHAR(10) NOT NULL,
    label_ar TEXT NOT NULL,
    symbol TEXT DEFAULT '',
    rate_to_mad NUMERIC NOT NULL DEFAULT 1,
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE (workspace_id, code)
);

-- 1.15 سجل التدقيق والرقابة الشامل (Audit Logs)
CREATE TABLE IF NOT EXISTS public.audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    action TEXT NOT NULL,
    table_name TEXT NOT NULL,
    record_id TEXT NOT NULL,
    reason TEXT,
    old_data JSONB,
    new_data JSONB,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 1.16 جدول رحلات الشحن والديسباتش (Trips)
CREATE TABLE IF NOT EXISTS public.trips (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
    trip_number INT NOT NULL,
    trip_code VARCHAR(40) NOT NULL,
    driver_name TEXT NOT NULL,
    driver_phone TEXT,
    vehicle_plate TEXT NOT NULL,
    origin_station_id UUID NOT NULL REFERENCES public.stations(id) ON DELETE RESTRICT,
    destination_station_id UUID NOT NULL REFERENCES public.stations(id) ON DELETE RESTRICT,
    status TEXT NOT NULL DEFAULT 'loading' CHECK (status IN ('loading', 'departed', 'arrived', 'closed')),
    parcels_count INT NOT NULL DEFAULT 0,
    loaded_parcel_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
    received_parcel_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
    departure_time TIMESTAMPTZ,
    arrival_time TIMESTAMPTZ,
    closed_at TIMESTAMPTZ,
    closed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    close_reason TEXT,
    notes TEXT,
    created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE (workspace_id, trip_code)
);

-- 1.17 جدول طرود الرحلات والربط المباشر (Trip Parcels)
CREATE TABLE IF NOT EXISTS public.trip_parcels (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
    trip_id UUID NOT NULL REFERENCES public.trips(id) ON DELETE CASCADE,
    parcel_id UUID NOT NULL REFERENCES public.parcels(id) ON DELETE CASCADE,
    loaded_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    received_at TIMESTAMPTZ,
    condition TEXT NOT NULL DEFAULT 'normal' CHECK (condition IN ('normal', 'abnormal')),
    condition_notes TEXT,
    scanned_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    received_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    UNIQUE (trip_id, parcel_id)
);

-- 1.18 جدول السائقين المحفوظين للاختيار السريع (Remembered Drivers)
CREATE TABLE IF NOT EXISTS public.remembered_drivers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    phone TEXT,
    last_used TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE (workspace_id, name)
);

-- 1.19 جدول ماتريكيلات العربات المحفوظة (Remembered Vehicles)
CREATE TABLE IF NOT EXISTS public.remembered_vehicles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
    plate TEXT NOT NULL,
    last_used TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE (workspace_id, plate)
);

-- ============================================================================
-- 2. الفهارس (INDEXES)
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_workspaces_short_id ON public.workspaces(short_id);
CREATE INDEX IF NOT EXISTS idx_workspaces_invite_code ON public.workspaces(invite_code);
CREATE INDEX IF NOT EXISTS idx_members_user_ws ON public.workspace_members(user_id, workspace_id);
CREATE INDEX IF NOT EXISTS idx_join_requests_ws_status ON public.join_requests(workspace_id, status);
CREATE INDEX IF NOT EXISTS idx_collab_req ON public.workspace_collaborations(requester_workspace_id, status);
CREATE INDEX IF NOT EXISTS idx_collab_target ON public.workspace_collaborations(target_workspace_id, status);
CREATE INDEX IF NOT EXISTS idx_stations_ws ON public.stations(workspace_id);
CREATE INDEX IF NOT EXISTS idx_station_workers_user ON public.station_workers(user_id, station_id);
CREATE INDEX IF NOT EXISTS idx_tx_ws_station ON public.transactions(workspace_id, station_id, status);
CREATE INDEX IF NOT EXISTS idx_parcels_ws_tracking ON public.parcels(workspace_id, tracking_code);
CREATE INDEX IF NOT EXISTS idx_parcels_status ON public.parcels(workspace_id, status);
CREATE INDEX IF NOT EXISTS idx_trips_ws_status ON public.trips(workspace_id, status);
CREATE INDEX IF NOT EXISTS idx_trips_route ON public.trips(origin_station_id, destination_station_id);
CREATE INDEX IF NOT EXISTS idx_trip_parcels_trip ON public.trip_parcels(trip_id);
CREATE INDEX IF NOT EXISTS idx_trip_parcels_parcel ON public.trip_parcels(parcel_id);
CREATE INDEX IF NOT EXISTS idx_rem_drivers_ws ON public.remembered_drivers(workspace_id);
CREATE INDEX IF NOT EXISTS idx_rem_vehicles_ws ON public.remembered_vehicles(workspace_id);
CREATE INDEX IF NOT EXISTS idx_pw_reset_user ON public.password_reset_requests(user_id, status);

-- ============================================================================
-- 3. الدوال الأمنية المساعدة (SECURITY DEFINER FUNCTIONS)
-- ============================================================================

-- هل المستخدم هو مالك المنصة؟ (فحص وجود المعرف في جدول platform_owners)
CREATE OR REPLACE FUNCTION public.is_platform_owner(p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT CASE 
        WHEN p_user_id IS NULL THEN FALSE
        ELSE EXISTS (SELECT 1 FROM public.platform_owners WHERE user_id = p_user_id)
    END;
$$;

-- معرف مساحة العمل النشطة للمستخدم
CREATE OR REPLACE FUNCTION public.get_user_workspace_id(p_user_id UUID)
RETURNS UUID
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT workspace_id 
    FROM public.workspace_members 
    WHERE user_id = p_user_id AND status = 'active'
    LIMIT 1;
$$;

-- هل المستخدم مدير لمساحة العمل المحددة؟
CREATE OR REPLACE FUNCTION public.is_workspace_admin(p_workspace_id UUID, p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT CASE 
        WHEN p_user_id IS NULL THEN FALSE
        ELSE EXISTS (
            SELECT 1 
            FROM public.workspace_members 
            WHERE workspace_id = p_workspace_id 
              AND user_id = p_user_id 
              AND role = 'admin' 
              AND status = 'active'
        )
    END;
$$;

-- هل المستخدم عضو نشط في مساحة العمل؟
CREATE OR REPLACE FUNCTION public.is_workspace_member(p_workspace_id UUID, p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT CASE 
        WHEN p_user_id IS NULL THEN FALSE
        ELSE EXISTS (
            SELECT 1 
            FROM public.workspace_members 
            WHERE workspace_id = p_workspace_id 
              AND user_id = p_user_id 
              AND status = 'active'
        )
    END;
$$;

-- هل العامل مخصص لمحطة معينة؟
CREATE OR REPLACE FUNCTION public.is_worker_assigned_to_station(p_station_id UUID, p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT CASE 
        WHEN p_user_id IS NULL THEN FALSE
        ELSE EXISTS (
            SELECT 1 
            FROM public.station_workers 
            WHERE station_id = p_station_id 
              AND user_id = p_user_id
        )
    END;
$$;

-- هل يحق للمستخدم رؤية حركة الأموال في مساحة العمل؟
-- (مدير المساحة، أو عامل في محطته المعين بها، أو مدير شريك فُعِّلت له المشاركة)
CREATE OR REPLACE FUNCTION public.can_view_workspace_cash(p_workspace_id UUID, p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
DECLARE
    v_user_ws UUID;
    v_is_admin BOOLEAN;
BEGIN
    IF p_user_id IS NULL THEN 
        RETURN FALSE; 
    END IF;

    -- إذا كان مديراً في مساحة العمل نفسها
    IF public.is_workspace_admin(p_workspace_id, p_user_id) THEN
        RETURN TRUE;
    END IF;

    -- التحقق إن كان مديراً في مساحة عمل شريكة سمحت له برؤية الكاش
    v_user_ws := public.get_user_workspace_id(p_user_id);
    IF v_user_ws IS NULL THEN
        RETURN FALSE;
    END IF;

    v_is_admin := public.is_workspace_admin(v_user_ws, p_user_id);
    IF NOT v_is_admin THEN
        RETURN FALSE;
    END IF;

    RETURN EXISTS (
        SELECT 1 
        FROM public.workspace_collaborations
        WHERE status = 'accepted'
          AND (
            (requester_workspace_id = p_workspace_id AND target_workspace_id = v_user_ws AND requester_share_cash = TRUE)
            OR
            (target_workspace_id = p_workspace_id AND requester_workspace_id = v_user_ws AND target_share_cash = TRUE)
          )
    );
END;
$$;

-- هل يحق للمستخدم رؤية طرود مساحة العمل؟
CREATE OR REPLACE FUNCTION public.can_view_workspace_parcels(p_workspace_id UUID, p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
DECLARE
    v_user_ws UUID;
    v_is_admin BOOLEAN;
BEGIN
    IF p_user_id IS NULL THEN 
        RETURN FALSE; 
    END IF;

    -- إذا كان مديراً في مساحة العمل
    IF public.is_workspace_admin(p_workspace_id, p_user_id) THEN
        RETURN TRUE;
    END IF;

    -- التحقق إن كان مديراً في مساحة عمل شريكة فُعلت له مشاركة الطرود
    v_user_ws := public.get_user_workspace_id(p_user_id);
    IF v_user_ws IS NULL THEN
        RETURN FALSE;
    END IF;

    v_is_admin := public.is_workspace_admin(v_user_ws, p_user_id);
    IF NOT v_is_admin THEN
        RETURN FALSE;
    END IF;

    RETURN EXISTS (
        SELECT 1 
        FROM public.workspace_collaborations
        WHERE status = 'accepted'
          AND (
            (requester_workspace_id = p_workspace_id AND target_workspace_id = v_user_ws AND requester_share_parcels = TRUE)
            OR
            (target_workspace_id = p_workspace_id AND requester_workspace_id = v_user_ws AND target_share_parcels = TRUE)
          )
    );
END;
$$;

-- هل يحق للمستخدم رؤية رقم واتساب المستخدم المستهدف؟
-- (فقط لنفسه، أو لأعضاء نفس مساحة العمل، أو للمدراء الشركاء)
CREATE OR REPLACE FUNCTION public.can_view_user_whatsapp(p_target_user_id UUID, p_viewer_user_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
DECLARE
    v_target_ws UUID;
    v_viewer_ws UUID;
BEGIN
    IF p_viewer_user_id IS NULL THEN 
        RETURN FALSE; 
    END IF;

    IF p_target_user_id = p_viewer_user_id THEN
        RETURN TRUE;
    END IF;

    v_target_ws := public.get_user_workspace_id(p_target_user_id);
    v_viewer_ws := public.get_user_workspace_id(p_viewer_user_id);

    IF v_target_ws IS NULL OR v_viewer_ws IS NULL THEN
        RETURN FALSE;
    END IF;

    -- أعضاء نفس مساحة العمل
    IF v_target_ws = v_viewer_ws THEN
        RETURN TRUE;
    END IF;

    -- مدراء في مساحات عمل متعاونة ومقبولة
    RETURN EXISTS (
        SELECT 1 
        FROM public.workspace_collaborations
        WHERE status = 'accepted'
          AND (
            (requester_workspace_id = v_target_ws AND target_workspace_id = v_viewer_ws)
            OR
            (target_workspace_id = v_target_ws AND requester_workspace_id = v_viewer_ws)
          )
          AND public.is_workspace_admin(v_viewer_ws, p_viewer_user_id)
    );
END;
$$;

-- ============================================================================
-- 4. سياسات الأمان على مستوى الصفوف (ROW LEVEL SECURITY - RLS)
-- ============================================================================

-- تفعيل RLS على كل الجداول دون استثناء
ALTER TABLE public.platform_owners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workspaces ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workspace_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.join_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.password_reset_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workspace_collaborations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.station_workers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.station_balances ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.parcels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trips ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trip_parcels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.remembered_drivers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.remembered_vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.currencies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- إزالة السياسات السابقة إن وجدت لضمان إمكانية إعادة تشغيل السكريبت بأمان (Idempotent)
DROP POLICY IF EXISTS "platform_owners_select_self" ON public.platform_owners;
DROP POLICY IF EXISTS "profiles_select_policy" ON public.profiles;
DROP POLICY IF EXISTS "profiles_insert_self" ON public.profiles;
DROP POLICY IF EXISTS "profiles_update_self" ON public.profiles;
DROP POLICY IF EXISTS "workspaces_select_policy" ON public.workspaces;
DROP POLICY IF EXISTS "workspaces_insert_policy" ON public.workspaces;
DROP POLICY IF EXISTS "workspaces_update_admin" ON public.workspaces;
DROP POLICY IF EXISTS "members_select_policy" ON public.workspace_members;
DROP POLICY IF EXISTS "members_manage_admin" ON public.workspace_members;
DROP POLICY IF EXISTS "join_requests_select_policy" ON public.join_requests;
DROP POLICY IF EXISTS "join_requests_insert_self" ON public.join_requests;
DROP POLICY IF EXISTS "join_requests_update_admin" ON public.join_requests;
DROP POLICY IF EXISTS "pw_reset_select_policy" ON public.password_reset_requests;
DROP POLICY IF EXISTS "pw_reset_insert_self" ON public.password_reset_requests;
DROP POLICY IF EXISTS "pw_reset_update_resolvers" ON public.password_reset_requests;
DROP POLICY IF EXISTS "collab_select_policy" ON public.workspace_collaborations;
DROP POLICY IF EXISTS "collab_insert_policy" ON public.workspace_collaborations;
DROP POLICY IF EXISTS "collab_update_policy" ON public.workspace_collaborations;
DROP POLICY IF EXISTS "stations_select_policy" ON public.stations;
DROP POLICY IF EXISTS "stations_modify_admin" ON public.stations;
DROP POLICY IF EXISTS "station_workers_select" ON public.station_workers;
DROP POLICY IF EXISTS "station_workers_modify_admin" ON public.station_workers;
DROP POLICY IF EXISTS "station_balances_select" ON public.station_balances;
DROP POLICY IF EXISTS "station_balances_modify_admin" ON public.station_balances;
DROP POLICY IF EXISTS "transactions_select_policy" ON public.transactions;
DROP POLICY IF EXISTS "transactions_insert_policy" ON public.transactions;
DROP POLICY IF EXISTS "transactions_update_admin" ON public.transactions;
DROP POLICY IF EXISTS "parcels_select_policy" ON public.parcels;
DROP POLICY IF EXISTS "parcels_insert_policy" ON public.parcels;
DROP POLICY IF EXISTS "parcels_update_policy" ON public.parcels;
DROP POLICY IF EXISTS "subscriptions_select_policy" ON public.subscriptions;
DROP POLICY IF EXISTS "subscriptions_update_platform_owner" ON public.subscriptions;
DROP POLICY IF EXISTS "currencies_select_policy" ON public.currencies;
DROP POLICY IF EXISTS "currencies_modify_admin" ON public.currencies;
DROP POLICY IF EXISTS "audit_logs_select_admin" ON public.audit_logs;
DROP POLICY IF EXISTS "audit_logs_insert_members" ON public.audit_logs;
DROP POLICY IF EXISTS "trips_select_policy" ON public.trips;
DROP POLICY IF EXISTS "trips_insert_policy" ON public.trips;
DROP POLICY IF EXISTS "trips_update_policy" ON public.trips;
DROP POLICY IF EXISTS "trips_delete_policy" ON public.trips;
DROP POLICY IF EXISTS "trip_parcels_select_policy" ON public.trip_parcels;
DROP POLICY IF EXISTS "trip_parcels_insert_policy" ON public.trip_parcels;
DROP POLICY IF EXISTS "trip_parcels_update_policy" ON public.trip_parcels;
DROP POLICY IF EXISTS "trip_parcels_delete_policy" ON public.trip_parcels;
DROP POLICY IF EXISTS "remembered_drivers_select_policy" ON public.remembered_drivers;
DROP POLICY IF EXISTS "remembered_drivers_insert_policy" ON public.remembered_drivers;
DROP POLICY IF EXISTS "remembered_drivers_update_policy" ON public.remembered_drivers;
DROP POLICY IF EXISTS "remembered_vehicles_select_policy" ON public.remembered_vehicles;
DROP POLICY IF EXISTS "remembered_vehicles_insert_policy" ON public.remembered_vehicles;
DROP POLICY IF EXISTS "remembered_vehicles_update_policy" ON public.remembered_vehicles;

-- 4.1 سياسات جدول مالكي المنصة (platform_owners)
-- قراءة فقط للمستخدم نفسه إذا كان مالكاً
CREATE POLICY "platform_owners_select_self"
ON public.platform_owners
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

-- 4.2 سياسات جدول الملفات الشخصية (profiles)
CREATE POLICY "profiles_select_policy"
ON public.profiles
FOR SELECT
TO authenticated
USING (
    auth.uid() = id
    OR public.can_view_user_whatsapp(id, auth.uid())
    OR public.is_platform_owner(auth.uid())
);

CREATE POLICY "profiles_insert_self"
ON public.profiles
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);

CREATE POLICY "profiles_update_self"
ON public.profiles
FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- 4.3 سياسات مساحات العمل (workspaces)
CREATE POLICY "workspaces_select_policy"
ON public.workspaces
FOR SELECT
TO authenticated
USING (
    public.is_workspace_member(id, auth.uid())
    OR EXISTS (
        SELECT 1 FROM public.workspace_collaborations
        WHERE status = 'accepted'
          AND (
            (requester_workspace_id = id AND target_workspace_id = public.get_user_workspace_id(auth.uid()))
            OR
            (target_workspace_id = id AND requester_workspace_id = public.get_user_workspace_id(auth.uid()))
          )
    )
    OR public.is_platform_owner(auth.uid())
);

CREATE POLICY "workspaces_insert_policy"
ON public.workspaces
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() IS NOT NULL AND created_by = auth.uid());

CREATE POLICY "workspaces_update_admin"
ON public.workspaces
FOR UPDATE
TO authenticated
USING (
    public.is_workspace_admin(id, auth.uid())
    OR public.is_platform_owner(auth.uid())
)
WITH CHECK (
    public.is_workspace_admin(id, auth.uid())
    OR public.is_platform_owner(auth.uid())
);

-- 4.4 سياسات أعضاء مساحة العمل (workspace_members)
CREATE POLICY "members_select_policy"
ON public.workspace_members
FOR SELECT
TO authenticated
USING (
    public.is_workspace_member(workspace_id, auth.uid())
    OR public.is_platform_owner(auth.uid())
);

CREATE POLICY "members_manage_admin"
ON public.workspace_members
FOR ALL
TO authenticated
USING (public.is_workspace_admin(workspace_id, auth.uid()))
WITH CHECK (public.is_workspace_admin(workspace_id, auth.uid()));

-- 4.5 سياسات طلبات الانضمام (join_requests)
CREATE POLICY "join_requests_select_policy"
ON public.join_requests
FOR SELECT
TO authenticated
USING (
    auth.uid() = user_id
    OR public.is_workspace_admin(workspace_id, auth.uid())
);

CREATE POLICY "join_requests_insert_self"
ON public.join_requests
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "join_requests_update_admin"
ON public.join_requests
FOR UPDATE
TO authenticated
USING (public.is_workspace_admin(workspace_id, auth.uid()))
WITH CHECK (public.is_workspace_admin(workspace_id, auth.uid()));

-- 4.6 سياسات طلبات استعادة كلمة المرور (password_reset_requests)
CREATE POLICY "pw_reset_select_policy"
ON public.password_reset_requests
FOR SELECT
TO authenticated
USING (
    auth.uid() = user_id
    OR (target_role = 'worker' AND workspace_id IS NOT NULL AND public.is_workspace_admin(workspace_id, auth.uid()))
    OR (target_role = 'admin' AND public.is_platform_owner(auth.uid()))
);

CREATE POLICY "pw_reset_insert_self"
ON public.password_reset_requests
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "pw_reset_update_resolvers"
ON public.password_reset_requests
FOR UPDATE
TO authenticated
USING (
    (target_role = 'worker' AND workspace_id IS NOT NULL AND public.is_workspace_admin(workspace_id, auth.uid()))
    OR (target_role = 'admin' AND public.is_platform_owner(auth.uid()))
)
WITH CHECK (
    (target_role = 'worker' AND workspace_id IS NOT NULL AND public.is_workspace_admin(workspace_id, auth.uid()))
    OR (target_role = 'admin' AND public.is_platform_owner(auth.uid()))
);

-- 4.7 سياسات التعاون بين المدراء (workspace_collaborations)
CREATE POLICY "collab_select_policy"
ON public.workspace_collaborations
FOR SELECT
TO authenticated
USING (
    public.is_workspace_admin(requester_workspace_id, auth.uid())
    OR public.is_workspace_admin(target_workspace_id, auth.uid())
);

CREATE POLICY "collab_insert_policy"
ON public.workspace_collaborations
FOR INSERT
TO authenticated
WITH CHECK (
    public.is_workspace_admin(requester_workspace_id, auth.uid())
    AND requester_workspace_id <> target_workspace_id
);

CREATE POLICY "collab_update_policy"
ON public.workspace_collaborations
FOR UPDATE
TO authenticated
USING (
    public.is_workspace_admin(requester_workspace_id, auth.uid())
    OR public.is_workspace_admin(target_workspace_id, auth.uid())
)
WITH CHECK (
    public.is_workspace_admin(requester_workspace_id, auth.uid())
    OR public.is_workspace_admin(target_workspace_id, auth.uid())
);

-- 4.8 سياسات المحطات (stations)
CREATE POLICY "stations_select_policy"
ON public.stations
FOR SELECT
TO authenticated
USING (
    public.is_workspace_member(workspace_id, auth.uid())
    OR public.can_view_workspace_cash(workspace_id, auth.uid())
    OR public.can_view_workspace_parcels(workspace_id, auth.uid())
);

CREATE POLICY "stations_modify_admin"
ON public.stations
FOR ALL
TO authenticated
USING (public.is_workspace_admin(workspace_id, auth.uid()))
WITH CHECK (public.is_workspace_admin(workspace_id, auth.uid()));

-- 4.9 سياسات عمال المحطات (station_workers)
CREATE POLICY "station_workers_select"
ON public.station_workers
FOR SELECT
TO authenticated
USING (public.is_workspace_member(workspace_id, auth.uid()));

CREATE POLICY "station_workers_modify_admin"
ON public.station_workers
FOR ALL
TO authenticated
USING (public.is_workspace_admin(workspace_id, auth.uid()))
WITH CHECK (public.is_workspace_admin(workspace_id, auth.uid()));

-- 4.10 سياسات أرصدة المحطات (station_balances)
CREATE POLICY "station_balances_select"
ON public.station_balances
FOR SELECT
TO authenticated
USING (
    public.is_workspace_admin(workspace_id, auth.uid())
    OR (
        public.is_workspace_member(workspace_id, auth.uid())
        AND public.is_worker_assigned_to_station(station_id, auth.uid())
    )
    OR public.can_view_workspace_cash(workspace_id, auth.uid())
);

CREATE POLICY "station_balances_modify_admin"
ON public.station_balances
FOR ALL
TO authenticated
USING (public.is_workspace_admin(workspace_id, auth.uid()))
WITH CHECK (public.is_workspace_admin(workspace_id, auth.uid()));

-- 4.11 سياسات المعاملات النقدية (transactions) - عزل المحطة للعمال
CREATE POLICY "transactions_select_policy"
ON public.transactions
FOR SELECT
TO authenticated
USING (
    -- 1. مدير مساحة العمل يرى جميع محطات مساحته
    public.is_workspace_admin(workspace_id, auth.uid())
    OR
    -- 2. العامل يرى حصراً معاملات المحطة المعين بها
    (
        public.is_workspace_member(workspace_id, auth.uid())
        AND public.is_worker_assigned_to_station(station_id, auth.uid())
    )
    OR
    -- 3. مدير شريك مسموح له برؤية حركة الأموال
    public.can_view_workspace_cash(workspace_id, auth.uid())
);

CREATE POLICY "transactions_insert_policy"
ON public.transactions
FOR INSERT
TO authenticated
WITH CHECK (
    auth.uid() IS NOT NULL
    AND created_by = auth.uid()
    AND (
        public.is_workspace_admin(workspace_id, auth.uid())
        OR (
            public.is_workspace_member(workspace_id, auth.uid())
            AND public.is_worker_assigned_to_station(station_id, auth.uid())
        )
    )
);

CREATE POLICY "transactions_update_admin"
ON public.transactions
FOR UPDATE
TO authenticated
USING (public.is_workspace_admin(workspace_id, auth.uid()))
WITH CHECK (public.is_workspace_admin(workspace_id, auth.uid()));

-- 4.12 سياسات الكوليات (parcels) - عزل المحطات للعمال
CREATE POLICY "parcels_select_policy"
ON public.parcels
FOR SELECT
TO authenticated
USING (
    -- 1. مدير مساحة العمل يرى جميع كوليات مساحته
    public.is_workspace_admin(workspace_id, auth.uid())
    OR
    -- 2. العامل يرى الكوليات المنطلقة من محطته أو الواصلة إليها
    (
        public.is_workspace_member(workspace_id, auth.uid())
        AND (
            public.is_worker_assigned_to_station(origin_station_id, auth.uid())
            OR public.is_worker_assigned_to_station(destination_station_id, auth.uid())
        )
    )
    OR
    -- 3. مدير شريك فُعِّلت له مشاركة الكوليات
    public.can_view_workspace_parcels(workspace_id, auth.uid())
);

CREATE POLICY "parcels_insert_policy"
ON public.parcels
FOR INSERT
TO authenticated
WITH CHECK (
    auth.uid() IS NOT NULL
    AND created_by = auth.uid()
    AND (
        public.is_workspace_admin(workspace_id, auth.uid())
        OR (
            public.is_workspace_member(workspace_id, auth.uid())
            AND public.is_worker_assigned_to_station(origin_station_id, auth.uid())
        )
    )
);

CREATE POLICY "parcels_update_policy"
ON public.parcels
FOR UPDATE
TO authenticated
USING (
    public.is_workspace_admin(workspace_id, auth.uid())
    OR (
        public.is_workspace_member(workspace_id, auth.uid())
        AND (
            public.is_worker_assigned_to_station(origin_station_id, auth.uid())
            OR public.is_worker_assigned_to_station(destination_station_id, auth.uid())
        )
    )
)
WITH CHECK (
    public.is_workspace_admin(workspace_id, auth.uid())
    OR (
        public.is_workspace_member(workspace_id, auth.uid())
        AND (
            public.is_worker_assigned_to_station(origin_station_id, auth.uid())
            OR public.is_worker_assigned_to_station(destination_station_id, auth.uid())
        )
    )
);

-- 4.13 سياسات الاشتراكات (subscriptions)
CREATE POLICY "subscriptions_select_policy"
ON public.subscriptions
FOR SELECT
TO authenticated
USING (
    public.is_workspace_admin(workspace_id, auth.uid())
    OR public.is_platform_owner(auth.uid())
);

CREATE POLICY "subscriptions_update_platform_owner"
ON public.subscriptions
FOR UPDATE
TO authenticated
USING (public.is_platform_owner(auth.uid()))
WITH CHECK (public.is_platform_owner(auth.uid()));

-- 4.14 سياسات العملات (currencies)
CREATE POLICY "currencies_select_policy"
ON public.currencies
FOR SELECT
TO authenticated
USING (public.is_workspace_member(workspace_id, auth.uid()));

CREATE POLICY "currencies_modify_admin"
ON public.currencies
FOR ALL
TO authenticated
USING (public.is_workspace_admin(workspace_id, auth.uid()))
WITH CHECK (public.is_workspace_admin(workspace_id, auth.uid()));

-- 4.15 سياسات سجل التدقيق (audit_logs)
CREATE POLICY "audit_logs_select_admin"
ON public.audit_logs
FOR SELECT
TO authenticated
USING (public.is_workspace_admin(workspace_id, auth.uid()));

CREATE POLICY "audit_logs_insert_members"
ON public.audit_logs
FOR INSERT
TO authenticated
WITH CHECK (public.is_workspace_member(workspace_id, auth.uid()));

-- 4.16 سياسات جدول رحلات الشحن (trips)
CREATE POLICY "trips_select_policy"
ON public.trips
FOR SELECT
TO authenticated
USING (
    public.is_workspace_admin(workspace_id, auth.uid())
    OR (
        public.is_workspace_member(workspace_id, auth.uid())
        AND (
            public.is_worker_assigned_to_station(origin_station_id, auth.uid())
            OR public.is_worker_assigned_to_station(destination_station_id, auth.uid())
        )
    )
);

CREATE POLICY "trips_insert_policy"
ON public.trips
FOR INSERT
TO authenticated
WITH CHECK (
    auth.uid() IS NOT NULL
    AND created_by = auth.uid()
    AND (
        public.is_workspace_admin(workspace_id, auth.uid())
        OR (
            public.is_workspace_member(workspace_id, auth.uid())
            AND public.is_worker_assigned_to_station(origin_station_id, auth.uid())
        )
    )
);

CREATE POLICY "trips_update_policy"
ON public.trips
FOR UPDATE
TO authenticated
USING (
    public.is_workspace_admin(workspace_id, auth.uid())
    OR (
        public.is_workspace_member(workspace_id, auth.uid())
        AND (
            public.is_worker_assigned_to_station(origin_station_id, auth.uid())
            OR public.is_worker_assigned_to_station(destination_station_id, auth.uid())
        )
    )
)
WITH CHECK (
    public.is_workspace_admin(workspace_id, auth.uid())
    OR (
        public.is_workspace_member(workspace_id, auth.uid())
        AND (
            public.is_worker_assigned_to_station(origin_station_id, auth.uid())
            OR public.is_worker_assigned_to_station(destination_station_id, auth.uid())
        )
    )
);

CREATE POLICY "trips_delete_policy"
ON public.trips
FOR DELETE
TO authenticated
USING (
    public.is_workspace_admin(workspace_id, auth.uid())
);

-- 4.17 سياسات جدول طرود الرحلات (trip_parcels)
CREATE POLICY "trip_parcels_select_policy"
ON public.trip_parcels
FOR SELECT
TO authenticated
USING (
    public.is_workspace_admin(workspace_id, auth.uid())
    OR EXISTS (
        SELECT 1 FROM public.trips t
        WHERE t.id = trip_parcels.trip_id
          AND (
              public.is_worker_assigned_to_station(t.origin_station_id, auth.uid())
              OR public.is_worker_assigned_to_station(t.destination_station_id, auth.uid())
          )
    )
);

CREATE POLICY "trip_parcels_insert_policy"
ON public.trip_parcels
FOR INSERT
TO authenticated
WITH CHECK (
    auth.uid() IS NOT NULL
    AND (
        public.is_workspace_admin(workspace_id, auth.uid())
        OR EXISTS (
            SELECT 1 FROM public.trips t
            WHERE t.id = trip_parcels.trip_id
              AND public.is_worker_assigned_to_station(t.origin_station_id, auth.uid())
        )
    )
);

CREATE POLICY "trip_parcels_update_policy"
ON public.trip_parcels
FOR UPDATE
TO authenticated
USING (
    public.is_workspace_admin(workspace_id, auth.uid())
    OR EXISTS (
        SELECT 1 FROM public.trips t
        WHERE t.id = trip_parcels.trip_id
          AND (
              public.is_worker_assigned_to_station(t.origin_station_id, auth.uid())
              OR public.is_worker_assigned_to_station(t.destination_station_id, auth.uid())
          )
    )
)
WITH CHECK (
    public.is_workspace_admin(workspace_id, auth.uid())
    OR EXISTS (
        SELECT 1 FROM public.trips t
        WHERE t.id = trip_parcels.trip_id
          AND (
              public.is_worker_assigned_to_station(t.origin_station_id, auth.uid())
              OR public.is_worker_assigned_to_station(t.destination_station_id, auth.uid())
          )
    )
);

CREATE POLICY "trip_parcels_delete_policy"
ON public.trip_parcels
FOR DELETE
TO authenticated
USING (
    public.is_workspace_admin(workspace_id, auth.uid())
    OR EXISTS (
        SELECT 1 FROM public.trips t
        WHERE t.id = trip_parcels.trip_id
          AND public.is_worker_assigned_to_station(t.origin_station_id, auth.uid())
    )
);

-- 4.18 سياسات السائقين المحفوظين (remembered_drivers)
CREATE POLICY "remembered_drivers_select_policy"
ON public.remembered_drivers
FOR SELECT
TO authenticated
USING (
    public.is_workspace_member(workspace_id, auth.uid())
);

CREATE POLICY "remembered_drivers_insert_policy"
ON public.remembered_drivers
FOR INSERT
TO authenticated
WITH CHECK (
    auth.uid() IS NOT NULL
    AND public.is_workspace_member(workspace_id, auth.uid())
);

CREATE POLICY "remembered_drivers_update_policy"
ON public.remembered_drivers
FOR UPDATE
TO authenticated
USING (
    public.is_workspace_member(workspace_id, auth.uid())
)
WITH CHECK (
    public.is_workspace_member(workspace_id, auth.uid())
);

-- 4.19 سياسات ماتريكيلات العربات المحفوظة (remembered_vehicles)
CREATE POLICY "remembered_vehicles_select_policy"
ON public.remembered_vehicles
FOR SELECT
TO authenticated
USING (
    public.is_workspace_member(workspace_id, auth.uid())
);

CREATE POLICY "remembered_vehicles_insert_policy"
ON public.remembered_vehicles
FOR INSERT
TO authenticated
WITH CHECK (
    auth.uid() IS NOT NULL
    AND public.is_workspace_member(workspace_id, auth.uid())
);

CREATE POLICY "remembered_vehicles_update_policy"
ON public.remembered_vehicles
FOR UPDATE
TO authenticated
USING (
    public.is_workspace_member(workspace_id, auth.uid())
)
WITH CHECK (
    public.is_workspace_member(workspace_id, auth.uid())
);

-- ============================================================================
-- 5. التريجرز لتحديث الأرصدة تلقائياً وتوليد البيانات (TRIGGERS)
-- ============================================================================

-- دالة وتريجر لتحديث رصيد المحطة عند كل معاملة مؤكدة أو معدلة أو ملغاة
CREATE OR REPLACE FUNCTION public.fn_update_station_balance()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_old_signed NUMERIC(14,2) := 0;
    v_new_signed NUMERIC(14,2) := 0;
    v_diff NUMERIC(14,2) := 0;
BEGIN
    IF TG_OP = 'INSERT' THEN
        IF NEW.status = 'confirmed' THEN
            IF NEW.type IN ('cash_in', 'parcel_shipping_fee', 'parcel_cod_collection') THEN
                v_diff := NEW.amount;
            ELSIF NEW.type IN ('cash_out', 'goods_payment', 'parcel_cod_payout') THEN
                v_diff := -NEW.amount;
            END IF;
        END IF;
    ELSIF TG_OP = 'UPDATE' THEN
        IF OLD.status = 'confirmed' THEN
            IF OLD.type IN ('cash_in', 'parcel_shipping_fee', 'parcel_cod_collection') THEN
                v_old_signed := OLD.amount;
            ELSIF OLD.type IN ('cash_out', 'goods_payment', 'parcel_cod_payout') THEN
                v_old_signed := -OLD.amount;
            END IF;
        END IF;

        IF NEW.status = 'confirmed' THEN
            IF NEW.type IN ('cash_in', 'parcel_shipping_fee', 'parcel_cod_collection') THEN
                v_new_signed := NEW.amount;
            ELSIF NEW.type IN ('cash_out', 'goods_payment', 'parcel_cod_payout') THEN
                v_new_signed := -NEW.amount;
            END IF;
        END IF;

        v_diff := v_new_signed - v_old_signed;
    END IF;

    IF v_diff <> 0 THEN
        INSERT INTO public.station_balances (station_id, workspace_id, currency, balance, updated_at)
        VALUES (NEW.station_id, NEW.workspace_id, NEW.currency, v_diff, timezone('utc'::text, now()))
        ON CONFLICT (station_id, currency)
        DO UPDATE SET 
            balance = public.station_balances.balance + v_diff,
            updated_at = timezone('utc'::text, now());
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_update_station_balance ON public.transactions;
CREATE TRIGGER trg_update_station_balance
AFTER INSERT OR UPDATE ON public.transactions
FOR EACH ROW
EXECUTE FUNCTION public.fn_update_station_balance();

-- ============================================================================
-- 6. دوال العمليات عن بُعد (RPC FUNCTIONS - SECURITY DEFINER)
-- ============================================================================

-- دالة مساعدة لتوليد أكواد قصيرة عشوائية آمنة (Short ID / Invite Code)
CREATE OR REPLACE FUNCTION public.fn_generate_alnum_code(p_len INT)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_chars CONSTANT TEXT := '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
    v_result TEXT := '';
    v_i INT;
BEGIN
    FOR v_i IN 1..p_len LOOP
        v_result := v_result || substr(v_chars, floor(random() * length(v_chars) + 1)::INT, 1);
    END LOOP;
    RETURN v_result;
END;
$$;

-- 6.1 إنشاء مساحة عمل جديدة مع عضوية المدير، اشتراك تجريبي 15 يوم، المحطات والعملات الافتراضية
CREATE OR REPLACE FUNCTION public.rpc_create_workspace(p_name TEXT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_user_meta JSONB;
    v_user_name TEXT;
    v_user_phone TEXT;
    v_user_whatsapp TEXT;
    v_short_id VARCHAR(6);
    v_invite_code VARCHAR(12);
    v_ws public.workspaces%ROWTYPE;
    v_sub public.subscriptions%ROWTYPE;
    v_st_dakhla UUID;
    v_st_nouadhibou UUID;
    v_clean_name TEXT;
BEGIN
    IF v_user_id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'يرجى تسجيل الدخول أولاً');
    END IF;

    -- ضمان وجود الملف الشخصي في جدول profiles
    SELECT raw_user_meta_data INTO v_user_meta
    FROM auth.users
    WHERE id = v_user_id;

    v_user_name := COALESCE(NULLIF(TRIM(v_user_meta->>'name'), ''), 'مدير المحطة');
    v_user_phone := COALESCE(NULLIF(TRIM(v_user_meta->>'phone'), ''), v_user_id::TEXT);
    v_user_whatsapp := COALESCE(NULLIF(TRIM(v_user_meta->>'whatsapp_number'), ''), v_user_phone);

    INSERT INTO public.profiles (id, name, phone, whatsapp_number)
    VALUES (v_user_id, v_user_name, v_user_phone, v_user_whatsapp)
    ON CONFLICT (id) DO UPDATE SET
        name = COALESCE(NULLIF(public.profiles.name, ''), EXCLUDED.name),
        updated_at = timezone('utc'::text, now());

    SELECT phone, whatsapp_number, name
    INTO v_user_phone, v_user_whatsapp, v_user_name
    FROM public.profiles
    WHERE id = v_user_id;

    -- توليد short_id فريد من 6 أحرف
    LOOP
        v_short_id := public.fn_generate_alnum_code(6);
        EXIT WHEN NOT EXISTS (SELECT 1 FROM public.workspaces WHERE short_id = v_short_id);
    END LOOP;

    -- توليد invite_code فريد من 8 أحرف
    LOOP
        v_invite_code := public.fn_generate_alnum_code(8);
        EXIT WHEN NOT EXISTS (SELECT 1 FROM public.workspaces WHERE invite_code = v_invite_code);
    END LOOP;

    v_clean_name := COALESCE(NULLIF(TRIM(p_name), ''), 'محطة الاتحادية - ' || v_user_name);

    -- 1. إنشاء مساحة العمل
    INSERT INTO public.workspaces (
        short_id,
        name,
        invite_code,
        owner_phone,
        owner_whatsapp,
        last_parcel_number,
        created_by
    )
    VALUES (
        v_short_id,
        v_clean_name,
        v_invite_code,
        v_user_phone,
        v_user_whatsapp,
        100,
        v_user_id
    )
    RETURNING * INTO v_ws;

    -- 2. إضافة المالك كعضو مدير نشط (admin)
    INSERT INTO public.workspace_members (workspace_id, user_id, role, status)
    VALUES (v_ws.id, v_user_id, 'admin', 'active')
    ON CONFLICT (workspace_id, user_id) DO UPDATE SET
        role = 'admin',
        status = 'active';

    -- 3. إنشاء اشتراك تجريبي مجاني لمدة 15 يوماً
    INSERT INTO public.subscriptions (
        workspace_id,
        status,
        start_date,
        end_date,
        is_trial,
        notes
    )
    VALUES (
        v_ws.id,
        'trial',
        timezone('utc'::text, now()),
        timezone('utc'::text, now()) + interval '15 days',
        TRUE,
        'فترة تجريبية مجانية لمدة 15 يوماً'
    )
    ON CONFLICT (workspace_id) DO UPDATE SET
        notes = EXCLUDED.notes
    RETURNING * INTO v_sub;

    -- 4. إنشاء المحطتين الافتراضيتين (الداخلة ونواذيبو)
    INSERT INTO public.stations (workspace_id, name, city, country, is_active, phone, address)
    VALUES (
        v_ws.id,
        'محطة الداخلة الرئيسية',
        'الداخلة',
        'MA',
        TRUE,
        '+212 528 890000',
        'شارع الولاء، ميناء الداخلة، المملكة المغربية'
    )
    RETURNING id INTO v_st_dakhla;

    INSERT INTO public.stations (workspace_id, name, city, country, is_active, phone, address)
    VALUES (
        v_ws.id,
        'محطة نواذيبو الدولية',
        'نواذيبو',
        'MR',
        TRUE,
        '+222 4574 0000',
        'حي كانصادو، طريق الميناء المستقل، الجمهورية الإسلامية الموريتانية'
    )
    RETURNING id INTO v_st_nouadhibou;

    -- تهيئة أرصدة المحطتين بـ 0 لكل عملة
    INSERT INTO public.station_balances (station_id, workspace_id, currency, balance)
    VALUES
        (v_st_dakhla, v_ws.id, 'MAD', 0.00),
        (v_st_dakhla, v_ws.id, 'MRU', 0.00),
        (v_st_nouadhibou, v_ws.id, 'MAD', 0.00),
        (v_st_nouadhibou, v_ws.id, 'MRU', 0.00)
    ON CONFLICT (station_id, currency) DO NOTHING;

    -- 5. إنشاء العملتين الافتراضيتين (MAD و MRU)
    INSERT INTO public.currencies (workspace_id, code, label_ar, symbol, rate_to_mad, is_active)
    VALUES
        (v_ws.id, 'MAD', 'درهم مغربي', 'د.م.', 1.0, TRUE),
        (v_ws.id, 'MRU', 'أوقية موريتانية', 'أ.م.', 0.263, TRUE)
    ON CONFLICT (workspace_id, code) DO NOTHING;

    RETURN jsonb_build_object(
        'success', true,
        'workspace_id', v_ws.id,
        'short_id', v_ws.short_id,
        'invite_code', v_ws.invite_code,
        'workspace', to_jsonb(v_ws),
        'subscription', to_jsonb(v_sub),
        'stations', COALESCE((SELECT jsonb_agg(to_jsonb(s) ORDER BY s.created_at) FROM public.stations s WHERE s.workspace_id = v_ws.id), '[]'::jsonb),
        'currencies', COALESCE((SELECT jsonb_agg(to_jsonb(c) ORDER BY c.created_at) FROM public.currencies c WHERE c.workspace_id = v_ws.id), '[]'::jsonb)
    );
END;
$$;

-- 6.2 إرسال طلب انضمام عامل باستخدام رمز الدعوة
CREATE OR REPLACE FUNCTION public.rpc_submit_join_request(p_invite_code TEXT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_ws public.workspaces%ROWTYPE;
    v_prof public.profiles%ROWTYPE;
    v_user_meta JSONB;
    v_req public.join_requests%ROWTYPE;
    v_clean_code TEXT := UPPER(TRIM(COALESCE(p_invite_code, '')));
BEGIN
    IF v_user_id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'يرجى تسجيل الدخول أولاً');
    END IF;

    IF v_clean_code = '' THEN
        RETURN jsonb_build_object('success', false, 'error', 'يرجى إدخال رمز الدعوة');
    END IF;

    SELECT * INTO v_ws
    FROM public.workspaces
    WHERE UPPER(invite_code) = v_clean_code
    LIMIT 1;

    IF v_ws.id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'رمز الدعوة غير صحيح أو منتهي الصلاحية');
    END IF;

    -- التأكد من وجود ملف شخصي للمستخدم
    SELECT * INTO v_prof FROM public.profiles WHERE id = v_user_id;
    IF v_prof.id IS NULL THEN
        SELECT raw_user_meta_data INTO v_user_meta FROM auth.users WHERE id = v_user_id;
        INSERT INTO public.profiles (id, name, phone, whatsapp_number)
        VALUES (
            v_user_id,
            COALESCE(NULLIF(TRIM(v_user_meta->>'name'), ''), 'موظف محطة'),
            COALESCE(NULLIF(TRIM(v_user_meta->>'phone'), ''), v_user_id::TEXT),
            COALESCE(NULLIF(TRIM(v_user_meta->>'whatsapp_number'), ''), COALESCE(NULLIF(TRIM(v_user_meta->>'phone'), ''), v_user_id::TEXT))
        )
        ON CONFLICT (id) DO NOTHING
        RETURNING * INTO v_prof;
    END IF;

    INSERT INTO public.join_requests (
        workspace_id,
        user_id,
        invite_code_used,
        user_name,
        user_phone,
        user_whatsapp,
        status,
        created_at
    )
    VALUES (
        v_ws.id,
        v_user_id,
        v_clean_code,
        COALESCE(v_prof.name, 'موظف محطة'),
        COALESCE(v_prof.phone, ''),
        COALESCE(v_prof.whatsapp_number, COALESCE(v_prof.phone, '')),
        'pending',
        timezone('utc'::text, now())
    )
    ON CONFLICT (workspace_id, user_id) DO UPDATE SET
        invite_code_used = EXCLUDED.invite_code_used,
        status = 'pending',
        created_at = timezone('utc'::text, now()),
        resolved_at = NULL,
        resolved_by = NULL
    RETURNING * INTO v_req;

    RETURN jsonb_build_object(
        'success', true,
        'request_id', v_req.id,
        'workspace_id', v_ws.id,
        'request', to_jsonb(v_req)
    );
END;
$$;

-- 6.3 الموافقة على طلب انضمام عامل (لمدير مساحة العمل فقط)
CREATE OR REPLACE FUNCTION public.rpc_approve_join_request(p_request_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_req public.join_requests%ROWTYPE;
BEGIN
    IF v_user_id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'غير مصرح');
    END IF;

    SELECT * INTO v_req
    FROM public.join_requests
    WHERE id = p_request_id;

    IF v_req.id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'طلب الانضمام غير موجود');
    END IF;

    IF NOT public.is_workspace_admin(v_req.workspace_id, v_user_id) THEN
        RETURN jsonb_build_object('success', false, 'error', 'صلاحية الموافقة لمدير مساحة العمل فقط');
    END IF;

    UPDATE public.join_requests
    SET status = 'approved',
        resolved_at = timezone('utc'::text, now()),
        resolved_by = v_user_id
    WHERE id = p_request_id;

    INSERT INTO public.workspace_members (workspace_id, user_id, role, status, joined_at)
    VALUES (v_req.workspace_id, v_req.user_id, 'worker', 'active', timezone('utc'::text, now()))
    ON CONFLICT (workspace_id, user_id) DO UPDATE SET
        role = 'worker',
        status = 'active';

    RETURN jsonb_build_object(
        'success', true,
        'workspace_id', v_req.workspace_id,
        'user_id', v_req.user_id
    );
END;
$$;

-- 6.4 رفض طلب انضمام عامل (لمدير مساحة العمل فقط)
CREATE OR REPLACE FUNCTION public.rpc_reject_join_request(p_request_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_req public.join_requests%ROWTYPE;
BEGIN
    IF v_user_id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'غير مصرح');
    END IF;

    SELECT * INTO v_req
    FROM public.join_requests
    WHERE id = p_request_id;

    IF v_req.id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'طلب الانضمام غير موجود');
    END IF;

    IF NOT public.is_workspace_admin(v_req.workspace_id, v_user_id) THEN
        RETURN jsonb_build_object('success', false, 'error', 'صلاحية الرفض لمدير مساحة العمل فقط');
    END IF;

    UPDATE public.join_requests
    SET status = 'rejected',
        resolved_at = timezone('utc'::text, now()),
        resolved_by = v_user_id
    WHERE id = p_request_id;

    RETURN jsonb_build_object('success', true);
END;
$$;

-- 6.5 تجديد رمز الدعوة لمساحة العمل (لمدير مساحة العمل فقط)
CREATE OR REPLACE FUNCTION public.rpc_renew_invite_code(p_workspace_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_new_code VARCHAR(12);
BEGIN
    IF v_user_id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'غير مصرح');
    END IF;

    IF NOT public.is_workspace_admin(p_workspace_id, v_user_id) THEN
        RETURN jsonb_build_object('success', false, 'error', 'صلاحية تجديد الرمز لمدير مساحة العمل فقط');
    END IF;

    LOOP
        v_new_code := public.fn_generate_alnum_code(8);
        EXIT WHEN NOT EXISTS (SELECT 1 FROM public.workspaces WHERE invite_code = v_new_code);
    END LOOP;

    UPDATE public.workspaces
    SET invite_code = v_new_code,
        updated_at = timezone('utc'::text, now())
    WHERE id = p_workspace_id;

    RETURN jsonb_build_object(
        'success', true,
        'invite_code', v_new_code
    );
END;
$$;

-- 6.6 إرسال طلب تعاون لمساحة عمل أخرى عبر المعرف القصير (Short ID)
CREATE OR REPLACE FUNCTION public.rpc_send_collaboration_request(p_target_short_id TEXT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_my_ws_id UUID;
    v_target_ws public.workspaces%ROWTYPE;
    v_collab public.workspace_collaborations%ROWTYPE;
    v_clean_short_id TEXT := UPPER(TRIM(COALESCE(p_target_short_id, '')));
BEGIN
    IF v_user_id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'غير مصرح');
    END IF;

    v_my_ws_id := public.get_user_workspace_id(v_user_id);
    IF v_my_ws_id IS NULL OR NOT public.is_workspace_admin(v_my_ws_id, v_user_id) THEN
        RETURN jsonb_build_object('success', false, 'error', 'صلاحية إرسال طلبات التعاون لمدير مساحة العمل فقط');
    END IF;

    SELECT * INTO v_target_ws
    FROM public.workspaces
    WHERE UPPER(short_id) = v_clean_short_id
    LIMIT 1;

    IF v_target_ws.id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'لم يتم العثور على مساحة عمل بهذا المعرف');
    END IF;

    IF v_target_ws.id = v_my_ws_id THEN
        RETURN jsonb_build_object('success', false, 'error', 'لا يمكنك إرسال طلب تعاون لمساحة عملك الخاصة');
    END IF;

    INSERT INTO public.workspace_collaborations (
        requester_workspace_id,
        target_workspace_id,
        status,
        requester_share_cash,
        requester_share_parcels,
        requester_share_reports,
        target_share_cash,
        target_share_parcels,
        target_share_reports,
        updated_at
    )
    VALUES (
        v_my_ws_id,
        v_target_ws.id,
        'pending',
        FALSE,
        FALSE,
        FALSE,
        FALSE,
        FALSE,
        FALSE,
        timezone('utc'::text, now())
    )
    ON CONFLICT (requester_workspace_id, target_workspace_id) DO UPDATE SET
        status = 'pending',
        updated_at = timezone('utc'::text, now())
    RETURNING * INTO v_collab;

    RETURN jsonb_build_object(
        'success', true,
        'collaboration_id', v_collab.id,
        'target_workspace_id', v_target_ws.id,
        'target_workspace_name', v_target_ws.name,
        'target_workspace_short_id', v_target_ws.short_id,
        'collaboration', to_jsonb(v_collab)
    );
END;
$$;

-- 6.7 الرد على طلب التعاون بالقبول أو الرفض
CREATE OR REPLACE FUNCTION public.rpc_respond_to_collaboration(p_collab_id UUID, p_accept BOOLEAN)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_collab public.workspace_collaborations%ROWTYPE;
    v_new_status TEXT;
BEGIN
    IF v_user_id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'غير مصرح');
    END IF;

    SELECT * INTO v_collab
    FROM public.workspace_collaborations
    WHERE id = p_collab_id;

    IF v_collab.id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'طلب التعاون غير موجود');
    END IF;

    IF NOT (
        public.is_workspace_admin(v_collab.target_workspace_id, v_user_id)
        OR (NOT COALESCE(p_accept, FALSE) AND public.is_workspace_admin(v_collab.requester_workspace_id, v_user_id))
    ) THEN
        RETURN jsonb_build_object('success', false, 'error', 'غير مصرح للرد على طلب التعاون هذا');
    END IF;

    v_new_status := CASE WHEN COALESCE(p_accept, FALSE) THEN 'accepted' ELSE 'rejected' END;

    UPDATE public.workspace_collaborations
    SET status = v_new_status,
        updated_at = timezone('utc'::text, now())
    WHERE id = p_collab_id;

    RETURN jsonb_build_object(
        'success', true,
        'status', v_new_status
    );
END;
$$;

-- 6.8 تحديث إعدادات المشاركة الاختيارية بين مساحتي عمل متعاونتين
CREATE OR REPLACE FUNCTION public.rpc_update_sharing_settings(
    p_collab_id UUID,
    p_share_cash BOOLEAN,
    p_share_parcels BOOLEAN,
    p_share_reports BOOLEAN
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_collab public.workspace_collaborations%ROWTYPE;
BEGIN
    IF v_user_id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'غير مصرح');
    END IF;

    SELECT * INTO v_collab
    FROM public.workspace_collaborations
    WHERE id = p_collab_id;

    IF v_collab.id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'علاقة التعاون غير موجودة');
    END IF;

    IF public.is_workspace_admin(v_collab.requester_workspace_id, v_user_id) THEN
        UPDATE public.workspace_collaborations
        SET requester_share_cash = COALESCE(p_share_cash, FALSE),
            requester_share_parcels = COALESCE(p_share_parcels, FALSE),
            requester_share_reports = COALESCE(p_share_reports, FALSE),
            updated_at = timezone('utc'::text, now())
        WHERE id = p_collab_id;
    ELSIF public.is_workspace_admin(v_collab.target_workspace_id, v_user_id) THEN
        UPDATE public.workspace_collaborations
        SET target_share_cash = COALESCE(p_share_cash, FALSE),
            target_share_parcels = COALESCE(p_share_parcels, FALSE),
            target_share_reports = COALESCE(p_share_reports, FALSE),
            updated_at = timezone('utc'::text, now())
        WHERE id = p_collab_id;
    ELSE
        RETURN jsonb_build_object('success', false, 'error', 'غير مصرح لتعديل إعدادات المشاركة');
    END IF;

    RETURN jsonb_build_object('success', true);
END;
$$;

-- 6.9 توليد رقم تسلسلي ذري للكوليات لكل مساحة عمل لمنع التصادم بين الأجهزة (ITT-YYYY-NNNNN)
CREATE OR REPLACE FUNCTION public.rpc_next_parcel_number(p_workspace_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_next_num BIGINT;
    v_year TEXT;
    v_tracking_code VARCHAR(30);
BEGIN
    IF v_user_id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'يرجى تسجيل الدخول أولاً');
    END IF;

    IF NOT public.is_workspace_member(p_workspace_id, v_user_id) THEN
        RETURN jsonb_build_object('success', false, 'error', 'غير مصرح في مساحة العمل هذه');
    END IF;

    -- قفل ذري على مستوى المعاملة لمساحة العمل لمنع أي تصادم متزامن بين جهازين
    PERFORM pg_advisory_xact_lock(hashtext('parcel_seq_' || p_workspace_id::TEXT));

    UPDATE public.workspaces
    SET last_parcel_number = GREATEST(
            COALESCE(last_parcel_number, 100),
            COALESCE((SELECT MAX(parcel_number) FROM public.parcels WHERE workspace_id = p_workspace_id), 100)
        ) + 1,
        updated_at = timezone('utc'::text, now())
    WHERE id = p_workspace_id
    RETURNING last_parcel_number INTO v_next_num;

    IF v_next_num IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'مساحة العمل غير موجودة');
    END IF;

    v_year := EXTRACT(YEAR FROM timezone('utc'::text, now()))::INT::TEXT;
    v_tracking_code := 'ITT-' || v_year || '-' || LPAD(v_next_num::TEXT, 5, '0');

    -- ضمان عدم تكرار tracking_code عالمياً في جدول parcels
    WHILE EXISTS (SELECT 1 FROM public.parcels WHERE tracking_code = v_tracking_code) LOOP
        UPDATE public.workspaces
        SET last_parcel_number = last_parcel_number + 1
        WHERE id = p_workspace_id
        RETURNING last_parcel_number INTO v_next_num;

        v_tracking_code := 'ITT-' || v_year || '-' || LPAD(v_next_num::TEXT, 5, '0');
    END LOOP;

    RETURN jsonb_build_object(
        'success', true,
        'parcel_number', v_next_num,
        'tracking_code', v_tracking_code
    );
END;
$$;

-- منح صلاحيات التنفيذ للمستخدمين المصادق عليهم (authenticated) فقط
GRANT EXECUTE ON FUNCTION public.fn_generate_alnum_code(INT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.rpc_create_workspace(TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.rpc_submit_join_request(TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.rpc_approve_join_request(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION public.rpc_reject_join_request(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION public.rpc_renew_invite_code(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION public.rpc_send_collaboration_request(TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.rpc_respond_to_collaboration(UUID, BOOLEAN) TO authenticated;
GRANT EXECUTE ON FUNCTION public.rpc_update_sharing_settings(UUID, BOOLEAN, BOOLEAN, BOOLEAN) TO authenticated;
GRANT EXECUTE ON FUNCTION public.rpc_next_parcel_number(UUID) TO authenticated;

-- ============================================================================
-- 7. تفعيل التحديث الفوري (SUPABASE REALTIME PUBLICATION)
-- ============================================================================
DO $$
DECLARE
    v_tbl TEXT;
BEGIN
    IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') THEN
        FOREACH v_tbl IN ARRAY ARRAY[
            'parcels',
            'trips',
            'trip_parcels',
            'transactions',
            'stations',
            'station_balances',
            'join_requests',
            'workspace_collaborations'
        ] LOOP
            BEGIN
                EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', v_tbl);
            EXCEPTION
                WHEN duplicate_object THEN NULL;
            END;
        END LOOP;
    END IF;
END;
$$;

-- ============================================================================
-- 8. أمر إدخال مالك المنصة يدوياً (توجيهات التشغيل)
-- ============================================================================
-- بعد تسجيل حسابك بالهاتف في التطبيق، انسخ معرف المستخدم الخاص بك (User ID) من Supabase Auth،
-- ونفذ السطر التالي في SQL Editor لترقية حسابك إلى مالك المنصة بصلاحيات كاملة:
--
-- INSERT INTO public.platform_owners (user_id) 
-- VALUES ('<ضع_معرف_المستخدم_هنا>');
--
-- مثال:
-- INSERT INTO public.platform_owners (user_id) 
-- VALUES ('b2f51234-5678-4321-8765-abcdef123456');
-- ============================================================================
